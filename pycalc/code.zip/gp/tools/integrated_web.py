"""통합 일별계획(V1·V2) → 웹 페이지용 JSON(암호화) — gpw/integrated.html 이 읽음
실행: python tools/integrated_web.py --extra extradata.json --password ... --out ../gpw/published/integrated.enc.json [--plain work/integrated_web.json]
(앞서 tools/integrated_plan.py prep · plating V1 · plating V2 를 돌려 둘 것)
"""
import argparse, calendar, datetime as dt, json, os, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from cglplan import color as CL, color_full as CF, publish as PB  # noqa: E402
from cglplan import tables as TB
import master_plan as MP  # noqa: E402
import integrated_plan as IP  # noqa: E402
import integrated_excel as IX  # noqa: E402

PRI_LABEL = {1: '수출 벌크(선적 완료기한)', 2: '가전 내수', 3: '수출 컨테이너·수요개발', 4: '주문재'}
GRP_PRI = {'건재수출': 3, '가전수출': 3, '가전내수': 2, '수요개발': 3, '주문재': 4}


def r0(x, n=0):
    return round(x, n) if isinstance(x, (int, float)) else x


def campaigns(R):
    """MILP 강종 상태 → 라인별 연속 구간 [(시작, 끝, 강종)]"""
    st = R['milp']['state']
    out = {}
    for l in ('1CGL', '2CGL'):
        ds = sorted(k.split('|')[1] for k in st if k.startswith(l + '|'))
        runs = []
        for d in ds:
            a = st[f'{l}|{d}']
            if runs and runs[-1][2] == a:
                runs[-1][1] = d
            else:
                runs.append([d, d, a])
        out[l] = runs
    return out


def plating_view(R):
    camp = campaigns(R)

    def camp_of(l, d):
        return next((c for c in camp[l] if c[0] <= d <= c[1]), None)
    cells = defaultdict(lambda: {'cls': Counter(), 'alloy': Counter(), 'items': []})
    for d, l, a, cls, t, due, *rest in [x[:6] for x in R['rows']]:
        c = cells[(d, l)]
        c['cls'][cls] += t
        c['alloy'][a] += t
    for d, l, a, cls, dest, port, win, t, due in R['dest']:
        cells[(d, l)]['items'].append([a, cls, dest, port or '', win or '', r0(t, 1), due])
    ev = {(c['date'], c['line']): c for c in R['cal']}
    out = []
    for (d, l), c in sorted(cells.items()):
        cp = camp_of(l, d)
        why = []
        if cp:
            why.append(f"{l} {cp[2]} 캠페인 {cp[0][5:]}~{cp[1][5:]} — 강종 전환(M/C) 횟수 최소화 기준으로 설정한 구간")
        early = [it for it in c['items'] if (dt.date.fromisoformat(it[6]) - dt.date.fromisoformat(d)).days > 14]
        if early:
            why.append(f"납기보다 15일 이상 앞선 생산 {sum(it[5] for it in early):,.0f}t — 해당 강종의 이 라인 생산 가능 기간이 이 구간뿐(캠페인)이거나, 후반 능력 부족(2CGL 대수리 11/23~12/6)")
        else:
            why.append('납기 근접 배치(선행 생산량 톤·일 최소화)')
        e = ev.get((d, l)) or {}
        out.append({'d': d, 'l': l, 'cls': {k: r0(v) for k, v in c['cls'].items()}, 'alloy': {k: r0(v) for k, v in c['alloy'].items()},
                    'items': sorted(c['items'], key=lambda z: z[6]), 'ev': e.get('event') or '', 'why': why})
    for (d, l), e in ev.items():                                 # 생산 없는 날(정기수리 등)
        if (d, l) not in cells and e.get('event'):
            out.append({'d': d, 'l': l, 'cls': {}, 'alloy': {}, 'items': [], 'ev': e['event'], 'why': []})
    return sorted(out, key=lambda z: (z['d'], z['l'])), camp


def color_view(P, ex):
    T = ex['tables']
    sub = P['masters']['V1']['measure']['substrate']
    thr = CF.thr_table(T['color_prod'], '2026-07-01', '2026-09-30')
    cells = defaultdict(lambda: {'g': Counter(), 'rows': [], 'act': False, 'min': 0.0})
    for M in P['color']:
        y, m = M['year'], M['month']
        agg = defaultdict(lambda: [0.0, 0.0])                    # 실적일: (일, 라인, 그룹, 품명)별 톤·분 → 품목 행
        for r in M['act']:
            c = cells[(dt.date(y, m, r['day']).isoformat(), r['line'])]
            c['g'][r['group']] += r['t']
            c['min'] += r.get('min') or 0
            c['act'] = True
            a = agg[(r['day'], r['line'], r['group'], r['product'])]
            a[0] += r['t']; a[1] += r.get('min') or 0
        for (day, line, g, prod), (t, mn) in agg.items():
            if t >= 0.5:
                cells[(dt.date(y, m, day).isoformat(), line)]['rows'].append([g, prod, '', '', '실적', r0(t, 1), r0(mn), r0(t / mn * 60, 1) if mn else 0, 'MES 생산 실적',
                                                                             '', prod, 0, [], ''])
        for r in M['rows']:
            d = dt.date(y, m, r['day']).isoformat()
            c = cells[(d, r['line'])]
            c['g'][r['group']] += r['t']
            c['min'] += r['min'] or 0
            g = r['group']
            if r.get('note'):                                            # 예전 준비 파일 문구도 같은 표현으로
                r['note'] = r['note'].replace('운영안대로', '운영안 준수').replace('앞당겨 생산', '선행 생산').replace('완료기한 후', '완료기한 경과')
            if g == '계획재':
                why = f"계획재는 운영안 사양·물량 우선 배정(타 그룹보다 먼저 시간 확보), {r['note']}"
            else:
                base = r.get('base') or CF.base_name(r['product'])[0]
                cands = CF.lines_for(base, g, thr)
                pri = 1 if '벌크' in str(r.get('ship')) or '선생산' in str(r.get('ship')) else GRP_PRI.get(g, 4)
                parts = [f"우선순위 {pri}({PRI_LABEL[pri]})", f"가능 라인 {'·'.join(cands)}" + (' — 해당 라인 전용 품명으로 우선 배정' if len(cands) == 1 else ' (속도 높은 라인 우선, 2CCL 후순위)')]
                if r.get('due'):
                    parts.append(f"선적 완료기한 {(r['dueYm'][5:].lstrip('0') + '/') if r.get('dueYm') else ''}{r['due']}일 → 기한 전 10일 이내 생산")
                elif '선생산' in str(r.get('ship')):
                    parts.append('익월 1~5일 선적분 → 당월 말 10일 이내 생산')
                else:
                    parts.append('월 소요량을 로트 단위로 균등 배치')
                if r.get('note'):
                    parts.append(r['note'] + ('(기한 내 가동시간 부족)' if r['note'] == '선행 생산' else ''))
                why = ', '.join(parts)
            base = r.get('base') or CF.base_name(r['product'])[0]
            sh = MP.self_of(sub, base)[0]
            sa = [[sec, a, r0(w, 3)] for (sec, a), w in MP.self_alloy(sub, base, r.get('cust') or '', g).items() if w > 0.005]
            dy, dm = map(int, r['dueYm'].split('-')) if r.get('dueYm') else (y, m)     # 휴지 집약으로 다른 달로 앞당겨진 행은 원래 달 기준 납기
            due = dt.date(dy, dm, int(r['due'])).isoformat() if r.get('due') else ''
            # 9~13: 납기(선적 완료기한) · 기본 품명 · 자가재 비중 · 자가재 (구역, 강종, 1t당) · 고객
            c['rows'].append([g, r['product'], r.get('spec') or '', r.get('dest') or '', r.get('ship') or '', r0(r['t'], 1), r0(r['min']), r0(r['tph'], 1), why,
                              due, base, r0(sh, 3), sa, r.get('cust') or ''])
    out = []
    for (d, l), c in sorted(cells.items()):
        out.append({'d': d, 'l': l, 'g': {k: r0(v) for k, v in c['g'].items()}, 'act': c['act'], 'min': r0(min(1440, c['min'])),
                    'rows': sorted(c['rows'], key=lambda z: -z[5])})
    unpl = [{'ym': M['ym'], 'g': u['group'], 'p': u['product'], 'c': u['cust'], 'dest': u['dest'], 't': r0(u['t']),
             'lines': '·'.join(CF.lines_for(u['product'], u['group'], thr)), **({'carry': u['carry']} if u.get('carry') else {})}
            for M in P['color'] for u in M['unplaced'] if u['t'] >= 5]
    lines = {M['ym']: {l: {'plan': M['monthPlan'].get(l), 'placed': r0(sum(r['t'] for r in M['rows'] if r['line'] == l) + M['doneLine'].get(l, 0))} for l in CL.LINES} for M in P['color']}
    return out, unpl, lines


CGRP = {'계획재': 'C건재', '주문재': 'C건재', '수요개발': 'C수요'}
GRPS = ['C건재', 'C수출', 'C수요', 'G국내', 'G수출', 'G자동차', 'G자가재']


SHIP_DEPT = {'도금판매그룹': 'G국내', '도금수출그룹': 'G수출', '자동차강판판매그룹': 'G자동차', '컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재'}
PROFILE_GROUPS = ('C건재', 'C수출')   # 도금은 계획과 같은 기준(품목 납기). 도금 내수에 쓰면 납기 = 월말 가정과 실제 월중 출하가 어긋나 자동차 재고가 음수 → 납기 가정 보완 후 적용


def ship_profile(ex):
    """MES 출하 실적(판매 출고 1300)의 월중 분포 — 그룹별, 월말 기준 칸(말일 = 31, 말일 − 1 = 30 …, 1~(말일 − 6)일은 그 날짜).
    완결된 달만. 없으면 None(→ 균등)"""
    t = (ex or {}).get('tables', {}).get('ship')
    if not t:
        return None
    I = t['columns'].index
    last = max(str(r[I('OUT_DT')]) for r in t['rows'])[:7]
    prof = defaultdict(Counter)
    for r in t['rows']:
        g = SHIP_DEPT.get(r[I('DEPT')])
        d = str(r[I('OUT_DT')])
        if not g or str(r[I('OUT_RSN_CD')]) != '1300' or d[:7] >= last:
            continue
        nd = calendar.monthrange(int(d[:4]), int(d[5:7]))[1]
        k = int(d[8:10]) if int(d[8:10]) <= nd - 6 else 31 - (nd - int(d[8:10]))
        prof[g][k] += f_(r[I('WGT')])
    return {g: {k: v / sum(c.values()) for k, v in c.items()} for g, c in prof.items() if sum(c.values()) > 0}


def f_(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def stock_daily(P, R, v, prof=None, outd=None):
    """그룹별 일말 재고 추이 = 9월말 + 생산(컬러 실적·계획, 도금 MILP) − 판매(컬러 = LP 월 판매 ÷ 일수, 도금 = 판매계획 품목 납기일, 자가재 = 컬러 필요량)"""
    M = P['masters'][v]
    prod = defaultdict(Counter)
    for Mo in P['color']:
        for r in Mo['act'] + Mo['rows']:
            prod[CGRP.get(r['group'], 'C수출')][dt.date(Mo['year'], Mo['month'], r['day']).isoformat()] += r['t']
    for d, l, a, c, t, due in R['rows']:
        prod[IP.CLS_GROUP[c]][d] += t
    SB = IX.self_balance(P, R)
    ship = defaultdict(Counter)                                  # 도금 판매 = 판매계획 품목의 납기일(선적창 끝·월말)에 나감
    for x in P['baseItems']:
        if x['cls'] != '자가재':
            ship[IP.CLS_GROUP[x['cls']]][max(IX.D0.isoformat(), x['due'])] += x['tons']
    def pday(g, d):                                              # 그 달 판매 중 이 날 나가는 비중(MES 월중 분포)
        nd = calendar.monthrange(d.year, d.month)[1]
        kk = lambda day: day if day <= nd - 6 else 31 - (nd - day)
        w = prof[g]
        tot = sum(w.get(kk(x), 0) for x in range(1, nd + 1)) or 1
        return w.get(kk(d.day), 0) / tot
    msales = defaultdict(float)                                  # 도금 내수 그룹: 판매계획 품목 톤을 월 합으로
    for x in P['baseItems']:
        if x['cls'] != '자가재':
            msales[(IP.CLS_GROUP[x['cls']], x['due'][:7])] += x['tons']
    out = {}
    for g in GRPS:
        s, ser = M['begin'].get(g, 0.0), {}
        for d in IX.days():
            if g == 'G자가재':
                s = sum(SB[p][(d - IX.D0).days][3] for p in SB)
            elif prof and g in PROFILE_GROUPS and g in prof:
                mi = d.month - 10
                sales = msales[(g, d.strftime('%Y-%m'))] if g.startswith('G') else M['plan'][g][mi]['sales']
                o = sales * pday(g, d)
                s += prod[g][d.isoformat()] - o
            elif g in ship:
                o = ship[g][d.isoformat()]
                s += prod[g][d.isoformat()] - o
            else:
                mi = d.month - 10
                o = M['plan'][g][mi]['sales'] / calendar.monthrange(d.year, d.month)[1]
                s += prod[g][d.isoformat()] - o
            if outd is not None and g != 'G자가재':
                outd.setdefault(g, {})[d.isoformat()] = o              # 하루 판매(출고) — 사내 PC 가 매일 '실제 재고 + 최신 재계획 생산 − 이것' 으로 재고 추이를 다시 굴림
            ser[d.isoformat()] = s
        out[g] = ser
    return out


def self_flow(P, R, v):
    """자가재 반순 품목(구역·강종·반순 끝) 하나하나에 대해 '도금이 언제·어느 라인에서 만들고 → 컬러가 언제·어느 라인에서 쓰는지'.
    컬러 사용 → 품목 연결은 품목을 만든 규칙(integrated_plan.self_items)과 같음: 필요일 = 컬러 생산일 − 8일, 필요일이 든 반순 끝이 그 품목의 납기"""
    sub = P['masters'][v]['measure']['substrate']
    ends = sorted({dt.date.fromisoformat(x['due']) for x in R['items'] if x['cls'] == '자가재'} |
                  {dt.date(y, m, e) for y, m in IP.Q for e in (10, 20, calendar.monthrange(y, m)[1])})
    bucket = lambda nd: next((e for e in ends if nd <= e), ends[-1])
    use = defaultdict(Counter)                                   # (반순 끝, 구역, 강종) → (컬러 생산일, 라인) → t
    acc = Counter()
    for Mo in P['color']:
        y, m = Mo['year'], Mo['month']
        for r in Mo['rows']:
            base = r.get('base') or CF.base_name(r['product'])[0]
            d = dt.date(y, m, r['day'])
            for (sec, a), w in MP.self_alloy(sub, base, r.get('cust') or '', r['group']).items():
                acc[(d, sec, a)] += r['t'] * w / MP.COLOR_YIELD
                use[(bucket(max(IX.D0, d - dt.timedelta(days=IP.SELF_LEAD))), sec, a)][(d.isoformat(), r['line'])] += r['t'] * w / MP.COLOR_YIELD
        # 실적일: 사용량은 selfUse(코일 실제 강종), 라인은 그날 자가재 소재(AA·BA) 실적 비중으로 나눔
        sh = defaultdict(Counter)
        for r in Mo['act']:
            if r['raw'][:2] in ('AA', 'BA'):
                sh[dt.date(y, m, r['day'])][r['line']] += r['rawT']
        for d_, sec, a, t in P['selfUse']:
            d = dt.date.fromisoformat(d_)
            if d in sh and (d.year, d.month) == (y, m):
                rest = t - acc.get((d, sec, a), 0)
                if rest <= 0.5:
                    continue
                tot = sum(sh[d].values())
                for l, w in sh[d].items():
                    use[(bucket(max(IX.D0, d - dt.timedelta(days=IP.SELF_LEAD))), sec, a)][(d_, l)] += rest * w / tot
    made = defaultdict(Counter)
    for d, l, a, cls, dest, port, win, t, due in R['dest']:
        if cls == '자가재':
            made[(dt.date.fromisoformat(due), dest, a)][(d, l)] += t
    out = []
    for x in R['items']:
        if x['cls'] != '자가재':
            continue
        k = (dt.date.fromisoformat(x['due']), x['dest'], x['alloy'])
        U, Mk = use.get(k, Counter()), made.get(k, Counter())
        out.append({'due': x['due'], 'sec': x['dest'], 'a': x['alloy'], 't': r0(x['tons']),
                    'made': [[d, l, r0(t)] for (d, l), t in sorted(Mk.items()) if t >= 0.5],
                    'use': [[d, l, r0(t)] for (d, l), t in sorted(U.items()) if t >= 0.5]})
    return out


def horizon_ext(MAT, SB):
    """계획 기간 끝(12/31) 너머 추정 — 화면에서 12월 말 칸이 비지 않게.
    구매 소재: 1월 이후 사용 = 4분기 일평균으로 가정해 리드타임 안쪽(12월에 내야 할) 발주를 추가.
    자가재: 12/27~31 사용(= 1월 초 컬러 생산분)을 12월 하루 평균 사용으로 가정"""
    ext = {}
    for k, o in MAT.items():
        rows = o['rows']
        avg = sum(x['use'] for x in rows) / len(rows)
        stock, L = rows[-1]['stock'], []
        d = IX.D1
        while True:
            d += dt.timedelta(days=1)
            od = d - dt.timedelta(days=o['lt'])
            if od > IX.D1:
                break
            need = max(0.0, o['target'] - (stock - avg))         # 목표재고 유지에 필요한 입고
            stock += need - avg
            if need > 0.5:
                L.append([od.isoformat(), d.isoformat(), r0(need)])
        ext[k] = {'avgUse': r0(avg), 'orders': L}
    self_est = {}
    cut = IX.D1 - dt.timedelta(days=IP.SELF_LEAD - 1)          # 12/27 부터 = 1월 컬러 생산분
    for p, rows in SB.items():
        dec = [u for d, u, pr, s in rows if d.month == 12 and d < cut]
        avg = sum(dec) / len(dec) if dec else 0.0
        self_est[p] = avg
    return ext, self_est, cut


def variant_view(P, R, v):
    M = P['masters'][v]
    cells, camp = plating_view(R)
    SB = IX.self_balance(P, R)
    MAT = IX.materials(P, R, v)
    ext, sest, cut = horizon_ext(MAT, SB)
    for p, rows in SB.items():                                   # 12/27~ 자가재 사용 추정분을 넣어 재고를 다시 굴림
        s, new = None, []
        for d, u, pr, st in rows:
            if d >= cut and u < 0.5:
                u = sest[p]
            s = st if s is None else s + pr - u
            new.append((d, u, pr, s))
        SB[p] = new
    lc = Counter()
    for d, l, a, c, t, due in R['rows']:
        lc[(l, int(d[5:7]))] += t
    plan = {g: [{k: r0(x[k], 1) for k in ('sales', 'prod', 'end', 'endDays', 'target', 'safety') if k in x} for x in rows] for g, rows in M['plan'].items()}
    return {
        'plan': plan, 'util': {k: [r0(x, 3) for x in u] for k, u in M['util'].items()},
        'third': {g: [r0(x['prod']) for x in rows] for g, rows in M['third'].items()},
        'plating': cells, 'campaigns': camp, 'mc': R['milp'].get('K'), 'inv': r0(R['milp'].get('INV')), 'short': r0(R['milp'].get('short', 0)), 'late': r0(R['milp'].get('late', 0)),
        'lineMonth': {f'{l}|{m}': r0(t) for (l, m), t in lc.items()},
        'self': {p: [[d.isoformat()[5:], r0(u), r0(pr), r0(s)] for d, u, pr, s in rows] for p, rows in SB.items()},
        'selfItems': [[x['due'], x['dest'], x['alloy'], x.get('window') or '월말', r0(x['tons'])] for x in R['items'] if x['cls'] == '자가재'],
        'mat': {k: {'begin': r0(o['begin']), 'target': o['target'], 'lt': o['lt'],
                    'rows': [[x['d'].isoformat()[5:], r0(x['use']), r0(x['in']), x['order'].isoformat()[5:] if x['in'] > 0.5 else '', r0(x['stock'])] for x in o['rows']]}
                for k, o in MAT.items()},
        'matExt': ext, 'selfEstFrom': cut.isoformat(), 'selfEstUse': {p: r0(v) for p, v in sest.items()},
        'selfFlow': self_flow(P, R, v),
    }


def build(ex):
    P = json.load(open(os.path.join(IP.WORK, 'integ_prep.json'), encoding='utf-8'))
    color, unpl, lines = color_view(P, ex)
    M1 = P['masters']['V1']
    act_last = max((c['d'] for c in color if c.get('act')), default='2026-10-01')       # 실적 마지막 날(컬러 실적 기준)
    out = {'app': 'cgl-integrated', 'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': act_last,
           'color': color, 'colorUnplaced': unpl, 'colorLines': lines,
           'moves': {'items': IP.color_moves(), **({k: v for k, v in (P.get('moves') or {}).items()})},   # 캘린더 끌어 옮기기(화면이 다시 불러 이어서 고침)
           'targets': {g: {k: r0(v, 1) for k, v in t.items()} for g, t in M1['targets'].items()},
           'demand': {g: {k: r0(v) for k, v in d.items()} for g, d in M1['measure']['demand'].items()},
           'begin': {k: r0(v) for k, v in M1['begin'].items()}, 'cap': MP.CAP, 'weights': MP.W,
           'substrate': sorted([[k, r0(x['t']), r0(x['self'], 2), {a: r0(w, 2) for a, w in x['alloy'].items()}] for k, x in M1['measure']['substrate'].items() if k != '_all' and x['t'] >= 300], key=lambda z: -z[1]),
           'selfCoef': {g: [r0(x, 3) for x in v[:3]] for g, v in M1['selfCoef'].items()},
           'variants': {}}
    pb = json.load(open(os.path.join(ROOT, 'cglplan', 'pages_base', 'procure_base.json'), encoding='utf-8'))
    out['mat'] = {'codeMix': pb['codeMix']['byProduct'], 'matCode': pb['matCode'], 'inLead': {'C': 7, 'G': 5}, 'selfLeadTeam': 8,
                  'sup': {s_['code']: [s_['name'], s_['lt'], s_['ltMed'], s_.get('ltSrc', '')] for s_ in sorted(pb['suppliers'], key=lambda z: -z['prio']) if s_['plant'] == 'C'},
                  'note': '구매 소재: 품명 → 소재 코드 비중(13주 실적) · 소재별 1순위 업체 리드타임(80%, MES 발주→입고). 입고 필요일 = 컬러 생산일 − 7일(팀 소재 리드타임 표)'}
    weeks = [d for d in IX.days() if d.weekday() == 6] + [IX.D1]
    PROF = ship_profile(ex)
    out['shipProfile'] = {g: {k: round(v, 4) for k, v in sorted(w.items())} for g, w in (PROF or {}).items()}
    out['weeks'] = [d.isoformat() for d in weeks]
    dfp = os.path.join(ROOT, 'data', 'color_downtime_2026Q4.json')            # 컬러 휴지계획(가동 현황 표에 표시)
    if os.path.exists(dfp):
        DD = json.load(open(dfp, encoding='utf-8'))
        out['colorDown'] = [[x['date'], x['line'], x['kind'], x['min']] for x in DD['items']]
        out['colorDownNotes'] = DD.get('notes', [])
    for v in ('V1', 'V2', 'V3'):
        f = os.path.join(IP.WORK, f'integ_plating_{v}.json')
        if not os.path.exists(f):
            continue
        R = json.load(open(f, encoding='utf-8'))['result']
        mv = v if v in P['masters'] else 'V1'                    # V3 는 V1 월 물량·자가재 품목 + M/C 추가 허용
        vv = variant_view(P, R, mv)
        OUT = {}
        SD = stock_daily(P, R, mv, PROF, OUT)
        M = P['masters'][mv]
        rows = []
        for g in ('C건재', 'C수출', 'G국내', 'G수출', 'G자동차'):
            rows.append({'k': g, 'v': [r0(SD[g][d.isoformat()]) for d in weeks],
                         'tgt': [r0(M['plan'][g][d.month - 10]['target']) for d in weeks], 'ss': [r0(M['plan'][g][d.month - 10].get('safety') or 0) for d in weeks]})
        for p in ('AZ', 'MAC', 'AL'):
            ser = {x[0]: x[3] for x in vv['self'][p]}
            rows.append({'k': '자가재 ' + p, 'v': [r0(ser[d.isoformat()[5:]]) for d in weeks], 'tgt': None, 'ss': [0] * len(weeks)})
        for k, nm in (('FH', 'FH(도금 소재)'), ('CMAT', '컬러 구매소재')):
            ser = {x[0]: x[4] for x in vv['mat'][k]['rows']}
            rows.append({'k': nm, 'v': [r0(ser[d.isoformat()[5:]]) for d in weeks], 'tgt': [vv['mat'][k]['target']] * len(weeks), 'ss': [0] * len(weeks),
                         'in': [r0(sum(x[2] for x in vv['mat'][k]['rows'] if (d - dt.timedelta(days=6)).isoformat()[5:] <= x[0] <= d.isoformat()[5:])) for d in weeks]})
        vv['stockWeek'] = rows
        vv['stockDay'] = {g: [r0(SD[g][d.isoformat()]) for d in IX.days()] for g in ('C건재', 'C수출', 'G국내', 'G수출', 'G자동차')}
        vv['stockTgt'] = {g: [r0(x['target']) for x in M['plan'][g]] for g in ('C건재', 'C수출', 'G국내', 'G수출', 'G자동차')}
        vv['outDay'] = {g: [r0(OUT[g][d.isoformat()]) for d in IX.days()] for g in ('C건재', 'C수출', 'G국내', 'G수출', 'G자동차')}
        vv['planVol'] = mv
        out['variants'][v] = vv
    # 비교 지표
    cmp = {}
    for v, vv in out['variants'].items():
        az = [x[3] for x in vv['self']['AZ']]
        lm = lambda l, m: vv['lineMonth'].get(f'{l}|{m}', 0)
        mc = sum(1 for c in vv['plating'] if 'M/C' in c['ev'])
        cmp[v] = {'self': [vv['plan']['G자가재'][i]['prod'] for i in range(3)], 'azMin': r0(min(az)), 'azMax': r0(max(az)),
                  'azNegDays': sum(1 for x in az if x < 0), 'util': vv['util']['G'], 'g1': [r0(lm('1CGL', m)) for m in (10, 11, 12)],
                  'g2': [r0(lm('2CGL', m)) for m in (10, 11, 12)], 'mc': mc, 'short': vv['short'], 'late': vv['late'],
                  'selfStockAvg': r0(sum(sum(x[3] for x in vv['self'][p]) for p in vv['self']) / len(az))}
    out['cmp'] = cmp
    # 추천: 컬러 소재 부족·결품·지연 없는 안 중 자가재 평균 재고 + 1CGL 월간 편차(공백)가 작은 안
    ok = [v for v, c in cmp.items() if c['azNegDays'] == 0 and c['short'] < 1 and c['late'] < 1] or list(cmp)
    score = {v: cmp[v]['selfStockAvg'] + 0.3 * (max(cmp[v]['g1']) - min(cmp[v]['g1'])) for v in ok}
    rec = min(score, key=score.get)
    if rec == 'V3' and 'V1' in score and score['V3'] > 0.95 * score['V1']:     # M/C 2회를 더 쓰는 만큼 뚜렷이 나아야 V3
        rec = 'V1'
    out['rec'] = rec
    why = {'V1': '자가재를 컬러 사용일에 맞춰 컬러 소재 부족이 없고, 도금 능력에 여유가 남음',
           'V2': '자가재계획 그대로 — 판단 근거 확인 필요',
           'V3': 'V1처럼 컬러 소재 부족이 없으면서, M/C 를 2회 더 써서 AZ 캠페인을 짧게 나눠 자가재 재고 봉우리와 12월 1CGL 공백을 줄임'}
    if rec == 'V1' and 'V3' in cmp:
        why['V1'] += f". V3(M/C +2회)는 선생산을 {1 - out['variants']['V3']['inv'] / out['variants']['V1']['inv']:.0%}만 줄이고 12월 1CGL 공백·MAC 재고 봉우리는 그대로라 M/C 비용만큼 이득이 없음"
    out['recWhy'] = f"추천 {rec}: {why.get(rec, '')}. V2 는 월말 납기라 10월 중순 컬러 AZ 소재가 모자람(최대 {-cmp['V2']['azMin']:,.0f}t)" if 'V2' in cmp and cmp['V2']['azMin'] < 0 else f"추천 {rec}: {why.get(rec, '')}"
    sf = os.path.join(IP.WORK, 'roll_sim.json')
    if os.path.exists(sf):
        out['sim'] = json.load(open(sf, encoding='utf-8'))
    # 주간 재계획(가장 최근 기록)
    rd = os.path.join(IP.WORK, 'roll')
    if os.path.isdir(rd):
        fs = sorted(x for x in os.listdir(rd) if x[:4].isdigit())
        out['rolls'] = [json.load(open(os.path.join(rd, x), encoding='utf-8'))['summary'] for x in fs]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--extra', required=True)
    ap.add_argument('--password', default=os.environ.get('CGL_ANALYSIS_PW'))
    ap.add_argument('--out', required=True)
    ap.add_argument('--plain')
    ap.add_argument('--confirmed', default='V1', help='확정안만 게시(2026-10-07 V1 확정, V2·V3 제외). 비교가 필요하면 --confirmed all')
    a = ap.parse_args()
    o = build(TB.load_extra(a.extra))
    if a.confirmed != 'all':
        confirm(o, a.confirmed)
    s = json.dumps(o, ensure_ascii=False, separators=(',', ':'))
    print('데이터', f'{len(s) / 1e6:.2f}MB')
    if a.plain:
        open(a.plain, 'w', encoding='utf-8').write(s)
    json.dump(PB.encrypt(o, a.password, '4분기 통합 일별계획'), open(a.out, 'w', encoding='utf-8'))
    print('저장', a.out)


def confirm(o, v='V1'):
    """확정안만 남기고 설명 문구를 붙임(화면 게시용). 웹 컬러 계획 계산(tools/color_calc.py)도 같은 함수를 씀"""
    o['variants'] = {v: o['variants'][v]}; o['cmp'] = {v: o['cmp'][v]}; o['rec'] = v; o['confirmed'] = v
    o['recWhy'] = '확정 계획(2026-10-07): ' + ('자가재를 컬러 사용일에 맞춰(컬러 생산일 − 8일, 10일 단위) 컬러 소재 부족이 없고, 도금 능력에 여유가 남음. 남은 과제: 12월 1CGL 공백(약 9천t) — 1월분 선생산 또는 감산 결정' if v == 'V1' else '')
    if IP.USE_R15:
        o['recWhy'] += ('. 10/12: 컬러 계획재를 계획재 운영안(TF)대로(사양·물량·라인·순서 그대로, 날짜만 월 전체에 펼침) 바꿈 — 도금은 확정 계획 유지'
                        '(운영안 수요로 다시 풀어도 M/C 7회·결품 0·지연 0, 1CGL 날짜 같음), 자가재 부족 없음')
    if os.path.exists(os.path.join(ROOT, 'data', 'color_downtime_2026Q4.json')):
        o['recWhy'] += '. 컬러 휴지계획(S/D·수리·청소·Test·샘플) 반영 — 도금 영향 없음(자가재 부족 없음)'
    o['recWhy'] += ('. 10/13: 자가재 필요일을 팀 기준(도금 생산 → 컬러 투입 8일)으로 바꿈, 10·11월 컬러는 앞날부터 꽉 채우고 월말에 휴지를 모음(가전내수 날짜 고정·구매 소재 입고일 확인), '
                    '12월은 그대로(월말 휴지는 AZ 자가재 부족을 키우고 중순 휴지는 수출·주문재 납기를 늦춤). 도금 재계획은 자가재 납기를 컬러 필요일 기준 반순으로 앞당김 — 직판재 지연·결품 0, M/C 그대로')
    o['recWhy'] += ('. 10/20 재계산: 2CCL 10/16~29 휴지(사용자), 지난달 미편성은 다음 달 1일부터 먼저(이월 — 10월 못 만든 컬러 11월 초로), '
                    '이번 달 실적은 실제 그룹(가전수출·가전내수 = MES 주문 수출 구분)에서 차감')
    o['recWhy'] += ('. 10/20 도금 확정 계획을 실제 상태에서 다시 계산: 현장은 1CGL 10/14 AZ→AL, 2CGL 10/15 AL→MAC 로 전환(지난 확정안과 다름), '
                    '10/19까지 실적 30,570t 빼고 지금 강종에서 출발 — 남은 M/C 8회(1CGL 10/30·11/12·12/8·12/19, 2CGL 10/26·11/16·12/11·12/28, 최소 증명), '
                    '결품 0, 지연 303톤·일(10/20 마감 도금수출 AL 303t 하루 늦음 — 10월 수출 실적이 계획보다 약 1,200t 적었던 몫)')
    return o


if __name__ == '__main__':
    main()
