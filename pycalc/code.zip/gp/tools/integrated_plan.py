"""4분기 통합 일별 가동계획 (컬러 → 자가재 → 도금 → 소재), 자가재 기준 두 가지
  V1 calc : 자가재 = 컬러 일별 계획에서 거꾸로 계산(품명별 자가재 비중·강종, 필요일 = 컬러 생산일 − 8일)
  V2 plan : 자가재 = 자가재계획 파일 그대로
공통: 월 물량 = tools/master_plan.py LP(그룹별 생산량), 컬러 일별 = cglplan.color_full 스케줄러(라인 한도 = 하루 1,440분 − 휴지계획, 월차 한도 없음),
      도금 일별 = cglplan MILP(판매계획 품목에 재고 보충·감축분 반영), 소재 = 일별 사용량에서 입고기한·발주일 역산

단계
  python tools/integrated_plan.py prep  --extra X --mesdata Y            → work/integ_prep.json, work/integ_items_V1.json, _V2.json
  python tools/integrated_plan.py plating --variant V1 [--threads 2]     → work/integ_plating_V1.json (MILP 15~40분)
  python tools/integrated_plan.py excel --variant V1                     → outputs/통합_일별가동계획_2026Q4_V1.xlsx
"""
import argparse, calendar, copy, datetime as dt, json, os, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from cglplan import color as CL, color_full as CF  # noqa: E402
from cglplan import tables as TB
import master_plan as MP  # noqa: E402
import salesrpt  # noqa: E402

WORK = os.path.join(ROOT, 'work')
SALES = os.path.join(ROOT, 'data', 'color', 'TF_컬러도금_일별가동계획_26.10-27.3.xlsx')
EOQ = os.path.join(ROOT, 'data', 'color', 'TF_계획재_사양별_EOQ_추천반순_요약.xlsx')
REF = os.path.join(ROOT, 'data', 'color', '컬러_계획재_일별계획_산출기준.xlsx')
PLAT_IN = [os.path.join(ROOT, 'data', 'ctx_가동_판매자가재.xlsx'), os.path.join(ROOT, 'data', 'ctx_배선일정분석.xlsx')]
Q = [(2026, 10), (2026, 11), (2026, 12)]
USE_R15 = os.environ.get('CGL_R15', '1') != '0'                     # 계획재 = TF 계획재 운영안 R15(사양·물량·라인·순서), 날짜만 펼침 (2026-10-12 사용자 결정 a)
PACK = os.environ.get('CGL_PACK', '1') != '0'                     # 10·11월 컬러 몰기(월말 휴지, 2026-10-13 사용자 결정) — tools/color_pack.py
SELF_LEAD = 8                    # 자가재 필요일 = 컬러 생산일 − 8일(팀 리드타임 표 2026-10-12: 도금 생산 → 컬러 입고 +1일 → 투입 +7일. MES 실측 중앙값 9일)
CLS_GROUP = {'도금국내': 'G국내', '도금수출': 'G수출', '자동차내수': 'G자동차', '자동차수출': 'G자동차', '자가재': 'G자가재'}
ALLOY_POOL = {'AZ': 'AZ', 'MAC': 'MAC', 'AL': 'AL', 'AL-LG': 'AL'}


def f(x):
    return float(x) if isinstance(x, (int, float)) else 0.0


# ================================================================ 컬러 10~12월

_AG = {}


def act_grouper(T):
    """컬러 실적 코일 → 계획 그룹 — 규칙은 cglplan.pages.color_grouper 한 곳(사내 PC 매일 갱신과 같은 정의)"""
    if id(T) in _AG:
        return _AG[id(T)]
    from cglplan import pages as PG
    if not USE_R15:
        raise RuntimeError('R15(계획재 운영안) 없이 실적 분류는 지원하지 않음')
    _AG[id(T)] = PG.color_grouper(T)
    return _AG[id(T)]

def color_quarter(ex, master, prev=None, down=None):
    """prev: 지난 컬러 계획(color_quarter 결과) — 로트를 지난 자리에 먼저 둠. down: {(YYYY-MM-DD, 라인): 막을 분} 설비 정지 가정(실험용)"""
    T = ex['tables']
    SR = salesrpt.summary(T['snap_salesrpt'])
    mp = CL.month_plan_from_salesrpt(SR)
    asof = dt.date.fromisoformat((SR.get('asOf') or '2026-10-01')[:10])
    tb = CL.load_speed_table(REF)
    dest = CF.load_export_dest(SALES)
    plan = master['plan']
    spec_stock, smon = CL.stock_by_spec(CL.load_specs(EOQ), T['snap_stock'])
    from cglplan import r15 as R15
    R15B = R15.load() if USE_R15 else None                       # TF 계획재 운영안(R15): 계획재 사양·물량·라인·순서·교체시간
    out = []
    for mi, (y, m) in enumerate(Q):
        nd = calendar.monthrange(y, m)[1]
        ym = f'{y}-{m:02d}'
        ny, nm = (y + 1, 1) if m == 12 else (y, m + 1)
        next_ym, nd_next = f'{ny}-{nm:02d}', calendar.monthrange(ny, nm)[1]
        sd = asof.day if (asof.year, asof.month) == (y, m) else 1
        d1 = (dt.date(2026, 10, 1) - dt.timedelta(days=1)).isoformat()
        d0 = (dt.date.fromisoformat(d1) - dt.timedelta(days=91)).isoformat()
        specs = CL.load_specs(EOQ)
        act = CL.actual_stats(specs, T['color_prod'], d0, d1)
        act['share'] = {l: (0.0 if l == '3CCL' else 1.0) for l in CL.LINES}
        dact, made = CL.actual_days(specs, T['color_prod'], y, m, sd)
        PR = CL.plan(specs, spec_stock, mp, act, tb, y, m, start_day=sd, made_before=made)
        occ, plan_t_line, plan_t = Counter(), Counter(), Counter()
        for x in PR['lots']:
            a, b = x['startH'] - x['coMin'] / 60, x['endH']
            while a < b - 1e-9:
                d = int(a // 24) + 1
                e = min(b, d * 24)
                occ[(min(d, nd), x['line'])] += (e - a) * 60
                a = e
            plan_t_line[x['line']] += x['t']
            plan_t[x['spec']['id']] += x['t']
        nxt_stock = {s['id']: max(0.0, s['stock0'] + s['madeBefore'] + plan_t[s['id']] - s['demand']) for s in specs}
        plan_total = sum(plan_t.values()) + sum(s['madeBefore'] for s in specs)
        r15_rows, r15_left, r15_over = None, None, []
        dmon = {(int(ds_[8:]), l_): mn for (ds_, l_), mn in (down or {}).items() if ds_.startswith(ym + '-')}
        if R15B and ym in R15B:                                  # R15 로 계획재 대체: 이번 달 남은 배치(R15 날짜 ≥ 시작일). 배치는 다른 그룹을 넣은 뒤 남은 시간에(L-21, 아래)
            r15_left = R15.remaining(R15B[ym], R15.done_by_spec(R15B[ym], T['color_prod'], ym, sd)) if sd > 1 else R15B[ym]   # 이번 달: 사양별 R15 물량 − 실적
            occ = Counter(dmon)                                  # 계획 휴지(S/D·수리 등)는 그 날 시간을 먼저 막음
            plan_total = sum(b['t'] for bs in R15B[ym].values() for b in bs)
        # 판매계획 행 필요량(재고 반영) → 그룹 월 물량(LP)에 맞춰 배분
        sales = CF.load_sales(SALES)
        pools, _ = CF.stock_pools(T['snap_stock'], specs, smon)
        spec_dem = Counter()
        for s in specs:
            spec_dem[(s['name'], '(MAC' in str(s['nameMat']))] += s['demand']
        CF.needs(sales, pools if mi == 0 else Counter(), ym, nd_next, next_ym, spec_dem)
        fam = lambda g: {'주문재': 'C건재', '수요개발': 'C수요'}.get(g, 'C수출')
        tgt = {'C건재': max(0.0, plan['C건재'][mi]['prod'] - plan_total), 'C수출': plan['C수출'][mi]['prod'], 'C수요': plan['C수요'][mi]['prod']}
        # 다음 달 1~5일 벌크 선적분(전월 말 선생산)은 이번 달 물량 안에서 먼저 떼어 둠
        pre = Counter()
        for r in sales:
            r['preNext'] = 0.0
            if r['group'] in ('건재수출', '가전수출') and r['salesNext']:
                for dd, ship, due, bulk, w in dest.get((r['group'], r['product'], r['region'], next_ym)) or []:
                    if due == -1:
                        r['preNext'] += r['salesNext'] * w
            pre[fam(r['group'])] += r['preNext']
        for g in tgt:
            rs = [r for r in sales if fam(r['group']) == g]
            wkey = 'need' if mi == 0 and sum(r['need'] for r in rs) > 0 else 'salesM'
            tot = sum(r[wkey] for r in rs)
            rest = max(0.0, tgt[g] - pre[g])
            k_pre = min(1.0, tgt[g] / pre[g]) if pre[g] else 1.0
            for r in rs:
                r['preNext'] *= k_pre
                r['need'] = rest * r[wkey] / tot if tot else 0.0
        # 이번 달 실적(계획재 제외) 차감
        cd, mt = CL._codes(), CL.Matcher(specs)
        done, done_line = Counter(), Counter()
        for row in T['color_prod']['rows']:
            x = dict(zip(T['color_prod']['columns'], row))
            if not x['PRD_DT'].startswith(ym + '-') or int(x['PRD_DT'][8:]) >= sd:
                continue
            t = f(x['PDT_WGT']) / 1000
            done_line[x['LINE']] += t
            dept = str(x['DEPT'] or '')
            if dept.startswith('컬러건재') and mt(x['PDT_NM'], f(x['REAL_MSR_THK']), f(x['PDT_WDT']), x['SUR_FINISH_CD']):
                continue                                             # 계획재 = 컬러건재 부서 + 운영안 사양(cglplan.pages.color_grouper 와 같은 정의). 수출 코일은 사양이 같아도 수출 실적
            p = CF.base_name((cd.get(x['PDT_NM']) or {}).get('name', x['PDT_NM']))[0]
            done[('주문재' if dept.startswith('컬러건재') else ('수요개발' if dept.startswith('수요') else '수출'), p)] += t
        for r in sales:
            fm = '수출' if r['group'] in ('건재수출', '가전수출', '가전내수') else r['group']
            tot = sum(z['need'] for z in sales if z['product'] == r['product'] and ('수출' if z['group'] in ('건재수출', '가전수출', '가전내수') else z['group']) == fm)
            r['doneM'] = done[(fm, r['product'])] * (r['need'] / tot if tot else 0)
            r['needLeft'] = max(0.0, r['need'] - r['doneM'])
        # 품명이 판매계획 행과 안 맞는 실적(예: 판매계획에 없는 품명·계획 초과분)도 같은 계열 수요에서 뺌(남은 필요량 비례).
        # 안 빼면 이번 달 실적 시간은 이미 썼는데 수요는 그대로 남아 '미편성'이 부풀음(2026-10: 비계획재 실적 6,404t 중 4,085t만 차감 → 미편성 4,009t)
        FM = lambda z: '수출' if z['group'] in ('건재수출', '가전수출', '가전내수') else z['group']
        for fm in {FM(z) for z in sales}:
            rs = [z for z in sales if FM(z) == fm]
            resid = sum(v for (g_, p_), v in done.items() if g_ == fm) - sum(z['need'] - z['needLeft'] for z in rs)
            pool = sum(z['needLeft'] for z in rs)
            if resid > 0.5 and pool > 0:
                k_ = min(1.0, resid / pool)
                for z in rs:
                    z['doneM'] += z['needLeft'] * k_
                    z['needLeft'] *= 1 - k_
        cap = {l: float('inf') for l in CL.LINES}               # 2026-10-16 사용자: 월차로 라인 한도를 두지 않음 — 하루 1,440분(− 휴지계획)에 만들 수 있는 만큼(시간 한도는 schedule 의 free 분)
        lots = make_lots(sales, dest, ym, nd, sd, next_ym)
        thr = CF.thr_table(T['color_prod'], d0, d1)
        if r15_rows is None:                                     # (계획재 운영안을 쓰면 위에서 이미 막음)
            for k, mn in dmon.items():
                occ[k] += mn
        pref = None
        if prev:
            pref = defaultdict(list)
            for Mp in prev:
                if Mp['ym'] == ym:
                    for r in Mp['rows']:
                        if r.get('key'):
                            pref[r['key']].append((r['day'], r['line']))
        placed, unplaced, used = CF.schedule(lots, thr, cap, occ, nd, sd, pref)
        if r15_left is not None:                                 # 계획재 = 4순위(2026-10-17 사용자, L-21): 수출·가전내수·수요개발·주문재를 넣고 남은 1,440분에 운영안 순서대로
            blk = Counter(occ)
            for p in placed:
                blk[(p['day'], p['line'])] += p['min']
            r15_rows, occ15 = R15.place(r15_left, nd, sd, blk, over=r15_over)
            plan_t_line = Counter()
            for x in r15_rows:
                plan_t_line[x['line']] += x['t']
        # 실적(1 ~ sd−1일): 품명·부서 단위
        act_rows = []
        AG = act_grouper(T)
        for row in T['color_prod']['rows']:
            x = dict(zip(T['color_prod']['columns'], row))
            if x['PRD_DT'].startswith(ym + '-') and int(x['PRD_DT'][8:]) < sd:
                cust = str(x.get('CUST_NM') or x.get('CUSTOMER') or '')
                g = AG(x)
                act_rows.append({'day': int(x['PRD_DT'][8:]), 'line': x['LINE'], 'group': g, 'product': CF.base_name((cd.get(x['PDT_NM']) or {}).get('name', x['PDT_NM']))[0],
                                 'cust': cust, 't': f(x['PDT_WGT']) / 1000, 'raw': str(x['RAW_NO']), 'rawT': f(x['RAW_TRE_WGT']) / 1000, 'act': True,
                                 'min': f(x['WRK_TIME']) + f(x['PAU_TIME'])})
        rows = []
        for x in (r15_rows or []):
            b = x['batch']
            rows.append({'day': x['day'], 'line': x['line'], 'group': '계획재', 'product': b['product'], 'spec': b['spec'], 'cust': '', 'dest': '', 'ship': '운영안',
                         'due': None, 't': x['t'], 'min': x['min'], 'tph': x['t'] / x['min'] * 60 if x['min'] else None, 'mat': b['mat'],
                         'note': f"계획재 운영안 배치 {b['id']} · 소재 {b['mat']} · 순서·교체시간 운영안 준수"})
        for x in ([] if r15_rows is not None else PR['lots']):
            rows.append({'day': x['day0'], 'line': x['line'], 'group': '계획재', 'product': x['spec']['name'], 'spec': x['spec']['spec'], 'cust': '',
                         'dest': '', 'ship': f"{x['bankPlan']}반순", 'due': None, 't': x['t'], 'min': x['runH'] * 60 + x['coMin'], 'tph': x['tph'],
                         'note': f"속도 {x['mpm']:.0f}mpm+교체 {x['coMin']:.0f}분"})
        for p in placed:
            lo, rw = p['lot'], p['lot']['row']
            rows.append({'day': p['day'], 'line': p['line'], 'group': lo['group'], 'product': rw['product'] + ('(MAC)' if rw.get('mac') else ''),
                         'base': rw['product'], 'spec': rw['region'] or rw['customer'], 'cust': rw['customer'] or rw['region'], 'dest': lo['dest'], 'ship': lo['ship'],
                         'due': lo['due'] if lo['group'] in ('건재수출', '가전수출') else None, 't': p['t'], 'min': p['min'], 'tph': p['tph'],
                         'note': '완료기한 경과' if p['late'] else ('선행 생산' if p['early'] else ''), 'key': CF.lot_key(lo)})
        out.append({'year': y, 'month': m, 'ym': ym, 'ndays': nd, 'startDay': sd, 'monthPlan': mp, 'rows': rows, 'act': act_rows,
                    'unplaced': [{'group': x['group'], 'product': x['row']['product'], 'cust': x['row']['region'] or x['row']['customer'], 'dest': x['dest'],
                                  'due': x['due'], 't': left} for x, left in unplaced]
                                + [{'group': '계획재', 'product': o['batch']['product'], 'cust': o['batch']['spec'], 'dest': '', 'due': None, 't': o['t']} for o in r15_over],
                    'target': tgt, 'pre': dict(pre), 'planTotal': plan_total, 'doneLine': dict(done_line), 'planTLine': dict(plan_t_line),
                    'groupDone': {g: sum(r['doneM'] for r in sales if fam(r['group']) == g) for g in tgt},
                    'specStock0': sum(s['stock0'] for s in specs), 'specTarget': sum(s['target'] for s in specs),
                    'sales': [{'group': r['group'], 'product': r['productRaw'], 'cust': r['region'] or r['customer'], 'salesM': r['salesM'], 'salesNext': r['salesNext'],
                               'need': r['need'], 'preNext': r['preNext'], 'doneM': r['doneM'], 'needLeft': r['needLeft']} for r in sales],
                    'warns': PR['warns'][:3]})
        spec_stock = nxt_stock
    return out


def make_lots(sales, dest, ym, ndays, start_day, next_ym):
    """CF.make_lots 와 같되, 다음 달 1~5일 벌크분은 r['preNext'](이미 월 물량 안) 만큼 월말 10일에, 이번 달 1~5일 벌크분은 지난달에 만든 것으로 보고 뺌"""
    lots = []
    for r in sales:
        if r.get('preNext', 0) < 0.5:
            continue
        ds = [(d, s, w) for d, s, due, bulk, w in dest.get((r['group'], r['product'], r['region'], next_ym)) or [] if due == -1]
        tw = sum(w for *_, w in ds) or 1
        for d, ship, w in ds:
            q = r['preNext'] * w / tw
            n = max(1, min(4, round(q / 400)))
            for k in range(n):
                lots.append({'row': r, 'group': r['group'], 'dest': d, 'ship': ship + ' (다음달 1~5일 선적분 선생산)', 't': q / n,
                             'release': max(start_day, ndays - 9), 'due': ndays, 'prio': CF.PRIORITY['수출벌크'], 'k': k + 1})
    for r in sales:
        need = r['needLeft']
        if need < 1:
            continue
        g = r['group']
        if g in ('건재수출', '가전수출'):
            ds = [x for x in (dest.get((g, r['product'], r['region'], ym)) or []) if x[2] != -1] or [('미정', '', None, False, 1.0)]
            tw = sum(x[4] for x in ds) or 1
            for d, ship, due, bulk, w in ds:
                q = need * w / tw
                if q < 0.5:
                    continue
                if due:
                    due = max(due, start_day)
                    n = max(1, min(4 if bulk else CF.LOT_MAX[g], round(q / (400 if bulk else CF.LOT_T[g]))))
                    for k in range(n):
                        lots.append({'row': r, 'group': g, 'dest': d, 'ship': ship, 't': q / n, 'release': max(start_day, due - 10),
                                     'due': due, 'prio': CF.PRIORITY['수출벌크' if bulk else '수출'], 'k': k + 1})
                else:
                    lots += CF._even(r, g, q, ndays, start_day, CF.PRIORITY['수출'], d, ship)
        else:
            lots += CF._even(r, g, need, ndays, start_day, CF.PRIORITY[g], '', '')
    return lots


# ================================================================ 자가재 (V1: 컬러 계획에서 역산)
def self_usage(color, sub, alloy_of_coil):
    """컬러 일별(실적 + 계획) → 자가재 사용 (일자, 구역, 강종) t. 실적은 RAW_NO 로 실제 강종, 계획은 품명별 비중"""
    U = Counter()
    for M in color:
        for r in M['act']:
            if r['raw'][:2] in ('AA', 'BA'):
                a = alloy_of_coil.get(r['raw'], None)
                a = 'AL' if a == 'AL-STS' else a
                sec = MP.SECTION.get(r['group'], '컬러건재')
                if a is None:
                    for (s2, a2), v in MP.self_alloy(sub, r['product'], r['cust'], r['group']).items():
                        U[(dt.date(M['year'], M['month'], r['day']), s2, a2)] += r['rawT'] * v / max(1e-9, sum(MP.self_alloy(sub, r['product'], r['cust'], r['group']).values()))
                else:
                    U[(dt.date(M['year'], M['month'], r['day']), sec, a)] += r['rawT']
        for r in M['rows']:
            d = dt.date(M['year'], M['month'], r['day'])
            if r.get('mat'):                                       # R15 계획재: 소재발주구분으로 확정 — 수입 FH·P-FH = 도금 자가재(MAC 품명이면 MAC, 아니면 AZ), GI = 구매
                if r['mat'].replace(' ', '') in ('수입FH', 'P-FH'):
                    U[(d, MP.SECTION['계획재'], 'MAC' if 'MAC' in r['product'] else 'AZ')] += r['t'] / MP.COLOR_YIELD
                continue
            base = r.get('base') or CF.base_name(r['product'])[0]
            for (sec, a), v in MP.self_alloy(sub, base, r.get('cust') or '', r['group']).items():
                U[(d, sec, a)] += r['t'] * v / MP.COLOR_YIELD
    return U


def self_items(U, begin_by_alloy, target_days, month_totals=None):
    """반순(1~10·11~20·21~말) 끝을 납기로 하는 자가재 품목. 필요일 = 컬러 생산일 − 8일.
    누적 필요생산 R(t) = max(0, 누적 사용(t) + 목표재고(일 × 이후 10일 하루 사용) − 기초재고), 품목 = 반순별 R 증가분.
    month_totals 를 주면 월 합계를 LP 자가재 생산량에 맞춤"""
    need = Counter()                                             # (납기일, 구역, 강종)
    use_by = defaultdict(Counter)                                # 풀(강종) → 필요일 → t
    secmix = defaultdict(Counter)                                # (풀, 반순 끝) → (구역, 강종) → t
    ends = []
    for y, m in Q:
        nd = calendar.monthrange(y, m)[1]
        ends += [dt.date(y, m, 10), dt.date(y, m, 20), dt.date(y, m, nd)]
    start = dt.date(2026, 10, 1)
    for (d, sec, a), t in U.items():
        nd_ = max(start, d - dt.timedelta(days=SELF_LEAD))
        use_by[ALLOY_POOL[a]][nd_] += t
        e = next((e for e in ends if nd_ <= e), ends[-1])
        secmix[(ALLOY_POOL[a], e)][(sec, a)] += t
    for pool, ser in use_by.items():
        prevR = 0.0
        B = begin_by_alloy.get(pool, 0.0)
        for i, e in enumerate(ends):
            cum = sum(v for d, v in ser.items() if d <= e)
            nxt = [v for d, v in ser.items() if e < d <= e + dt.timedelta(days=10)]
            rate = sum(nxt) / 10 if nxt else (sum(v for d, v in ser.items() if e - dt.timedelta(days=10) < d <= e) / 10)
            R = max(0.0, cum + target_days * rate - B)
            inc = max(0.0, R - prevR)
            prevR = max(prevR, R)
            mix = secmix.get((pool, e)) or Counter({('컬러건재', pool): 1})
            tot = sum(mix.values())
            if tot <= 1e-9:                                      # 그 반순 사용량 합이 0(소수 행만 남음) → 기본 비중
                mix, tot = Counter({('컬러건재', pool): 1}), 1
            for (sec, a), v in mix.items():
                need[(e, sec, a)] += inc * v / tot
    if month_totals:
        mt = Counter()
        for (e, s, a), v in need.items():
            mt[e.month] += v
        for k in list(need):
            tgt = month_totals.get(k[0].month)
            if tgt is not None and mt[k[0].month]:
                need[k] *= tgt / mt[k[0].month]
    items = []
    for (e, sec, a), v in sorted(need.items()):
        if v < 1:
            continue
        mi = Q.index((e.year, e.month))
        items.append({'cls': '자가재', 'alloy': a, 'mi': mi, 'month': e.month, 'year': e.year, 'dest': sec, 'port': '',
                      'window': f"{(e.day - 1) // 10 * 10 + 1}~{e.day}일", 'due': e.isoformat(), 'tons': round(v, 1)})
    return items


def begin_self_by_alloy(ex, specs):
    from tf_rerun import pools_from_stock
    P, _ = pools_from_stock(ex['tables']['snap_stock'], specs)
    B = Counter()
    for k, v in P.items():
        if k[0] == '자가재':
            B[{'AZ': 'AZ', 'PosMAC': 'MAC'}.get(k[2], 'AL')] += v
    return B


# ================================================================ 도금 품목
def plating_items(base_items, master, self_items_v1=None):
    """판매계획 품목 × LP 그룹 물량. 늘릴 때는 늘어난 만큼 같은 목적지에 '재고 보충'(납기 월말) 품목 추가, 줄일 때는 비례 감축"""
    plan = master['plan']
    sales = Counter()
    for x in base_items:
        if x['cls'] != '자가재':
            sales[(CLS_GROUP[x['cls']], x['mi'])] += x['tons']
    fac = {(g, mi): plan[g][mi]['prod'] / v for (g, mi), v in sales.items() if v}
    out = []
    for x in base_items:
        if x['cls'] == '자가재':
            if self_items_v1 is None:
                out.append(dict(x))
            continue
        k = fac.get((CLS_GROUP[x['cls']], x['mi']), 1.0)
        if k <= 1:
            y = dict(x); y['tons'] = x['tons'] * k
            out.append(y)
        else:
            out.append(dict(x))
            y = dict(x)
            nd = calendar.monthrange(x['year'], x['month'])[1]
            y.update({'tons': x['tons'] * (k - 1), 'due': f"{x['year']}-{x['month']:02d}-{nd}", 'window': None, 'port': '재고 보충'})
            out.append(y)
    if self_items_v1 is not None:
        out += self_items_v1
    return [x for x in out if x['tons'] >= 0.5], fac


DOWN_FILE = os.path.join(ROOT, 'data', 'color_downtime_2026Q4.json')


def color_down(ex):
    """컬러 휴지계획(data/color_downtime_2026Q4.json, tools/color_downtime.py) → {(날짜, 라인): 막을 분}, 실적 다음 날부터.
    계획휴지·S/D·수리 = 그대로, 청소·Test·샘플 = 지난 3개월 월평균을 넘는 만큼만(실적 t/hr 에 평균 정지가 이미 들어 있음)"""
    if not os.path.exists(DOWN_FILE) or os.environ.get('CGL_DOWN') == '0':
        return None
    import color_downtime as CD
    T = ex['tables']
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else {}
    start = (SR.get('asOf') or '2026-10-01')[:10]
    D = json.load(open(DOWN_FILE, encoding='utf-8'))
    out, excess = CD.blocks(D['items'], CD.history(T), start)
    print('컬러 휴지계획', start, '이후 막는 분', {l: round(sum(v for (d, ll), v in out.items() if ll == l)) for l in CL.LINES},
          '· 평소 정지 초과분', [e for e in excess if e[5] > 0])
    return out


# ================================================================ prep
def prep(ex, md):
    from cglplan import parse, util as U
    res = {}
    masters = {v: MP.run(ex, md, mode) for v, mode in (('V1', 'calc'), ('V2', 'plan'))}
    pf = os.path.join(WORK, 'integ_prep.json')
    prev = json.load(open(pf, encoding='utf-8'))['color'] if os.path.exists(pf) else None   # 지난 컬러 계획 자리 우선(재계산해도 일정이 덜 바뀌게)
    cdown = color_down(ex)
    color = color_quarter(ex, masters['V1'], prev=prev, down=cdown)   # 컬러는 두 안 공통(자가재 기준과 무관)
    sub = masters['V1']['measure']['substrate']
    pack_sum = None
    if PACK:                                                     # 10·11월 몰기(월말 휴지) — tools/color_pack.py
        import color_pack as CPK
        from cglplan import pages as PG
        T = ex['tables']
        SR = salesrpt.summary(T['snap_salesrpt'])
        today = (SR.get('asOf') or '2026-10-01')[:10]
        cmix = ((PG.load_base('procure_base.json') or {}).get('codeMix') or {}).get('byProduct') or {}
        mix_of = lambda b: cmix.get(b) or next((v for k, v in cmix.items() if k[:3] == b[:3]), {})
        self_of = lambda b, c, g: sum(MP.self_alloy(sub, b, c, g).values())
        pack_sum = CPK.pack(color, cdown, CPK.supply_from(T, today), self_of, mix_of, MP.COLOR_YIELD)
        print('컬러 몰기', {ym: {l: (v['movedT'], v['partBefore'], v['partAfter'], f"{v['idle'][0]}~{v['idle'][-1]}" if v['idle'] else '-') for l, v in L.items()} for ym, L in pack_sum.items()})
    alloy_of = {dict(zip(md['coilCols'], c))['id']: dict(zip(md['coilCols'], c))['alloy'] for c in md['coils']}
    Uu = self_usage(color, sub, alloy_of)
    specs = CL.load_specs(EOQ)
    Bself = begin_self_by_alloy(ex, specs)
    m1 = masters['V1']
    sitems = self_items(Uu, Bself, m1['targets']['G자가재']['days'], {Q[i][1]: m1['plan']['G자가재'][i]['prod'] for i in range(3)})
    P = U.default_params()
    base = parse.parse_inputs(parse.load_workbooks(PLAT_IN), P)['items']
    for v in ('V1', 'V2'):
        items, fac = plating_items(base, masters[v], sitems if v == 'V1' else None)
        json.dump(items, open(os.path.join(WORK, f'integ_items_{v}.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        res[v] = {'factor': {f'{g}|{mi}': k for (g, mi), k in fac.items()}, 'nItems': len(items),
                  'tons': {f'{c}|{m}': t for (c, m), t in Counter({(x['cls'], x['month']): 0 for x in items}).items()}}
        tons = Counter()
        for x in items:
            tons[(x['cls'], x['month'])] += x['tons']
        res[v]['tons'] = {f'{c}|{m}': t for (c, m), t in tons.items()}
    out = {'masters': masters, 'color': color, 'selfUse': [[d.isoformat(), s, a, t] for (d, s, a), t in sorted(Uu.items())],
           'selfBegin': dict(Bself), 'selfItemsV1': sitems, 'baseItems': base, 'variants': res, 'colorPack': pack_sum, 'selfLead': SELF_LEAD}
    json.dump(out, open(os.path.join(WORK, 'integ_prep.json'), 'w', encoding='utf-8'), ensure_ascii=False, default=str)
    return out


VARIANT_SRC = {'V3': ('V1', {'mcExtra': 2})}      # V3 = V1 자가재 품목 + M/C 2회 추가 허용(AZ 캠페인을 짧게 나눠 재고·공백 축소)


def plating(variant, threads=2):
    from cglplan import model, util as U, publish as PB
    import time
    P = U.default_params()
    src, over = VARIANT_SRC.get(variant, (variant, {}))
    P.update(over)
    items = json.load(open(os.path.join(WORK, f'integ_items_{src}.json'), encoding='utf-8'))
    t0 = time.time()
    R = model.run_plan(items, P, lambda m: print(f'[{time.time() - t0:5.0f}s] {m}', flush=True), threads=threads)
    json.dump(PB.pack(R, {'variant': variant}), open(os.path.join(WORK, f'integ_plating_{variant}.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    print('저장', variant)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', choices=['prep', 'plating', 'excel'])
    ap.add_argument('--extra')
    ap.add_argument('--mesdata')
    ap.add_argument('--variant', default='V1')
    ap.add_argument('--threads', type=int, default=2)
    a = ap.parse_args()
    if a.cmd == 'prep':
        o = prep(TB.load_extra(a.extra), json.load(open(a.mesdata, encoding='utf-8')))
        for M in o['color']:
            tot = Counter()
            for r in M['rows']:
                tot[r['line']] += r['t']
            print(M['ym'], '라인', {l: round(tot[l] + M['doneLine'].get(l, 0)) for l in CL.LINES}, '미편성', round(sum(u['t'] for u in M['unplaced'])))
        for v, x in o['variants'].items():
            print(v, {k: round(t) for k, t in sorted(x['tons'].items())})
        print('V1 자가재 품목', len(o['selfItemsV1']), 'by month', Counter({x['month']: 0 for x in o['selfItemsV1']}))
    elif a.cmd == 'plating':
        plating(a.variant, a.threads)
    else:
        import integrated_excel as IX
        print('저장:', IX.build(a.variant))


if __name__ == '__main__':
    main()
