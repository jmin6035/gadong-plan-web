"""통합 일별 가동계획 엑셀 (tools/integrated_plan.py excel 에서 호출)
시트: 요약 · 월간수급 · 컬러 일별 · 도금 일별 · 자가재 · 소재 일별수급 · 컬러 상세 · 도금 상세 · 점검
"""
import calendar, datetime as dt, json, os, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from cglplan import color as CL, color_full as CF  # noqa: E402
import master_plan as MP  # noqa: E402
import integrated_plan as IP  # noqa: E402

WD = '월화수목금토일'
CG = ['계획재', '주문재', '건재수출', '가전수출', '가전내수', '수요개발']
PCLS = ['도금국내', '도금수출', '자동차내수', '자동차수출', '자가재']
D0, D1 = dt.date(2026, 10, 1), dt.date(2026, 12, 31)
VNAME = {'V1': 'V1 자가재 = 컬러 계획에서 계산', 'V2': 'V2 자가재 = 자가재계획 파일 유지'}


def days():
    d = D0
    while d <= D1:
        yield d
        d += dt.timedelta(days=1)


def load(variant):
    P = json.load(open(os.path.join(IP.WORK, 'integ_prep.json'), encoding='utf-8'))
    R = json.load(open(os.path.join(IP.WORK, f'integ_plating_{variant}.json'), encoding='utf-8'))['result']
    return P, R


# ------------------------------------------------------------------ 계산
def color_daily(P):
    """(일자, 라인) → {그룹: t}, 품명 목록, 분 ; 실적일은 부서 기준"""
    T, names, mins = defaultdict(Counter), defaultdict(list), Counter()
    act_days = set()
    for M in P['color']:
        y, m = M['year'], M['month']
        for r in M['act']:
            d = dt.date(y, m, r['day'])
            act_days.add(d)
            T[(d, r['line'])][r['group']] += r['t']
        for r in M['rows']:
            d = dt.date(y, m, r['day'])
            T[(d, r['line'])][r['group']] += r['t']
            mins[(d, r['line'])] += r['min'] or 0
            if r['product'] not in names[(d, r['line'])]:
                names[(d, r['line'])].append(r['product'])
    return T, names, mins, act_days


def plating_daily(R):
    T, alloy = defaultdict(Counter), defaultdict(Counter)
    for d, line, a, cls, t, due in R['rows']:
        T[(dt.date.fromisoformat(d), line)][cls] += t
        alloy[(dt.date.fromisoformat(d), line)][a] += t
    ev = {(dt.date.fromisoformat(c['date']), c['line']): c for c in R['cal']}
    return T, alloy, ev


def self_balance(P, R):
    """자가재 강종 풀별 일별: 필요(컬러 생산일 − 8일) · 도금 생산 · 재고(9월말 자가재 재고에서 시작)"""
    use = defaultdict(Counter)
    for d, sec, a, t in P['selfUse']:
        dd = max(D0, dt.date.fromisoformat(d) - dt.timedelta(days=IP.SELF_LEAD))
        use[IP.ALLOY_POOL[a]][dd] += t
    prod = defaultdict(Counter)
    for d, line, a, cls, t, due in R['rows']:
        if cls == '자가재':
            prod[IP.ALLOY_POOL.get(a, 'AL')][dt.date.fromisoformat(d)] += t
    out = {}
    for pool in ('AZ', 'MAC', 'AL'):
        s = P['selfBegin'].get(pool, 0.0)
        rows = []
        for d in days():
            s += prod[pool][d] - use[pool][d]
            rows.append((d, use[pool][d], prod[pool][d], s))
        out[pool] = rows
    return out


def materials(P, R, variant):
    """FH(도금 원소재) = 도금 생산 ÷ 실수율, 컬러 구매소재 = 컬러 생산 × (1 − 자가재 비중) ÷ 실수율.
    입고 필요(입고기한) = 재고가 목표재고 아래로 내려가지 않게 그 날까지 들어와야 할 양 = 누적 사용 + 목표재고 − 9월말 재고 의 증가분
    (목표재고 자체가 입고 지연·검사 여유를 덮는 완충), 발주일 = 입고기한 − 리드타임"""
    M = P['masters'][variant]
    sub = M['measure']['substrate']
    use = {'FH': Counter(), 'CMAT': Counter()}
    for d, line, a, cls, t, due in R['rows']:
        use['FH'][dt.date.fromisoformat(d)] += t / MP.PLATING_YIELD
    for Mo in P['color']:
        for r in Mo['act']:
            if r['raw'][:2] not in ('AA', 'BA'):
                use['CMAT'][dt.date(Mo['year'], Mo['month'], r['day'])] += r['rawT']
        for r in Mo['rows']:
            sh, _ = MP.self_of(sub, r.get('base') or CF.base_name(r['product'])[0])
            use['CMAT'][dt.date(Mo['year'], Mo['month'], r['day'])] += r['t'] * (1 - sh) / MP.COLOR_YIELD
    out = {}
    for k in ('FH', 'CMAT'):
        B, tgt, lt = M['matBegin'][k], MP.MAT_TARGET[k], MP.LT_DAYS[k]
        ds = list(days())
        cum_in, rows, stock = 0.0, [], B
        for i, d in enumerate(ds):
            cu = sum(v for x, v in use[k].items() if x <= d)
            # 목표재고: 9월말이 목표보다 많으면 바로 목표로(남는 재고부터 씀), 적으면 30일에 걸쳐 목표까지 올림
            tg_d = tgt if B >= tgt else B + (tgt - B) * min(1.0, (i + 1) / 30)
            need_in = max(0.0, cu + tg_d - B - cum_in)
            cum_in += need_in
            stock += need_in - use[k][d]
            rows.append({'d': d, 'use': use[k][d], 'in': need_in, 'order': d - dt.timedelta(days=lt), 'stock': stock})
        out[k] = {'begin': B, 'target': tgt, 'lt': lt, 'rows': rows}
    return out


# ------------------------------------------------------------------ 엑셀
def build(variant, path=None):
    import openpyxl
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter as CLx
    P, R = load(variant)
    M = P['masters'][variant]
    other = P['masters']['V2' if variant == 'V1' else 'V1']
    path = path or os.path.join(ROOT, 'outputs', f'통합_일별가동계획_2026Q4_{variant}.xlsx')
    wb = openpyxl.Workbook()
    th = Side(style='thin', color='BFBFBF')
    B = Border(left=th, right=th, top=th, bottom=th)
    HF, HF2, ACT = PatternFill('solid', fgColor='1F3864'), PatternFill('solid', fgColor='D9E1F2'), PatternFill('solid', fgColor='F2F2F2')
    WARN = PatternFill('solid', fgColor='FCE4D6')
    HFont, BOLD, GRAY = Font(color='FFFFFF', bold=True), Font(bold=True), Font(color='7F7F7F', italic=True)
    C = Alignment(horizontal='center', vertical='center', wrap_text=True)
    L = Alignment(horizontal='left', vertical='center', wrap_text=False)

    def hdr(ws, row, vals, widths=None, col=1):
        for j, v in enumerate(vals, col):
            c = ws.cell(row, j, v)
            c.fill, c.font, c.alignment, c.border = HF, HFont, C, B
        if widths:
            for j, w in enumerate(widths, col):
                ws.column_dimensions[CLx(j)].width = w

    def put(ws, row, vals, fmt='#,##0', col=1, bold=False, fill=None):
        for j, v in enumerate(vals, col):
            c = ws.cell(row, j, v)
            c.border = B
            if isinstance(v, float) or (isinstance(v, int) and j > col):
                c.number_format = fmt
            if bold:
                c.font = BOLD
            if fill:
                c.fill = fill

    cT, cN, cMin, cAct = color_daily(P)
    pT, pA, pEv = plating_daily(R)
    SB = self_balance(P, R)
    MAT = materials(P, R, variant)
    short, late = R['milp'].get('short', 0), R['milp'].get('late', 0)
    unpl = [sum(u['t'] for u in Mo['unplaced']) for Mo in P['color']]
    months = ['10월', '11월', '12월']

    # ================= 1. 요약
    ws = wb.active
    ws.title = '요약'
    ws.column_dimensions['A'].width = 16
    for j in range(2, 14):
        ws.column_dimensions[CLx(j)].width = 11
    ws['A1'] = f'2026년 4분기 컬러·도금·소재 통합 일별 가동계획 — {VNAME[variant]}'
    ws['A1'].font = Font(size=14, bold=True)
    ws['A2'] = ('월 물량 = 수급 LP(목표재고 = 생산주기/2 + 안전재고, 안전재고는 월말 효과 뺀 출고 편차) · 컬러 라인 한도 = MES 월차 · '
                '도금 = MILP(판매계획 + 재고 보충·감축) · 기초재고 = 9월말 재고현황 · 10/1~5 컬러는 실적')
    ws['A2'].font = GRAY
    r = 4
    ws.cell(r, 1, '① 공장별 월 생산 (t)').font = BOLD; r += 1
    hdr(ws, r, ['구분', '10월', '11월', '12월', '합계', '능력 대비 10월', '11월', '12월'])
    for nm, g, cap in (('컬러', ['C건재', 'C수출', 'C수요'], MP.CAP['color']), ('도금', ['G국내', 'G수출', 'G자동차', 'G자가재'], MP.CAP['plating'])):
        r += 1
        v = [sum(M['plan'][x][i]['prod'] for x in g) for i in range(3)]
        put(ws, r, [nm] + v + [sum(v)] + [v[i] / cap[i] for i in range(3)])
        for j in (6, 7, 8):
            ws.cell(r, j).number_format = '0%'
    r += 2
    ws.cell(r, 1, '② 그룹별 판매 · 생산 · 월말재고(일수) · 목표').font = BOLD; r += 1
    hdr(ws, r, ['그룹', '기초재고', '10월 판매', '생산', '월말', '11월 판매', '생산', '월말', '12월 판매', '생산', '월말', '12월말 일수', '목표 일수'])
    for g in ['C건재', 'C수출', 'C수요', 'G국내', 'G수출', 'G자동차', 'G자가재']:
        rows = M['plan'][g]
        r += 1
        vals = [g, M['begin'].get(g, 0)]
        for x in rows:
            vals += [x['sales'], x['prod'], x['end']]
        tg = M['targets'].get(g, {})
        vals += [rows[2]['endDays'], tg.get('days')]
        put(ws, r, vals)
        for j in (12, 13):
            ws.cell(r, j).number_format = '0.0'
    r += 2
    ws.cell(r, 1, '③ 자가재 두 기준 비교 (도금 자가재 생산, t)').font = BOLD; r += 1
    hdr(ws, r, ['기준', '10월', '11월', '12월', '합계', '비고'])
    v1, v2 = P['masters']['V1']['plan']['G자가재'], P['masters']['V2']['plan']['G자가재']
    r += 1; put(ws, r, ['V1 계산값'] + [x['prod'] for x in v1] + [sum(x['prod'] for x in v1), '컬러 생산 × 품명별 자가재 비중 + 목표재고 보충'])
    r += 1; put(ws, r, ['V2 자가재계획'] + [x['prod'] for x in v2] + [sum(x['prod'] for x in v2), '파일 값 그대로'])
    r += 1; put(ws, r, ['차이(V1−V2)'] + [a['prod'] - b['prod'] for a, b in zip(v1, v2)] + [sum(a['prod'] - b['prod'] for a, b in zip(v1, v2)), ''])
    r += 2
    ws.cell(r, 1, '④ 결과 점검').font = BOLD; r += 1
    mins = {k: min(x[3] for x in v) for k, v in SB.items()}
    minday = {k: min(v, key=lambda x: x[3])[0] for k, v in SB.items()}
    notes = [
        f"도금 MILP: 결품 {short:,.0f}t, 납기 지연 {late:,.0f}t·일, M/C {R['milp'].get('K')}회",
        f"컬러 미편성: 10월 {unpl[0]:,.0f}t · 11월 {unpl[1]:,.0f}t · 12월 {unpl[2]:,.0f}t (라인 전용 제약·월차 한도 안에 못 넣은 양 — '점검' 시트)",
        '자가재 재고 최저: ' + ' · '.join(f"{k} {mins[k]:,.0f}t({minday[k].month}/{minday[k].day})" for k in mins) + ' — 음수면 컬러 투입 전에 도금이 못 대는 날',
        f"소재 FH: 9월말 {MAT['FH']['begin']:,.0f}t → 목표 {MAT['FH']['target']:,.0f}t, 4분기 입고 필요 {sum(x['in'] for x in MAT['FH']['rows']):,.0f}t, "
        f"첫 입고 필요일 {next((x['d'] for x in MAT['FH']['rows'] if x['in'] > 1), '-')}",
        f"컬러 구매소재: 9월말 {MAT['CMAT']['begin']:,.0f}t → 목표 {MAT['CMAT']['target']:,.0f}t, 4분기 입고 필요 {sum(x['in'] for x in MAT['CMAT']['rows']):,.0f}t",
        '발주일이 오늘(10/6) 이전인 입고분은 이미 발주돼 있어야 하는 양 — 기발주 자료와 맞춰 볼 것(소재 시트)',
    ]
    for t in notes:
        ws.cell(r, 1, t); r += 1
    r += 1
    ws.cell(r, 1, '⑤ 계획 기준 (LP 수급)').font = BOLD; r += 1
    for t in [
        '목표재고(일) = 생산주기/2 + 안전재고일. 생산주기 = 13주 실적의 같은 품명 재생산 간격, 안전재고 = 1.28 × 주간 출고 편차 × √2 ÷ 하루 출고',
        '출고 편차는 월말 3일이 든 주와 평상주를 따로 평균 내고 그 평균에서 벗어난 양만 씀(월말 몰림은 예측 가능 → 생산계획이 따라감). 컬러 건재 편차 1,219 → 609t/주',
        '생산량 = 3개월 LP: 목표 미달·초과, 안전재고 미달, 결품, 월간 생산 급변에 벌점. 능력 남으면 바로 채우고, 모자라는 달은 앞 달에 미리 만듦',
        '컬러 건재 = 계획재 EOQ 사양별 목표 + 주문재분. 컬러 일별은 계획재(사양·반순) 먼저, 나머지 그룹은 LP 월 물량을 재고 반영 필요량 비중으로 나눔',
        '다음 달 1~5일 벌크 선적분은 이번 달 물량 안에서 월말 10일에 선생산(TF 처럼 목표재고에 또 더하지 않음 — 이중 계상 제거)',
        '자가재 V1: 컬러 품명별 자가재 비중(PGS 72%, PVS2 78%, PCS 0%, POR2 100% …)·강종 구성 × 컬러 일별 생산, 필요일 = 컬러 생산일 − 8일, 반순 단위 품목',
    ]:
        ws.cell(r, 1, t); r += 1

    # ================= 2. 월간수급
    ws = wb.create_sheet('월간수급')
    hdr(ws, 1, ['그룹', '월', '판매', '생산(LP)', '월말재고', '월말 일수', '목표재고', '안전재고', '예전 방식(1/3) 생산', '생산주기/2(일)', '안전재고(일)', '주간 편차 원래', '월말효과 제거'],
        [10, 9, 10, 10, 10, 9, 10, 10, 14, 11, 10, 11, 11])
    i = 2
    for g, rows in M['plan'].items():
        tg = M['targets'].get(g, {})
        dm = M['measure']['demand'].get(g, {})
        for k, x in enumerate(rows):
            put(ws, i, [g, x['month'], x['sales'], x['prod'], x['end'], x['endDays'], x['target'], x.get('safety'),
                        M['third'].get(g, [{}] * 3)[k].get('prod'), tg.get('cycleDays'), tg.get('safetyDays'), dm.get('sdWeekRaw'), dm.get('sdWeek')])
            for j in (6, 10, 11):
                ws.cell(i, j).number_format = '0.0'
            i += 1
    i += 1
    ws.cell(i, 1, '자가재 계수(컬러 1t 생산당 도금 자가재 t, 판매 품명 구성 가중)').font = BOLD; i += 1
    for g, v in M['selfCoef'].items():
        put(ws, i, [g] + v[:3], '0.000'); i += 1
    i += 1
    ws.cell(i, 1, '품명별 자가재 비중·강종 (13주 실적, 원소재 톤 기준)').font = BOLD; i += 1
    hdr(ws, i, ['품명', '실적 원소재(t)', '자가재 비중', 'AZ', 'MAC', 'AL']); i += 1
    for nm, x in sorted(M['measure']['substrate'].items(), key=lambda kv: -kv[1]['t'])[:30]:
        put(ws, i, [nm, x['t'], x['self'], x['alloy'].get('AZ', 0), x['alloy'].get('MAC', 0), x['alloy'].get('AL', 0)])
        for j in (3, 4, 5, 6):
            ws.cell(i, j).number_format = '0%'
        i += 1

    # ================= 3. 컬러 일별
    ws = wb.create_sheet('컬러 일별')
    ws['A1'] = '컬러 1~4CCL 일별 가동계획 (t) — 회색 = 실적(부서 기준)'
    ws['A1'].font = Font(size=13, bold=True)
    sub = CG + ['합계', '가동(분)', '품목']
    for c in (1, 2):
        ws.cell(3, c, ['일자', '요일'][c - 1]).fill = HF
        ws.cell(3, c).font = HFont
        ws.merge_cells(start_row=3, start_column=c, end_row=4, end_column=c)
    for li, l in enumerate(CL.LINES):
        c0 = 3 + li * len(sub)
        ws.cell(3, c0, l).fill, ws.cell(3, c0).font, ws.cell(3, c0).alignment = HF, HFont, C
        ws.merge_cells(start_row=3, start_column=c0, end_row=3, end_column=c0 + len(sub) - 1)
        for j, s in enumerate(sub):
            cc = ws.cell(4, c0 + j, s)
            cc.fill, cc.alignment, cc.border = HF2, C, B
            ws.column_dimensions[CLx(c0 + j)].width = 22 if s == '품목' else 7
    ws.column_dimensions['A'].width, ws.column_dimensions['B'].width = 11, 5
    c_tot = 3 + 4 * len(sub)
    ws.cell(3, c_tot, '공장 합계').fill, ws.cell(3, c_tot).font = HF, HFont
    rr = 5
    for d in days():
        ws.cell(rr, 1, d.isoformat()); ws.cell(rr, 2, WD[d.weekday()])
        if d.weekday() >= 5:
            ws.cell(rr, 2).font = Font(color='C00000')
        tot_day = 0
        for li, l in enumerate(CL.LINES):
            c0 = 3 + li * len(sub)
            gv = cT.get((d, l), {})
            t = sum(gv.values())
            tot_day += t
            for j, s in enumerate(sub):
                if s in CG:
                    v = round(gv[s]) if gv.get(s, 0) >= 0.5 else None
                elif s == '합계':
                    v = round(t) if t >= 0.5 else None
                elif s == '가동(분)':
                    v = round(min(1440, cMin[(d, l)])) if cMin.get((d, l)) else None
                else:
                    nm = cN.get((d, l), [])
                    v = ('실적' if d in cAct else ((nm[0] + (f' 외 {len(nm) - 1}' if len(nm) > 1 else '')) if nm else '비가동'))
                c = ws.cell(rr, c0 + j, v); c.border = B
                if d in cAct:
                    c.font = GRAY
                if s == '합계':
                    c.font = BOLD
        ws.cell(rr, c_tot, round(tot_day)).font = BOLD
        if d.day == calendar.monthrange(d.year, d.month)[1]:
            rr += 1
            ws.cell(rr, 1, f'{d.month}월 계').font = BOLD
            for li, l in enumerate(CL.LINES):
                c0 = 3 + li * len(sub)
                for j, s in enumerate(sub):
                    if s in CG or s == '합계':
                        v = sum((cT.get((x, l), {}).get(s, 0) if s != '합계' else sum(cT.get((x, l), {}).values())) for x in days() if x.month == d.month)
                        c = ws.cell(rr, c0 + j, round(v)); c.font = BOLD; c.fill = HF2; c.number_format = '#,##0'
            ws.cell(rr, c_tot, round(sum(sum(cT.get((x, l), {}).values()) for x in days() if x.month == d.month for l in CL.LINES))).font = BOLD
        rr += 1
    ws.freeze_panes = 'C5'

    # ================= 4. 도금 일별
    ws = wb.create_sheet('도금 일별')
    ws['A1'] = '도금 1·2CGL 일별 가동계획 (t)'
    ws['A1'].font = Font(size=13, bold=True)
    sub = ['강종'] + PCLS + ['합계', '이벤트']
    for c in (1, 2):
        ws.cell(3, c, ['일자', '요일'][c - 1]).fill = HF
        ws.cell(3, c).font = HFont
        ws.merge_cells(start_row=3, start_column=c, end_row=4, end_column=c)
    for li, l in enumerate(['1CGL', '2CGL']):
        c0 = 3 + li * len(sub)
        ws.cell(3, c0, l).fill, ws.cell(3, c0).font, ws.cell(3, c0).alignment = HF, HFont, C
        ws.merge_cells(start_row=3, start_column=c0, end_row=3, end_column=c0 + len(sub) - 1)
        for j, s in enumerate(sub):
            cc = ws.cell(4, c0 + j, s)
            cc.fill, cc.alignment, cc.border = HF2, C, B
            ws.column_dimensions[CLx(c0 + j)].width = 18 if s == '이벤트' else (9 if s == '강종' else 8)
    ws.column_dimensions['A'].width, ws.column_dimensions['B'].width = 11, 5
    c_tot = 3 + 2 * len(sub)
    ws.cell(3, c_tot, '공장 합계').fill, ws.cell(3, c_tot).font = HF, HFont
    rr = 5
    for d in days():
        ws.cell(rr, 1, d.isoformat()); ws.cell(rr, 2, WD[d.weekday()])
        tot_day = 0
        for li, l in enumerate(['1CGL', '2CGL']):
            c0 = 3 + li * len(sub)
            gv = pT.get((d, l), {})
            t = sum(gv.values())
            tot_day += t
            ev = pEv.get((d, l)) or {}
            for j, s in enumerate(sub):
                if s == '강종':
                    al = pA.get((d, l), {})
                    v = '/'.join(a for a, _ in al.most_common()) if al else (ev.get('fam') or '')
                elif s in PCLS:
                    v = round(gv[s]) if gv.get(s, 0) >= 0.5 else None
                elif s == '합계':
                    v = round(t) if t >= 0.5 else None
                else:
                    v = ev.get('event') or ('정기수리/비가동' if ev.get('blackout') else None)
                c = ws.cell(rr, c0 + j, v); c.border = B
                if s == '이벤트' and v:
                    c.fill = WARN
        ws.cell(rr, c_tot, round(tot_day)).font = BOLD
        if d.day == calendar.monthrange(d.year, d.month)[1]:
            rr += 1
            ws.cell(rr, 1, f'{d.month}월 계').font = BOLD
            for li, l in enumerate(['1CGL', '2CGL']):
                c0 = 3 + li * len(sub)
                for j, s in enumerate(sub):
                    if s in PCLS or s == '합계':
                        v = sum((pT.get((x, l), {}).get(s, 0) if s != '합계' else sum(pT.get((x, l), {}).values())) for x in days() if x.month == d.month)
                        c = ws.cell(rr, c0 + j, round(v)); c.font = BOLD; c.fill = HF2; c.number_format = '#,##0'
            ws.cell(rr, c_tot, round(sum(sum(pT.get((x, l), {}).values()) for x in days() if x.month == d.month for l in ('1CGL', '2CGL')))).font = BOLD
        rr += 1
    ws.freeze_panes = 'C5'

    # ================= 5. 자가재
    ws = wb.create_sheet('자가재')
    ws['A1'] = f'자가재 수급 — 컬러 필요(생산일 − {IP.SELF_LEAD}일) vs 도금 생산, 강종 풀별 재고 (9월말 자가재 재고에서 시작)'
    ws['A1'].font = Font(size=13, bold=True)
    hdr(ws, 3, ['일자'] + [f'{p} {k}' for p in ('AZ', 'MAC', 'AL') for k in ('필요', '도금생산', '재고')], [11] + [9] * 9)
    for i, d in enumerate(days()):
        vals = [d.isoformat()]
        for p in ('AZ', 'MAC', 'AL'):
            _, u, pr, s = SB[p][i]
            vals += [round(u), round(pr), round(s)]
        put(ws, 4 + i, vals)
        for k, p in enumerate(('AZ', 'MAC', 'AL')):
            if SB[p][i][3] < 0:
                ws.cell(4 + i, 4 + k * 3).fill = WARN
    c0 = 12
    ws.cell(3, c0, '도금 자가재 품목 (MILP 입력)').font = BOLD
    hdr(ws, 4, ['구역', '강종', '납기', '반순', '톤'], [22, 8, 11, 8, 9], col=c0)
    sitems = [x for x in R['items'] if x['cls'] == '자가재']
    for i, x in enumerate(sorted(sitems, key=lambda z: (z['due'], z['dest'], z['alloy'])), 5):
        put(ws, i, [x['dest'], x['alloy'], x['due'], x.get('window') or '월말', x['tons']], col=c0)
    c1 = c0 + 6
    ws.cell(3, c1, '월별 구역 × 강종 (t)').font = BOLD
    agg = Counter()
    for x in sitems:
        agg[(x['dest'], x['alloy'], x['month'])] += x['tons']
    other_items = json.load(open(os.path.join(IP.WORK, f"integ_items_{'V2' if variant == 'V1' else 'V1'}.json"), encoding='utf-8'))
    agg2 = Counter()
    for x in other_items:
        if x['cls'] == '자가재':
            agg2[(x['dest'], x['alloy'], x['month'])] += x['tons']
    hdr(ws, 4, ['구역', '강종', '10월', '11월', '12월', f"{'V2' if variant == 'V1' else 'V1'} 10월", '11월', '12월'], [22, 8, 9, 9, 9, 10, 9, 9], col=c1)
    keys = sorted({(s, a) for s, a, m in list(agg) + list(agg2)})
    for i, (s, a) in enumerate(keys, 5):
        put(ws, i, [s, a] + [agg[(s, a, m)] for m in (10, 11, 12)] + [agg2[(s, a, m)] for m in (10, 11, 12)], col=c1)
    ws.freeze_panes = 'B4'

    # ================= 6. 소재 일별수급
    ws = wb.create_sheet('소재 일별수급')
    ws['A1'] = (f"소재 일별 수급 — 입고기한 = 재고가 목표 아래로 내려가는 날(9월말 재고가 목표보다 적으면 30일에 걸쳐 목표로), 발주일 = 입고일 − 리드타임(FH {MP.LT_DAYS['FH']}일, 컬러 구매소재 {MP.LT_DAYS['CMAT']}일), "
                f"목표재고 FH {MP.MAT_TARGET['FH']:,}t · 컬러 구매소재 {MP.MAT_TARGET['CMAT']:,}t (판매생산속보)")
    ws['A1'].font = Font(size=12, bold=True)
    hdr(ws, 3, ['일자', 'FH 사용', 'FH 입고필요', 'FH 발주일', 'FH 재고', '', '컬러소재 사용', '입고필요', '발주일', '재고'], [11, 9, 10, 11, 9, 2, 11, 9, 11, 9])
    today = dt.date(2026, 10, 6)
    for i, (a, b) in enumerate(zip(MAT['FH']['rows'], MAT['CMAT']['rows'])):
        put(ws, 4 + i, [a['d'].isoformat(), a['use'], a['in'] or None, a['order'].isoformat() if a['in'] > 0.5 else None, a['stock'], None,
                        b['use'], b['in'] or None, b['order'].isoformat() if b['in'] > 0.5 else None, b['stock']])
        for col, x in ((4, a), (9, b)):
            if x['in'] > 0.5 and x['order'] < today:
                ws.cell(4 + i, col).fill = WARN
    c0 = 12
    ws.cell(3, c0, '주간 합계').font = BOLD
    hdr(ws, 4, ['주 시작', 'FH 사용', 'FH 입고', 'FH 발주 마감', '컬러소재 사용', '입고', '발주 마감'], [11, 9, 9, 12, 11, 9, 12], col=c0)
    wk = defaultdict(lambda: [0, 0, None, 0, 0, None])
    for a, b in zip(MAT['FH']['rows'], MAT['CMAT']['rows']):
        k = a['d'] - dt.timedelta(days=a['d'].weekday())
        w = wk[k]
        w[0] += a['use']; w[1] += a['in']; w[3] += b['use']; w[4] += b['in']
        if a['in'] > 0.5 and w[2] is None:
            w[2] = a['order'].isoformat()
        if b['in'] > 0.5 and w[5] is None:
            w[5] = b['order'].isoformat()
    for i, (k, w) in enumerate(sorted(wk.items()), 5):
        put(ws, i, [k.isoformat()] + w, col=c0)
    ws.freeze_panes = 'B4'

    # ================= 7. 컬러 상세
    ws = wb.create_sheet('컬러 상세')
    hdr(ws, 1, ['일자', '라인', '그룹', '품명', '사양/지역·고객', '목적지', '배선·반순', '완료기한', '생산량(t)', '시간(분)', 'T/hr', '비고'],
        [11, 7, 8, 14, 24, 18, 26, 8, 10, 9, 7, 24])
    i = 2
    for Mo in P['color']:
        for r in sorted(Mo['rows'], key=lambda z: (z['day'], CL.LINES.index(z['line']), CG.index(z['group']))):
            put(ws, i, [dt.date(Mo['year'], Mo['month'], r['day']).isoformat(), r['line'], r['group'], r['product'], r.get('spec') or '', r.get('dest') or '',
                        r.get('ship') or '', f"{r['due']}일" if r.get('due') else '', r['t'], r['min'], r['tph'], r.get('note') or ''], '#,##0.0')
            i += 1
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = f'A1:L{i - 1}'

    # ================= 8. 도금 상세
    ws = wb.create_sheet('도금 상세')
    hdr(ws, 1, ['일자', '라인', '강종', '구분', '목적지/구역', '항구', '선적창', '톤', '납기'], [11, 7, 8, 10, 22, 26, 10, 9, 11])
    for i, x in enumerate(R['dest'], 2):
        put(ws, i, x, '#,##0.0')
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = f'A1:I{len(R["dest"]) + 1}'

    # ================= 9. 점검
    ws = wb.create_sheet('점검')
    hdr(ws, 1, ['구분', '내용', '값', '판단'], [14, 70, 12, 40])
    chk = []
    for k, Mo in enumerate(P['color']):
        mp = sum(Mo['monthPlan'].values())
        tot = sum(r['t'] for r in Mo['rows']) + sum(Mo['doneLine'].values())
        chk.append(('컬러', f"{months[k]} 편성 합계(실적 포함) / MES 월차 {mp:,.0f}t", tot, f'{tot / mp:.0%}'))
        chk.append(('컬러', f"{months[k]} LP 물량 대비 미편성", sum(u['t'] for u in Mo['unplaced']), '라인 전용 제약(4CCL·2CCL 만 되는 PPH·PPG 등) — 2CCL 증편 검토' if sum(u['t'] for u in Mo['unplaced']) > 100 else '양호'))
        for u in sorted(Mo['unplaced'], key=lambda z: -z['t'])[:5]:
            chk.append(('', f"  {u['group']} {u['product']} {u['cust']} {u['dest'] or ''}", u['t'], f"가능 라인: {'·'.join(CF.lines_for(u['product'], u['group'], {}))}"))
    chk.append(('도금', '결품(t)', short, '양호' if short < 1 else '확인'))
    chk.append(('도금', '납기 지연(t·일)', late, '양호' if late < 1 else '확인'))
    for mo in (10, 11, 12):
        pt = sum(t for d, l, a, c, t, due in R['rows'] if int(d[5:7]) == mo)
        pl = sum(M['plan'][g][mo - 10]['prod'] for g in ('G국내', 'G수출', 'G자동차', 'G자가재'))
        chk.append(('도금', f'{mo}월 MILP 생산 / LP 물량', pt, f'LP {pl:,.0f}t (차이 {pt - pl:+,.0f}t, 1~5일 선적분 전월 생산 가정 포함)'))
    lc = Counter()
    for d, l, a, c, t, due in R['rows']:
        lc[(l, int(d[5:7]))] += t
    for l in ('1CGL', '2CGL'):
        chk.append(('도금', f'{l} 월 생산 10·11·12월', None, ' / '.join(f'{lc[(l, mo)]:,.0f}' for mo in (10, 11, 12)) +
                    (' — 한 달이 다른 달보다 크게 적으면 그 달 여유(앞 달 선생산 결과 또는 일감 부족)' if min(lc[(l, mo)] for mo in (10, 11, 12)) < 0.7 * max(lc[(l, mo)] for mo in (10, 11, 12)) else '')))
    for k in ('AZ', 'MAC', 'AL'):
        chk.append(('자가재', f'{k} 재고 최저 ({minday[k].isoformat()})', mins[k], '부족 — 그 날 이전 도금 자가재 앞당김 필요' if mins[k] < 0 else '양호'))
    for k, nm in (('FH', 'FH'), ('CMAT', '컬러 구매소재')):
        late_orders = sum(x['in'] for x in MAT[k]['rows'] if x['in'] > 0.5 and x['order'] < today)
        chk.append(('소재', f'{nm}: 발주일이 10/6 이전인 입고 필요량', late_orders, '기발주로 덮여 있는지 확인' if late_orders > 1 else '없음'))
    for i, row in enumerate(chk, 2):
        put(ws, i, list(row))
        ws.cell(i, 3).number_format = '#,##0'
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wb.save(path)
    return path
