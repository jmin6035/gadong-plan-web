"""컬러 계획 계산(웹 '컬러 계획 계산' 화면과 같은 계산) — 통합 계획 준비(integrated_plan.prep) → 화면 자료(integrated_web.build·confirm)

도금은 확정 계획(work/integ_plating_V1.json)을 그대로 두고, 컬러만 판매계획·계획재 운영안·휴지계획으로 다시 짠다(2026-10-12 결정과 같은 방식).
브라우저(Pyodide)에서는 이 파일을 그대로 불러 run() 을 부른다 — 서버 계산과 결과가 같다.
    python3 tools/color_calc.py --extra extradata.json --mesdata mesdata.json [--sales 판매계획.xlsx] [--r15 운영안.xlsx] [--down 휴지계획.xlsx] --plain out.json
    python3 tools/color_calc.py --files                 # 브라우저 묶음에 넣을 자료 파일 목록(실행 중 연 파일)
"""
import argparse
import json
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, 'tools'))
from cglplan import tables as TB  # noqa: E402

# 계산이 읽는 자료 파일(ROOT 기준) — 브라우저 묶음(tools/color_calc_bundle.py)도 이 목록을 씀
DATA_FILES = None                                                 # --files 로 실제 연 파일을 확인해 아래 상수로 고정


def parse_idle(text, year=2026):
    """'1CCL 10/30, 10/31' · '2CCL 2026-12-24~12-26' 같은 줄 → [{'line', 'date'}]. 줄마다 라인 하나"""
    import datetime as _dt, re as _re
    out = []
    for ln in str(text or '').splitlines():
        m = _re.match(r'\s*([1-4])\s*CCL\b(.*)', ln.strip(), _re.I)
        if not m:
            continue
        line = f'{m.group(1)}CCL'
        for tok in _re.split(r'[,\s]+', m.group(2).strip()):
            if not tok:
                continue
            ends = tok.split('~')
            ds = []
            for e in ends:
                mm = _re.match(r'(?:(\d{4})[-./])?(\d{1,2})[-./](\d{1,2})$', e)
                if mm:
                    ds.append(_dt.date(int(mm.group(1) or year), int(mm.group(2)), int(mm.group(3))))
            if len(ds) == 1:
                out.append({'line': line, 'date': ds[0].isoformat()})
            elif len(ds) == 2:
                d = ds[0]
                while d <= ds[1]:
                    out.append({'line': line, 'date': d.isoformat()})
                    d += _dt.timedelta(days=1)
    return out


def apply_uploads(sales=None, r15=None, down=None, log=print, lines=None, idle=None):
    """올린 엑셀로 기본 자료를 바꿈: 판매계획(TF) · 계획재 운영안(R15) · 컬러 휴지계획 · 품목별 적용라인(필수·우선라인)"""
    import integrated_plan as IP
    from cglplan import r15 as R15
    if sales:
        shutil.copy(sales, IP.SALES)
        log(f'판매계획 교체: {os.path.basename(sales)}')
    if r15:
        shutil.copy(r15, R15.DEFAULT_PATH)
        log(f'계획재 운영안 교체: {os.path.basename(r15)}')
    if lines:                                                    # 산출기준서 L-22: 품목별 적용라인(세부판매기준) — 필수라인 → 우선라인1~3
        from cglplan import line_rules as LR
        rules, warns, title = LR.from_xlsx(lines)
        if not rules:
            raise ValueError(f'품목별 적용라인: {os.path.basename(lines)} 에서 규칙 행을 찾지 못함(첫 시트에 필수라인·우선라인1~3 열 필요)')
        LR.save(rules, os.path.basename(lines), title)
        log(f'품목별 적용라인 교체: {os.path.basename(lines)} (규칙 {len(rules)}행 · 필수라인 {sum(1 for r in rules if r["must"])} · 우선라인만 {sum(1 for r in rules if not r["must"])})')
        for w in warns[:10]:
            log('  확인: ' + w)
    if idle is not None:                                         # 산출기준서 L-24: 휴지일 지정(그 날 라인을 비움). 빈칸이면 자동(월말 몰기)
        import integrated_plan as IP
        items = parse_idle(idle)
        if items:
            json.dump({'items': items, 'src': '컬러 계획 계산 화면 휴지일 지정'}, open(IP.IDLE_FILE, 'w', encoding='utf-8'), ensure_ascii=False)
            log(f'휴지일 지정: {len(items)}일 — ' + ', '.join(f"{x['line']} {x['date'][5:]}" for x in items[:12]) + (' …' if len(items) > 12 else ''))
        elif os.path.exists(IP.IDLE_FILE):
            os.remove(IP.IDLE_FILE)
    if down:
        import color_downtime as CD
        items, notes = CD.parse(down)
        out = os.path.join(ROOT, 'data', 'color_downtime_2026Q4.json')
        json.dump({'src': os.path.basename(down), 'items': items, 'notes': notes,
                   'rule': '계획휴지·S/D·수리 = 라인 정지(그대로 막음). 청소·Test·샘플 = 평소 정지라 지난 3개월 월평균을 넘는 만큼만 막음'},
                  open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        log(f'컬러 휴지계획 교체: {os.path.basename(down)} ({len(items)}건)')
        for n in notes:
            log('  확인: ' + n)


def run(ex, md, log=print):
    """→ (화면 자료 dict, 요약 dict). 화면 자료는 published/integrated.enc.json 과 같은 형식"""
    import integrated_plan as IP
    import integrated_web as IW
    log('월 물량·컬러 일별 계획 계산 중')
    P = IP.prep(ex, md)
    log('화면 자료 만드는 중(도금은 확정 계획 유지)')
    o = IW.confirm(IW.build(ex), 'V1')
    return o, summary(P, o)


def summary(P, o):
    """라인·월 생산, 미편성(그룹별), 자가재 최저 재고 — 화면 비교용"""
    from collections import Counter
    lines, unpl = Counter(), Counter()
    for M in P['color']:
        for r in M['rows']:
            lines[f"{r['line']}|{M['ym']}"] += r['t']
        for l, t in M['doneLine'].items():
            lines[f"{l}|{M['ym']}"] += t
        for u in M['unplaced']:
            unpl[f"{u['group']}|{M['ym']}"] += u['t']
    v = o['variants'].get('V1') or {}
    self_min = {p: min((x[3] for x in v.get('self', {}).get(p, [])), default=None) for p in ('AZ', 'MAC', 'AL')}
    return {'lines': {k: round(t, 1) for k, t in sorted(lines.items())}, 'unplaced': {k: round(t, 1) for k, t in sorted(unpl.items())},
            'selfMin': self_min, 'asOf': o.get('asOf')}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--extra')
    ap.add_argument('--mesdata')
    ap.add_argument('--sales')
    ap.add_argument('--r15')
    ap.add_argument('--down')
    ap.add_argument('--lines', help='품목별 적용라인(세부판매기준) 엑셀')
    ap.add_argument('--idle', help="휴지일 지정 글('1CCL 10/30, 10/31' 줄마다 라인)")
    ap.add_argument('--plain')
    ap.add_argument('--files', action='store_true', help='실행 중 연 자료 파일 목록 출력')
    a = ap.parse_args()
    opened = set()
    if a.files:
        def hook(ev, args):
            if ev == 'open' and isinstance(args[0], str):
                p = os.path.abspath(args[0])
                if p.startswith(ROOT) and ('r' in str(args[1]) or args[1] is None):
                    opened.add(os.path.relpath(p, ROOT))
        sys.addaudithook(hook)
    apply_uploads(a.sales, a.r15, a.down, lines=a.lines, idle=a.idle)
    o, s = run(TB.load_extra(a.extra), json.load(open(a.mesdata, encoding='utf-8')))
    print(json.dumps(s, ensure_ascii=False)[:2000])
    if a.plain:
        open(a.plain, 'w', encoding='utf-8').write(json.dumps(o, ensure_ascii=False, separators=(',', ':')))
    if a.files:
        print('\n'.join(sorted(x for x in opened if not x.endswith('.py') and '__pycache__' not in x)))


if __name__ == '__main__':
    main()
