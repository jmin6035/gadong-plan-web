"""컬러 일정 몰기(2026-10-13 사용자 결정): 10·11월은 라인별로 같은 달 안에서 앞날부터 하루를 꽉 채우고 월말에 휴지를 모음.
하루 몇 시간씩 띄엄띄엄 돌던 날(예: 2CCL 10월 하순 2~4시간)을 없애 재가동·더미 손실을 줄이기 위함. 월 생산량·라인·순서는 그대로.

규칙
· 같은 달·같은 라인 안에서만, 원래 순서 그대로 앞으로 채움(계획재 운영안 순서·교체시간 유지). 달은 넘기지 않음
· 하루 가용 = 1,440분 − 컬러 휴지계획(integrated_plan.color_down: 계획휴지·S/D·수리 전부, 청소·Test·샘플은 평소 초과분)
· 가전내수(고객 납입 주기)는 원래 날짜 고정
· 구매 소재: 컬러 투입 7일 전 입고(팀 리드타임 표 ⑤). 앞당긴 날의 코드별 누적 소요가 '현재 재고 + MES 기발주 입고(그 7일 전까지)'와
  '원래 계획의 같은 날 누적 소요' 중 큰 쪽을 넘으면 그날로는 못 당김(원래 계획보다 소재 부족을 늘리지 않음)
· 자가재(도금)는 여기서 막지 않음 — 당겨진 컬러 일정으로 자가재 필요일을 다시 계산(integrated_plan.self_items)
(옛 결정 — 10/19 사용자 결정으로 12월도 몲) 12월은 몰지 않음: 1CGL AZ 재가동(12/15) 전이라 AZ 자가재 부족이 커지고(월말 휴지), 중순 휴지는 수출·주문재 납기를 최대 25일 늦춤(2026-10-13 비교)
"""
import calendar
import os
import datetime as dt
from collections import Counter, defaultdict

MONTHS = ('2026-10', '2026-11') if os.environ.get('CGL_PACK_DEC') == '0' else ('2026-10', '2026-11', '2026-12')   # 12월 포함(2026-10-19 사용자). CGL_PACK_DEC=0 = 비교용
FIXED_GROUPS = ('가전내수',)
MAT_LEAD = 7                                              # 구매 소재 입고 → 컬러 투입(일)
GI_MATS = ('서림GI', 'P-GI')


def _mat_need(r, self_of, mix_of, yld):
    """행 → 구매 소재 코드별 t (자가재 몫 제외)"""
    if r.get('mat'):
        return {'G': r['t'] / yld} if r['mat'].replace(' ', '') in GI_MATS else {}
    base = r.get('base') or r['product']
    buy = r['t'] / yld * max(0.0, 1 - self_of(base, r.get('cust') or '', r['group']))
    return {c: buy * w for c, w in mix_of(base).items()} if buy > 0.01 else {}


def pack(color, down, supply, self_of, mix_of, yld=1.003, months=MONTHS):
    """color: integrated_plan.color_quarter 결과(월 목록, 제자리 수정). down: {(YYYY-MM-DD, 라인): 막는 분}.
    supply: {코드: {YYYY-MM-DD: t}} — 오늘 재고는 오늘 날짜에, 기발주는 입고 예정일에. 반환: 요약"""
    sup_cum = {}
    for c, ser in supply.items():
        acc, out = 0.0, []
        for d in sorted(ser):
            acc += ser[d]
            out.append((d, acc))
        sup_cum[c] = out

    def sup_by(c, d):
        v = 0.0
        for dd, acc in sup_cum.get(c, []):
            if dd > d:
                break
            v = acc
        return v

    summary = {}
    for M in color:
        if M['ym'] not in months:
            continue
        y, m, nd, sd = M['year'], M['month'], M['ndays'], M['startDay']
        ds = lambda k: f'{y}-{m:02d}-{k:02d}'
        days = list(range(sd, nd + 1))
        # 원래 계획의 코드별 일별 구매 소재 소요(전 라인) → 누적
        orig = defaultdict(Counter)
        for r in M['rows']:
            if r['day'] >= sd:
                for c, t in _mat_need(r, self_of, mix_of, yld).items():
                    orig[c][r['day']] += t
        new_need = defaultdict(Counter)
        moved = Counter()
        rows_out = [r for r in M['rows'] if r['day'] < sd]
        lines = sorted({r['line'] for r in M['rows'] if r['day'] >= sd})
        before_parts = {}
        for l in lines:
            mine = [r for _, r in sorted(((i, r) for i, r in enumerate(M['rows']) if r['line'] == l and r['day'] >= sd), key=lambda x: (x[1]['day'], x[0]))]   # 날짜순(같은 날은 원래 순서)
            before_parts[l] = sum(1 for k in days if 0 < sum(r['min'] for r in mine if r['day'] == k) < max(0, 1440 - (down or {}).get((ds(k), l), 0)) - 60)
            used = Counter()
            for r in mine:
                if r['group'] in FIXED_GROUPS:
                    rows_out.append(r)
                    used[r['day']] += r['min']
                    for c, t in _mat_need(r, self_of, mix_of, yld).items():
                        new_need[c][r['day']] += t
            q = [dict(r) for r in mine if r['group'] not in FIXED_GROUPS]
            k = sd
            for r in q:
                need = _mat_need(r, self_of, mix_of, yld)
                left_t, left_min = r['t'], r['min']
                while left_min > 1e-6:
                    day = min(k, r['day'])                           # 원래 날보다 늦추지 않음
                    room = max(0, 1440 - (down or {}).get((ds(day), l), 0)) - used[day]
                    ok = day >= r['day'] or all(
                        sum(v for dd, v in new_need[c].items() if dd <= day) + t * left_min / r['min'] <= max(sup_by(c, (dt.date(y, m, day) - dt.timedelta(days=MAT_LEAD)).isoformat()) + 1e-6,
                                                                                                              sum(v for dd, v in orig[c].items() if dd <= day) + 1e-6)
                        for c, t in need.items())
                    if room <= 1e-6 or not ok:
                        if day >= r['day']:                          # 원래 날: 공간이 없으면 그대로 둠(원래 계획과 같음)
                            room = left_min
                        else:
                            k = day + 1
                            continue
                    take = min(room, left_min)
                    f = take / r['min']
                    x = dict(r, day=day, min=take, t=r['t'] * f)
                    if day < r['day']:
                        x['note'] = (r.get('note') or '') + f" · 몰기(원래 {m}/{r['day']})"
                        moved[l] += x['t']
                    rows_out.append(x)
                    used[day] += take
                    for c, t in need.items():
                        new_need[c][day] += t * f
                    left_min -= take
                    left_t -= x['t']
                    if used[day] >= max(0, 1440 - (down or {}).get((ds(day), l), 0)) - 1e-6:
                        k = day + 1
        M['rows'] = sorted(rows_out, key=lambda r: (r['day'], r['line']))
        after_parts = {}
        for l in lines:
            mine = [r for r in M['rows'] if r['line'] == l and r['day'] >= sd]
            after_parts[l] = sum(1 for k in days if 0 < sum(r['min'] for r in mine if r['day'] == k) < max(0, 1440 - (down or {}).get((ds(k), l), 0)) - 60)
            idle = [k for k in days if sum(r['min'] for r in mine if r['day'] == k) < 1 and (down or {}).get((ds(k), l), 0) < 1440]
            summary.setdefault(M['ym'], {})[l] = {'movedT': round(moved[l]), 'partBefore': before_parts[l], 'partAfter': after_parts[l], 'idle': idle}
        M['packed'] = True
    return summary


IDLE_ADV = int(os.environ.get('CGL_IDLE_ADV', '30'))       # 휴지 집약: 최대 며칠 앞당겨 만들 수 있나(재고 증가 한도). 10/19 비교: 30일 이상은 결과 같음(= 최대 집약)


def pack_idle(color, down, supply, self_of, mix_of, yld=1.003, max_adv=None):
    """휴지 최대 집약(2026-10-19 사용자: 월말 몰기 폐기, 재고가 조금 늘어도 휴지를 최대한 모음).
    라인마다 남은 기간 전체(달 경계 무관)를 순서 그대로 앞날부터 꽉 채움 → 쉬는 시간이 띄엄띄엄이 아니라 며칠짜리 덩어리로 모임.
    · 늦추지 않음(납기 지연 없음), 앞당김은 최대 max_adv 일(그보다 일이 없으면 그 사이가 휴지 덩어리)
    · 가전내수(고객 납입 주기)는 날짜 고정, 구매 소재가 컬러 투입 7일 전 입고 안 되면 안 당김(원래 계획보다 소재 부족을 늘리지 않음)
    · 하루 가용 = 1,440분 − 휴지계획(사용자가 지정한 휴지일 포함)
    color 를 제자리 수정(행이 다른 달로 넘어가면 그 달 rows 로 옮김). 반환: 라인별 요약"""
    max_adv = IDLE_ADV if max_adv is None else max_adv
    sup_cum = {}
    for c, ser in supply.items():
        acc, out = 0.0, []
        for d in sorted(ser):
            acc += ser[d]
            out.append((d, acc))
        sup_cum[c] = out

    def sup_by(c, d):
        v = 0.0
        for dd, acc in sup_cum.get(c, []):
            if dd > d:
                break
            v = acc
        return v
    D = lambda M, k: dt.date(M['year'], M['month'], k)
    days = [D(M, k) for M in color for k in range(M['startDay'], M['ndays'] + 1)]
    if not days:
        return {}
    cap = lambda d, l: max(0.0, 1440.0 - (down or {}).get((d.isoformat(), l), 0))
    allr = [(D(M, r['day']), i, dict(r, _ym=r.get('dueYm') or M['ym'])) for M in color for i, r in enumerate(M['rows']) if r['day'] >= M['startDay']]
    orig = defaultdict(Counter)
    for d, _, r in allr:
        for c, t in _mat_need(r, self_of, mix_of, yld).items():
            orig[c][d] += t
    cum = lambda ctr, d: sum(v for dd, v in ctr.items() if dd <= d)
    new_need = defaultdict(Counter)
    out_rows, summary = [], {}
    lines = sorted({r['line'] for _, _, r in allr})
    for l in lines:
        mine = sorted((x for x in allr if x[2]['line'] == l), key=lambda x: (x[0], x[1]))
        load = Counter()
        for d, _, r in mine:
            load[d] += r['min']
        parts0 = sum(1 for d in days if 0 < load[d] < cap(d, l) - 60)
        used = Counter()
        for d, _, r in mine:
            if r['group'] in FIXED_GROUPS:
                out_rows.append((d, r))
                used[d] += r['min']
                for c, t in _mat_need(r, self_of, mix_of, yld).items():
                    new_need[c][d] += t
        ki, moved_td, moved_t = 0, 0.0, 0.0
        for d0, _, r in mine:
            if r['group'] in FIXED_GROUPS:
                continue
            need = _mat_need(r, self_of, mix_of, yld)
            lo = d0 - dt.timedelta(days=max_adv)
            while ki < len(days) - 1 and days[ki] < lo:          # 앞당김 한도보다 이르면 그 사이는 휴지로 둠
                ki += 1
            left = r['min']
            while left > 1e-6:
                day = min(days[ki], d0)
                room = cap(day, l) - used[day]
                ok = day >= d0 or all(cum(new_need[c], day) + t * left / r['min'] <= max(sup_by(c, (day - dt.timedelta(days=MAT_LEAD)).isoformat()), cum(orig[c], day)) + 1e-6
                                      for c, t in need.items())
                if room <= 1e-6 or not ok:
                    if day >= d0:
                        room = left                                # 원래 날: 그대로(원래 계획과 같음)
                    else:
                        ki += 1
                        continue
                take = min(room, left)
                f = take / r['min']
                x = dict(r, min=take, t=r['t'] * f)
                if day < d0:
                    x['note'] = (r.get('note') or '') + f" · 휴지 집약(원래 {d0.month}/{d0.day})"
                    moved_t += x['t']
                    moved_td += x['t'] * (d0 - day).days
                out_rows.append((day, x))
                used[day] += take
                for c, t in need.items():
                    new_need[c][day] += t * f
                left -= take
                if used[day] >= cap(day, l) - 1e-6 and ki < len(days) - 1 and days[ki] == day:
                    ki += 1
        mins = Counter()
        for d, x in out_rows:
            if x['line'] == l:
                mins[d] += x['min']
        idle = [d for d in days if mins[d] < 1 and cap(d, l) > 0]
        blocks, run = [], []
        for d in days:
            if d in idle:
                run.append(d)
            elif run:
                blocks.append(run); run = []
        if run:
            blocks.append(run)
        summary[l] = {'partBefore': parts0, 'partAfter': sum(1 for d in days if 0 < mins[d] < cap(d, l) - 60),
                      'idleDays': len(idle), 'blocks': [f"{b[0].month}/{b[0].day}~{b[-1].month}/{b[-1].day}({len(b)}일)" for b in blocks],
                      'movedT': round(moved_t), 'advTDays': round(moved_td)}
    first = {M['ym']: M for M in color}
    for M in color:
        M['rows'] = [r for r in M['rows'] if r['day'] < M['startDay']]
    for d, x in out_rows:
        M = first.get(f'{d.year}-{d.month:02d}')
        if M is None:
            continue
        y_ = dict(x, day=d.day)
        if x.get('due') and x.get('_ym') and x['_ym'] != M['ym']:
            y_['dueYm'] = x['_ym']                                 # 다른 달로 앞당겨진 행: 납기(일)는 원래 달 기준
        y_.pop('_ym', None)
        M['rows'].append(y_)
    for M in color:
        M['rows'].sort(key=lambda r: (r['day'], r['line']))
        M['packed'] = 'idle'
    return summary


def supply_from(T, today):
    """컬러 구매 소재 공급 {코드: {날짜: t}} — 웹 계산 묶음에는 미리 계산한 'color_supply' 표(톤만)가 실림, 없으면 원자료로 계산(cglplan.pages.color_supply)"""
    if T.get('color_supply'):
        sup = defaultdict(Counter)
        for c, d, t in T['color_supply']['rows']:
            sup[c][d] += t
        return sup
    from cglplan import pages as PG
    return PG.color_supply(T, today)
