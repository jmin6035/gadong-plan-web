"""컬러 일정 몰기(2026-10-13 사용자 결정): 10·11월은 라인별로 같은 달 안에서 앞날부터 하루를 꽉 채우고 월말에 휴지를 모음.
하루 몇 시간씩 띄엄띄엄 돌던 날(예: 2CCL 10월 하순 2~4시간)을 없애 재가동·더미 손실을 줄이기 위함. 월 생산량·라인·순서는 그대로.

규칙
· 같은 달·같은 라인 안에서만, 원래 순서 그대로 앞으로 채움(계획재 운영안 순서·교체시간 유지). 달은 넘기지 않음
· 하루 가용 = 1,440분 − 컬러 휴지계획(integrated_plan.color_down: 계획휴지·S/D·수리 전부, 청소·Test·샘플은 평소 초과분)
· 가전내수(고객 납입 주기)는 원래 날짜 고정
· 구매 소재: 컬러 투입 7일 전 입고(팀 리드타임 표 ⑤). 앞당긴 날의 코드별 누적 소요가 '현재 재고 + MES 기발주 입고(그 7일 전까지)'와
  '원래 계획의 같은 날 누적 소요' 중 큰 쪽을 넘으면 그날로는 못 당김(원래 계획보다 소재 부족을 늘리지 않음)
· 자가재(도금)는 여기서 막지 않음 — 당겨진 컬러 일정으로 자가재 필요일을 다시 계산(integrated_plan.self_items)
(옛 결정 — 10/19 사용자 결정으로 12월도 몲) 12월은 몰지 않음: 1CGL AZ 재가동(12/15) 전이라 AZ 자가재 부족이 커지고(월말 휴지), 중순 휴지는 수출·주문재 납기를 최대 25일 늦춤(2026-10-13 비교)
"""
import calendar
import os
import datetime as dt
from collections import Counter, defaultdict

MONTHS = ('2026-10', '2026-11') if os.environ.get('CGL_PACK_DEC') == '0' else ('2026-10', '2026-11', '2026-12')   # 12월 포함(2026-10-19 사용자). CGL_PACK_DEC=0 = 비교용
FIXED_GROUPS = ()                                          # 2026-10-19 사용자: 가전내수도 휴지 집약에 포함(예전 10/13: 고객 납입 주기라 날짜 고정)
MAT_LEAD = 7                                              # 구매 소재 입고 → 컬러 투입(일)
GI_MATS = ('서림GI', 'P-GI')


def _mat_need(r, self_of, mix_of, yld):
    """행 → 구매 소재 코드별 t (자가재 몫 제외)"""
    if r.get('mat'):
        return {'G': r['t'] / yld} if r['mat'].replace(' ', '') in GI_MATS else {}
    base = r.get('base') or r['product']
    buy = r['t'] / yld * max(0.0, 1 - self_of(base, r.get('cust') or '', r['group']))
    return {c: buy * w for c, w in mix_of(base).items()} if buy > 0.01 else {}


def pack(color, down, supply, self_of, mix_of, yld=1.003, months=MONTHS):
    """color: integrated_plan.color_quarter 결과(월 목록, 제자리 수정). down: {(YYYY-MM-DD, 라인): 막는 분}.
    supply: {코드: {YYYY-MM-DD: t}} — 오늘 재고는 오늘 날짜에, 기발주는 입고 예정일에. 반환: 요약"""
    sup_cum = {}
    for c, ser in supply.items():
        acc, out = 0.0, []
        for d in sorted(ser):
            acc += ser[d]
            out.append((d, acc))
        sup_cum[c] = out

    def sup_by(c, d):
        v = 0.0
        for dd, acc in sup_cum.get(c, []):
            if dd > d:
                break
            v = acc
        return v

    summary = {}
    for M in color:
        if M['ym'] not in months:
            continue
        y, m, nd, sd = M['year'], M['month'], M['ndays'], M['startDay']
        ds = lambda k: f'{y}-{m:02d}-{k:02d}'
        days = list(range(sd, nd + 1))
        # 원래 계획의 코드별 일별 구매 소재 소요(전 라인) → 누적
        orig = defaultdict(Counter)
        for r in M['rows']:
            if r['day'] >= sd:
                for c, t in _mat_need(r, self_of, mix_of, yld).items():
                    orig[c][r['day']] += t
        new_need = defaultdict(Counter)
        moved = Counter()
        rows_out = [r for r in M['rows'] if r['day'] < sd]
        lines = sorted({r['line'] for r in M['rows'] if r['day'] >= sd})
        before_parts = {}
        for l in lines:
            mine = [r for _, r in sorted(((i, r) for i, r in enumerate(M['rows']) if r['line'] == l and r['day'] >= sd), key=lambda x: (x[1]['day'], x[0]))]   # 날짜순(같은 날은 원래 순서)
            before_parts[l] = sum(1 for k in days if 0 < sum(r['min'] for r in mine if r['day'] == k) < max(0, 1440 - (down or {}).get((ds(k), l), 0)) - 60)
            used = Counter()
            for r in mine:
                if r['group'] in FIXED_GROUPS:
                    rows_out.append(r)
                    used[r['day']] += r['min']
                    for c, t in _mat_need(r, self_of, mix_of, yld).items():
                        new_need[c][r['day']] += t
            q = [dict(r) for r in mine if r['group'] not in FIXED_GROUPS]
            k = sd
            for r in q:
                need = _mat_need(r, self_of, mix_of, yld)
                left_t, left_min = r['t'], r['min']
                while left_min > 1e-6:
                    day = min(k, r['day'])                           # 원래 날보다 늦추지 않음
                    room = max(0, 1440 - (down or {}).get((ds(day), l), 0)) - used[day]
                    ok = day >= r['day'] or all(
                        sum(v for dd, v in new_need[c].items() if dd <= day) + t * left_min / r['min'] <= max(sup_by(c, (dt.date(y, m, day) - dt.timedelta(days=MAT_LEAD)).isoformat()) + 1e-6,
                                                                                                              sum(v for dd, v in orig[c].items() if dd <= day) + 1e-6)
                        for c, t in need.items())
                    if room <= 1e-6 or not ok:
                        if day >= r['day']:                          # 원래 날: 공간이 없으면 그대로 둠(원래 계획과 같음)
                            room = left_min
                        else:
                            k = day + 1
                            continue
                    take = min(room, left_min)
                    f = take / r['min']
                    x = dict(r, day=day, min=take, t=r['t'] * f)
                    if day < r['day']:
                        x['note'] = (r.get('note') or '') + f" · 몰기(원래 {m}/{r['day']})"
                        moved[l] += x['t']
                    rows_out.append(x)
                    used[day] += take
                    for c, t in need.items():
                        new_need[c][day] += t * f
                    left_min -= take
                    left_t -= x['t']
                    if used[day] >= max(0, 1440 - (down or {}).get((ds(day), l), 0)) - 1e-6:
                        k = day + 1
        M['rows'] = sorted(rows_out, key=lambda r: (r['day'], r['line']))
        after_parts = {}
        for l in lines:
            mine = [r for r in M['rows'] if r['line'] == l and r['day'] >= sd]
            after_parts[l] = sum(1 for k in days if 0 < sum(r['min'] for r in mine if r['day'] == k) < max(0, 1440 - (down or {}).get((ds(k), l), 0)) - 60)
            idle = [k for k in days if sum(r['min'] for r in mine if r['day'] == k) < 1 and (down or {}).get((ds(k), l), 0) < 1440]
            summary.setdefault(M['ym'], {})[l] = {'movedT': round(moved[l]), 'partBefore': before_parts[l], 'partAfter': after_parts[l], 'idle': idle}
        M['packed'] = True
    return summary


NEW_ORDER_LT = int(os.environ.get('CGL_IDLE_LT', '35'))   # 오늘 + 이 날수 + 투입 여유 7일 뒤 생산분은 새로 발주해 맞출 수 있음 → 소재 검사 안 함(2026-10-19: 소재 때문에 연속 공정이 끊기면 안 됨. P-GI·P-FH 리드타임 35일)
PULL_LEAD = int(os.environ.get('CGL_PULL_LEAD', '0'))  # 앞당길 때 소재 검사: 그날까지 입고되면 됨(투입 여유 7일은 계획 여유라 연속 공정을 끊는 데 쓰지 않음, 10/19)
IDLE_ADV = int(os.environ.get('CGL_IDLE_ADV', '30'))       # 휴지 집약: 최대 며칠 앞당겨 만들 수 있나(재고 증가 한도). 10/19 비교: 30일 이상은 결과 같음(= 최대 집약)


def pack_idle(color, down, supply, self_of, mix_of, yld=1.003, max_adv=None):
    """휴지 최대 집약(2026-10-19 사용자: 월말 몰기 폐기, 재고가 조금 늘어도 휴지를 최대한 모음).
    라인마다 남은 기간 전체(달 경계 무관)를 순서 그대로 앞날부터 꽉 채움 → 쉬는 시간이 띄엄띄엄이 아니라 며칠짜리 덩어리로 모임.
    · 늦추지 않음(납기 지연 없음), 앞당김은 최대 max_adv 일(그보다 일이 없으면 그 사이가 휴지 덩어리)
    · 가전내수도 포함(10/19 날짜 고정 폐기). 하루 안의 빈 시간도 휴지 — 다음 날 일을 당겨 그날을 꽉 채움(연속 공정)
    · 구매 소재가 당긴 그날까지 실제 입고 안 되면 안 당김(PULL_LEAD=0, 원래 계획보다 소재 부족을 늘리지 않음). 오늘+NEW_ORDER_LT+7일 이후는 신규 발주로 맞춤 → 확인 안 함
    · 하루 가용 = 1,440분 − 휴지계획(사용자가 지정한 휴지일 포함)
    color 를 제자리 수정(행이 다른 달로 넘어가면 그 달 rows 로 옮김). 반환: 라인별 요약"""
    max_adv = IDLE_ADV if max_adv is None else max_adv
    sup_cum = {}
    for c, ser in supply.items():
        acc, out = 0.0, []
        for d in sorted(ser):
            acc += ser[d]
            out.append((d, acc))
        sup_cum[c] = out

    def sup_by(c, d):
        v = 0.0
        for dd, acc in sup_cum.get(c, []):
            if dd > d:
                break
            v = acc
        return v
    D = lambda M, k: dt.date(M['year'], M['month'], k)
    days = [D(M, k) for M in color for k in range(M['startDay'], M['ndays'] + 1)]
    if not days:
        return {}
    cap = lambda d, l: max(0.0, 1440.0 - (down or {}).get((d.isoformat(), l), 0))
    allr = [(D(M, r['day']), i, dict(r, _ym=r.get('dueYm') or M['ym'])) for M in color for i, r in enumerate(M['rows']) if r['day'] >= M['startDay']]
    orig = defaultdict(Counter)
    for d, _, r in allr:
        for c, t in _mat_need(r, self_of, mix_of, yld).items():
            orig[c][d] += t
    cum = lambda ctr, d: sum(v for dd, v in ctr.items() if dd <= d)
    new_need = defaultdict(Counter)
    out_rows, summary = [], {}
    lines = sorted({r['line'] for _, _, r in allr})
    for l in lines:
        mine = sorted((x for x in allr if x[2]['line'] == l), key=lambda x: (x[0], x[1]))
        load = Counter()
        for d, _, r in mine:
            load[d] += r['min']
        parts0 = sum(1 for d in days if 0 < load[d] < cap(d, l) - 60)
        used = Counter()
        for d, _, r in mine:
            if r['group'] in FIXED_GROUPS:
                out_rows.append((d, r))
                used[d] += r['min']
                for c, t in _mat_need(r, self_of, mix_of, yld).items():
                    new_need[c][d] += t
        ki, moved_td, moved_t = 0, 0.0, 0.0
        for d0, _, r in mine:
            if r['group'] in FIXED_GROUPS:
                continue
            need = _mat_need(r, self_of, mix_of, yld)
            lo = d0 - dt.timedelta(days=max_adv)
            while ki < len(days) - 1 and days[ki] < lo:          # 앞당김 한도보다 이르면 그 사이는 휴지로 둠
                ki += 1
            left = r['min']
            while left > 1e-6:
                day = min(days[ki], d0)
                room = cap(day, l) - used[day]
                ok = day >= d0 or os.environ.get('CGL_IDLE_MAT') == '0' or (NEW_ORDER_LT is not None and day >= days[0] + dt.timedelta(days=NEW_ORDER_LT + MAT_LEAD)) or all(cum(new_need[c], day) + t * left / r['min'] <= max(sup_by(c, (day - dt.timedelta(days=PULL_LEAD)).isoformat()), cum(orig[c], day)) + 1e-6
                                      for c, t in need.items())
                if room <= 1e-6 or not ok:
                    if day >= d0:
                        room = left                                # 원래 날: 그대로(원래 계획과 같음)
                    else:
                        ki += 1
                        continue
                take = min(room, left)
                f = take / r['min']
                x = dict(r, min=take, t=r['t'] * f)
                if day < d0:
                    x['note'] = (r.get('note') or '') + f" · 휴지 집약(원래 {d0.month}/{d0.day})"
                    moved_t += x['t']
                    moved_td += x['t'] * (d0 - day).days
                out_rows.append((day, x))
                used[day] += take
                for c, t in need.items():
                    new_need[c][day] += t * f
                left -= take
                if used[day] >= cap(day, l) - 1e-6 and ki < len(days) - 1 and days[ki] == day:
                    ki += 1
        mins = Counter()
        for d, x in out_rows:
            if x['line'] == l:
                mins[d] += x['min']
        idle = [d for d in days if mins[d] < 1 and cap(d, l) > 0]
        blocks, run = [], []
        for d in days:
            if d in idle:
                run.append(d)
            elif run:
                blocks.append(run); run = []
        if run:
            blocks.append(run)
        summary[l] = {'partBefore': parts0, 'partAfter': sum(1 for d in days if 0 < mins[d] < cap(d, l) - 60),
                      'idleDays': len(idle), 'blocks': [f"{b[0].month}/{b[0].day}~{b[-1].month}/{b[-1].day}({len(b)}일)" for b in blocks],
                      'movedT': round(moved_t), 'advTDays': round(moved_td)}
    first = {M['ym']: M for M in color}
    for M in color:
        M['rows'] = [r for r in M['rows'] if r['day'] < M['startDay']]
    for d, x in out_rows:
        M = first.get(f'{d.year}-{d.month:02d}')
        if M is None:
            continue
        y_ = dict(x, day=d.day)
        if x.get('due') and x.get('_ym') and x['_ym'] != M['ym']:
            y_['dueYm'] = x['_ym']                                 # 다른 달로 앞당겨진 행: 납기(일)는 원래 달 기준
        y_.pop('_ym', None)
        M['rows'].append(y_)
    for M in color:
        M['rows'].sort(key=lambda r: (r['day'], r['line']))
        M['packed'] = 'idle'
    return summary


def _same(r, mv):
    return (r['line'] == mv['line'] and r['group'] == mv.get('g', r['group']) and r['product'] == mv['p']
            and (r.get('cust') or '') == (mv.get('c') or '') and (r.get('dest') or '') == (mv.get('dest') or '') and (r.get('ship') or '') == (mv.get('ship') or '')
            and ('s' not in mv or (r.get('spec') or '') == (mv.get('s') or '')))


def _due_of(r, ym):
    if not r.get('due'):
        return None
    y, m = map(int, (r.get('dueYm') or ym).split('-'))
    try:
        return dt.date(y, m, int(r['due']))
    except ValueError:
        return None


def apply_moves(color, down, moves, supply, self_of, mix_of, yld=1.003):
    """캘린더 끌어 옮기기(2026-10-20 사용자): 사양·톤을 다른 날로 옮김. moves = [{line, from, to, g, p, c, dest, ship, t}].
    · 옮긴 몫은 그 날에 고정(시간 = 그 사양의 T/hr 로 다시 셈 — PES 100t 과 PGS 100t 은 시간이 다름)
    · 연속 공정: 옮긴 날 이후는 순서 그대로 다시 채움 — 넘친 일은 뒷날로 밀리고, 빈 시간은 바로 뒤 일을 당겨 채움.
      원래 계획에 있던 휴지 덩어리(하루 통째 빈 날)는 건너서 당기지 않음(휴지 집약 결과 유지)
    · 소재·납기는 막지 않고 영향으로 보고(사람이 정한 변경이라 결과를 보여 주고 판단)
    color 제자리 수정. 반환: {'applied': [...], 'skipped': [...], 'impact': {...}}"""
    D = lambda M, k: dt.date(M['year'], M['month'], k)
    days = [D(M, k) for M in color for k in range(M['startDay'], M['ndays'] + 1)]
    if not days or not moves:
        return None
    cap = lambda d, l: max(0.0, 1440.0 - (down or {}).get((d.isoformat(), l), 0))
    rows = [[D(M, r['day']), i, dict(r, _ym=r.get('dueYm') or M['ym'])] for M in color for i, r in enumerate(M['rows']) if r['day'] >= M['startDay']]
    before = [(d, dict(r)) for d, _, r in rows]
    load0 = Counter()
    for d, _, r in rows:
        load0[(d, r['line'])] += r['min']
    applied, skipped, pins, start = [], [], [], {}
    for k, mv in enumerate(moves):
        try:
            f, to = dt.date.fromisoformat(mv['from']), dt.date.fromisoformat(mv['to'])
        except (KeyError, ValueError):
            skipped.append({'move': mv, 'why': '날짜 형식'}); continue
        if f < days[0] or to < days[0] or to > days[-1]:
            skipped.append({'move': mv, 'why': f'계획 기간 밖(실적 날짜는 못 옮김, {days[0].month}/{days[0].day}~)'}); continue
        left = float(mv.get('t') or 0)
        got = 0.0
        src = f
        if not any(x[0] == f and _same(x[2], mv) and not x[2].get('pinned') for x in rows):
            # 화면에서 본 계획과 다시 계산한 계획이 조금 다를 수 있음(새 실적·자료) → 같은 사양을 가까운 날(±5일, 같은 거리면 앞날)에서 가져옴
            near = sorted({x[0] for x in rows if _same(x[2], mv) and not x[2].get('pinned') and abs((x[0] - f).days) <= 5}, key=lambda d: (abs((d - f).days), d))
            src = near[0] if near else f
        if src == to:
            skipped.append({'move': mv, 'why': f'다시 계산한 계획에선 그 사양이 이미 {to.month}/{to.day}에 있음'}); continue
        for x in [x for x in rows if x[0] == src and _same(x[2], mv) and not x[2].get('pinned')]:
            if left <= 0.05:
                break
            r = x[2]
            take = min(left, r['t'])
            fr = take / r['t'] if r['t'] else 1.0
            p = dict(r, t=take, min=r['min'] * fr, pinned=True, note=((r.get('note') or '') + f" · 수동 이동({src.month}/{src.day}→{to.month}/{to.day})").lstrip(' ·'))
            pins.append([to, 10_000 + k, p])
            r['t'] -= take
            r['min'] -= r['min'] * fr if fr < 1 else r['min']
            left -= take
            got += take
        rows = [x for x in rows if x[2]['t'] > 0.05]
        if got <= 0.05:
            skipped.append({'move': mv, 'why': '그 날 그 사양이 계획에 없음(계획이 바뀌었을 수 있음)'}); continue
        applied.append(dict(mv, t=round(got, 1), **({'fromActual': src.isoformat()} if src != f else {})))
        start[mv['line']] = min(start.get(mv['line'], days[-1]), src, to)
    out, spill, shifts = [x for x in rows if x[2]['line'] not in start or x[0] < start[x[2]['line']]], [], Counter()
    out += pins
    for l, s in start.items():
        pin_min = Counter()
        for d, _, r in pins:
            if r['line'] == l:
                pin_min[d] += r['min']
        mine = sorted((x for x in rows if x[2]['line'] == l and x[0] >= s), key=lambda x: (x[0], x[1]))
        used = Counter()
        ki = days.index(s)
        for d0, i, r in mine:
            if days[ki] < d0 and any(load0[(dd, l)] < 1 and cap(dd, l) > 0 for dd in days[ki:days.index(d0)]):
                ki = days.index(d0)                                  # 원래 계획의 휴지 덩어리는 건너 당기지 않음
            left = r['min']
            while left > 1e-6:
                if ki >= len(days):
                    spill.append(dict(r, min=left, t=r['t'] * left / r['min'])); break
                day = days[ki]
                room = cap(day, l) - pin_min[day] - used[day]
                if room <= 1e-6:
                    ki += 1; continue
                take = min(room, left)
                x = dict(r, min=take, t=r['t'] * take / r['min'])
                if day != d0:
                    x['note'] = ((r.get('note') or '') + f" · 수동 이동 영향({d0.month}/{d0.day}→{day.month}/{day.day})").lstrip(' ·')
                    shifts[(l, r['group'], r['product'], r.get('dest') or '', d0.isoformat(), day.isoformat())] += x['t']
                out.append([day, i, x])
                used[day] += take
                left -= take
    first = {M['ym']: M for M in color}
    for M in color:
        M['rows'] = [r for r in M['rows'] if r['day'] < M['startDay']]
    for d, _, x in out:
        M = first.get(f'{d.year}-{d.month:02d}')
        if M is None:
            continue
        y_ = dict(x, day=d.day)
        if x.get('due') and x.get('_ym') and x['_ym'] != M['ym']:
            y_['dueYm'] = x['_ym']
        y_.pop('_ym', None)
        M['rows'].append(y_)
    for M in color:
        M['rows'].sort(key=lambda r: (r['day'], r['line']))
        for s_ in spill:
            if s_.get('_ym') == M['ym']:
                M['unplaced'].append({'group': s_['group'], 'product': s_['product'], 'cust': s_.get('cust') or '', 'dest': s_.get('dest') or '', 'due': s_.get('due'), 't': s_['t']})
    after = [(D(M, r['day']), r) for M in color for r in M['rows'] if r['day'] >= M['startDay']]
    imp = move_impact(before, after, days, cap, supply, self_of, mix_of, yld, start, spill)
    sh = [{'line': k[0], 'g': k[1], 'p': k[2], 'dest': k[3], 'from': k[4], 'to': k[5], 't': round(v, 1)} for k, v in shifts.items() if v >= 0.5]
    imp['shifts'] = sorted(sh, key=lambda x: (x['line'], x['from'], x['to']))
    imp['shiftT'] = round(sum(x['t'] for x in sh), 1)
    imp['shiftLast'] = max((x['to'] for x in sh), default=None)
    return {'applied': applied, 'skipped': skipped, 'impact': imp}


def move_impact(before, after, days, cap, supply, self_of, mix_of, yld, start, spill):
    """옮기기 전·후 비교: 날짜별 시간(넘침·빈 시간) · 납기(선적 완료기한) 넘김 · 구매 소재 부족 · 밀린 물량"""
    lines = sorted(start)
    def load(rows):
        c = Counter()
        for d, r in rows:
            c[(d, r['line'])] += r['min']
        return c
    L0, L1 = load(before), load(after)
    cells = []
    for l in lines:
        for d in days:
            a, b = L0[(d, l)], L1[(d, l)]
            if abs(a - b) >= 30:
                cells.append({'line': l, 'd': d.isoformat(), 'before': round(a), 'after': round(b), 'cap': round(cap(d, l))})
    def late(rows):
        o = {}
        for d, r in rows:
            du = _due_of(r, r.get('_ym') or f'{d.year}-{d.month:02d}')
            if du and d > du:
                k = (r['line'], r['product'], r.get('dest') or '', du.isoformat())
                o[k] = o.get(k, 0) + r['t']
        return o
    lt0, lt1 = late(before), late(after)
    new_late = [{'line': k[0], 'p': k[1], 'dest': k[2], 'due': k[3], 't': round(v - lt0.get(k, 0), 1)} for k, v in lt1.items() if v - lt0.get(k, 0) >= 0.5]
    fixed_late = [{'line': k[0], 'p': k[1], 'dest': k[2], 'due': k[3], 't': round(v - lt1.get(k, 0), 1)} for k, v in lt0.items() if v - lt1.get(k, 0) >= 0.5]
    sup = {c: sorted(s.items()) for c, s in supply.items()}
    def short(rows):
        need = defaultdict(Counter)
        for d, r in rows:
            for c, t in _mat_need(r, self_of, mix_of, yld).items():
                need[c][d] += t
        horizon = days[0] + dt.timedelta(days=NEW_ORDER_LT + MAT_LEAD)   # 그 뒤는 신규 발주로 맞출 수 있음
        o = {}
        for c, ser in need.items():
            acc_n, worst, first = 0.0, 0.0, None
            for d in sorted(ser):
                if d > horizon:
                    break
                acc_n += ser[d]
                acc_s = sum(t for dd, t in sup.get(c, []) if dd <= d.isoformat())
                if acc_n - acc_s > worst + 0.5:
                    worst = acc_n - acc_s
                    first = first or d.isoformat()
            if worst > 0.5:
                o[c] = (round(worst), first)
        return o
    s0, s1 = short(before), short(after)
    mat = [{'code': c, 'before': s0.get(c, (0, None))[0], 'after': v[0], 'first': v[1]} for c, v in s1.items() if v[0] - s0.get(c, (0, None))[0] >= 1] \
        + [{'code': c, 'before': v[0], 'after': s1.get(c, (0, None))[0], 'first': None} for c, v in s0.items() if v[0] - s1.get(c, (0, None))[0] >= 1]
    return {'cells': cells, 'newLate': new_late, 'fixedLate': fixed_late, 'mat': mat,
            'spill': [{'line': s['line'], 'p': s['product'], 't': round(s['t'], 1)} for s in spill if s['t'] >= 0.5]}


def supply_from(T, today):
    """컬러 구매 소재 공급 {코드: {날짜: t}} — 웹 계산 묶음에는 미리 계산한 'color_supply' 표(톤만)가 실림, 없으면 원자료로 계산(cglplan.pages.color_supply)"""
    if T.get('color_supply'):
        sup = defaultdict(Counter)
        for c, d, t in T['color_supply']['rows']:
            sup[c][d] += t
        return sup
    from cglplan import pages as PG
    return PG.color_supply(T, today)
