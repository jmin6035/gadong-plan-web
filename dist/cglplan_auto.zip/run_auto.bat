@echo off
chcp 65001 >nul
cd /d %~dp0
set PYTHONUTF8=1
rem ① (선택) MES 엑셀을 내려받는 기존 파이썬 코드 실행 — 경로를 실제 파일로 바꾸고 앞의 rem 을 지우세요
rem py "D:\작업방\python\MES_다운로드.py"
rem ② 누적 → 재계획 → Supabase 게시
py -m cglplan auto --config auto_config.json
