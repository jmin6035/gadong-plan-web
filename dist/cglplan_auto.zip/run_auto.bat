@echo off
chcp 65001 >nul
cd /d %~dp0
set PYTHONUTF8=1
rem MES 내려받기(생산·휴지 쿼리 + 생산실적 화면) → 누적 → 실적 분석 → 재계획 → Supabase 게시
rem 실행 기록: out\run_log.txt (창이 닫혀도 남음)
if not exist out mkdir out
where py >nul 2>nul
if errorlevel 1 (
  echo [오류] 파이썬 실행기 py 를 찾을 수 없습니다. 파이썬 설치가 필요합니다. > out\run_log.txt
  type out\run_log.txt
  timeout /t 1800
  exit /b 1
)
if not exist auto_config.json (
  echo [오류] auto_config.json 이 이 폴더에 없습니다. 기존 설치 폴더의 auto_config.json 을 복사하세요. > out\run_log.txt
  type out\run_log.txt
  timeout /t 1800
  exit /b 1
)
py mes_download.py
if errorlevel 1 (
  echo.
  echo [오류] 실행 중 문제가 생겼습니다. 위 메시지 또는 out\run_log.txt 를 사진으로 보내주세요.
  echo 이 창은 30분 뒤 닫힙니다. 아무 키나 누르면 바로 닫힙니다.
  timeout /t 1800
  exit /b 1
)
