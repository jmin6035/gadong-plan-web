@echo off
cd /d "%~dp0"
set PYTHONUTF8=1
if not exist out mkdir out
echo [CGL] start %date% %time%
where py >nul 2>nul
if errorlevel 1 goto nopy
if not exist auto_config.json goto nocfg
py mes_download.py
if errorlevel 1 goto fail
echo [CGL] done
exit /b 0
:nopy
echo [ERROR] Python launcher "py" not found. Python is not installed on this PC.
echo [ERROR] Python launcher not found > out\run_log.txt
timeout /t 1800
exit /b 1
:nocfg
echo [ERROR] auto_config.json is missing in this folder: %~dp0
echo [ERROR] Copy auto_config.json from the old install folder.
echo [ERROR] auto_config.json missing > out\run_log.txt
timeout /t 1800
exit /b 1
:fail
echo.
echo [ERROR] Failed. Send a photo of this window or out\run_log.txt
timeout /t 1800
exit /b 1
