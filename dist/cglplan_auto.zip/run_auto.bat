@echo off
chcp 65001 >nul
cd /d %~dp0
set PYTHONUTF8=1
rem MES 내려받기(생산·휴지 쿼리 + 생산실적 화면) → 누적 → 실적 분석 → 재계획 → Supabase 게시
py mes_download.py
