@echo off
cd /d "%~dp0"
rem daily 07:25 (after the sales/production report updates around 07:16). PC must be on and logged in.
rem remove the old task name (Korean) if it was registered before - written with escapes to keep this file ASCII
py -c "import subprocess; subprocess.run(['schtasks','/Delete','/TN','CGL \uc790\ub3d9\uc218\uc9d1','/F'], capture_output=True)" >nul 2>nul
schtasks /Create /TN "CGL auto" /TR "\"%~dp0run_auto.bat\"" /SC DAILY /ST 07:25 /F
if errorlevel 1 (
  echo [ERROR] Register failed. Run Command Prompt as administrator and try again.
) else (
  echo [OK] Registered: daily 07:25 run_auto.bat
  schtasks /Query /TN "CGL auto"
)
pause
