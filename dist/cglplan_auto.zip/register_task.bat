@echo off
cd /d "%~dp0"
rem daily 07:35 full run + every 2h remote queries; missed runs start when the PC is back on (registration lives in mes_download.py)
py mes_download.py --register
pause
