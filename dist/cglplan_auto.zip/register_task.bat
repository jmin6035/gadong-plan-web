@echo off
chcp 65001 >nul
cd /d %~dp0
rem 매일 07:40 자동 실행 등록(판매생산속보가 07:16쯤 갱신된 뒤). 그 시각에 PC가 켜져 있고 로그인돼 있어야 함
schtasks /Create /TN "CGL 자동수집" /TR "\"%~dp0run_auto.bat\"" /SC DAILY /ST 07:40 /F
if errorlevel 1 (
  echo 등록 실패 - 명령 프롬프트를 '관리자 권한으로 실행'해서 다시 해 보세요.
) else (
  echo 등록됨: 매일 07:40 run_auto.bat
  schtasks /Query /TN "CGL 자동수집"
)
pause
