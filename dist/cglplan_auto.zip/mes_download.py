"""MES 자동 다운로드(사내 PC) → mes/ 폴더 → 자동 실행기(python -m cglplan auto).
받은 기존 MES 코드(Edge 자동화)의 로그인·쿼리 화면·엑셀 Export 방식을 그대로 쓰고, 도금 가동계획에 필요한 것만 받는다.
  ① 생산 쿼리(코일 1줄: 라인·도금종류·중량·시각)   → mes/q_prod.json
  ② 휴지 쿼리(생산번호 1줄: 휴지 시작·종료·사유)    → mes/q_brk.json
  ③ 생산실적 조회 화면(도금: 부서·계약·두께·폭)      → mes/screen_prod.json
결과 표는 화면에서 직접 읽어 .json 으로 저장한다(엑셀 파일을 거치지 않으므로 회사 문서보안(DRM)이 걸리지 않음).
화면 표를 못 읽으면 기존 방식(엑셀 Export, .xlsx)으로 받는다.
실행:  py mes_download.py                 (어제까지 최근 14일)
       py mes_download.py --from 20260701 (처음 한 번: 과거 실적 채우기)
       py mes_download.py --no-auto       (내려받기만)
로그인 정보는 auto_config.json 의 "mes": {"id": "...", "pw": "...", "url": "(선택) 접속 주소"} 또는 환경변수 MES_ID / MES_PW 에서 읽는다(코드에 적지 않음)."""
import argparse
import datetime
import glob
import json
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
MES_URL = 'https://intra-mes.poscosteeleon.com:8443/SCOM/main.do'


def q_prod(d0, d1):
    return ("select distinct a.prd_no as prd_no, a.pdt_no as pdt_no, TO_CHAR(to_date(a.prd_dt, 'YYYYMMDD'), 'YYYY-MM-DD') as prd_dt, a.line_cls as line_cls, "
            "TO_CHAR(a.wrk_sta_tm, 'YYYY-MM-DD HH24:MI:SS') as wrk_sta_tm, TO_CHAR(a.wrk_end_tm, 'YYYY-MM-DD HH24:MI:SS') as wrk_end_tm, "
            "a.wrk_time as tot_wrk_time, a.pau_time as tot_pau_time, a.opr_time as tot_opr_time, a.cot_cls as cot_cls, a.pdt_net_wgt as pdt_net_wgt, a.viw_grd as viw_grd "
            f"from sops.pf_cg_prod_rslt a where a.prd_dt between '{d0}' and '{d1}' and a.line_cls in ('A', 'B') order by line_cls, wrk_sta_tm")


def q_brk(d0, d1):
    nm = lambda c: f"(select cd_nm from scom.scom_code_detail where master_cd in ('CLR_NOPR_PAU_CD', 'CMN_NOPR_PLN_PAU_CD') and cd_val = {c})"
    cols = ["b.prd_no as prd_no", "(select max(a.line_cls) from sops.pf_cg_prod_rslt a where a.prd_no = b.prd_no) as line_cls"]
    for i in (1, 2, 3):
        cols += [f"TO_CHAR(b.pau_sta_tm_{i}, 'YYYY-MM-DD HH24:MI:SS') as pau_sta_tm_{i}", f"TO_CHAR(b.pau_end_tm_{i}, 'YYYY-MM-DD HH24:MI:SS') as pau_end_tm_{i}",
                 f"(CAST(b.pau_end_tm_{i} AS DATE) - CAST(b.pau_sta_tm_{i} AS DATE)) * 24 * 60 as pau_time_{i}"]
    for i in (1, 2, 3):
        cols += [f"b.pau_rsn_cd_{i} as pau_rsn_cd_{i}", f"{nm(f'b.pau_rsn_cd_{i}')} as pau_rsn_cd_{i}_nm"]
    cols += ["b.pau_cls as pau_cls", "b.pau_dtl_cls as pau_dtl_cls", f"{nm('b.pau_dtl_cls')} as pau_dtl_cls_nm"]
    return (f"select {', '.join(cols)} from sops.pf_cg_brk b where b.prd_no in (select a.prd_no from sops.pf_cg_prod_rslt a "
            f"where a.prd_dt between '{d0}' and '{d1}' and a.line_cls in ('A', 'B')) order by 2, 3")


def creds():
    cfg = {}
    p = os.path.join(HERE, 'auto_config.json')
    if os.path.exists(p):
        cfg = json.loads(open(p, encoding='utf-8-sig').read(), strict=False).get('mes') or {}
    uid, pw = os.environ.get('MES_ID') or cfg.get('id'), os.environ.get('MES_PW') or cfg.get('pw')
    if not uid or not pw:
        sys.exit('MES 로그인 정보가 없습니다 — auto_config.json 에 "mes": {"id": "...", "pw": "..."} 를 넣거나 환경변수 MES_ID/MES_PW 를 설정하세요')
    return uid, pw, (os.environ.get('MES_URL') or cfg.get('url') or MES_URL).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--from', dest='d0', help='시작일 YYYYMMDD (기본: 14일 전)')
    ap.add_argument('--to', dest='d1', help='종료일 YYYYMMDD (기본: 어제)')
    ap.add_argument('--days', type=int, default=14)
    ap.add_argument('--no-auto', action='store_true', help='내려받기만 하고 자동 실행기는 돌리지 않음')
    ap.add_argument('--out', default=os.path.join(HERE, 'mes'))
    a = ap.parse_args()
    today = datetime.date.today()
    d1 = a.d1 or (today - datetime.timedelta(days=1)).strftime('%Y%m%d')
    d0 = a.d0 or (today - datetime.timedelta(days=a.days)).strftime('%Y%m%d')
    fmt = lambda s: f'{s[:4]}-{s[4:6]}-{s[6:]}'
    os.makedirs(a.out, exist_ok=True)
    dl = os.path.join(HERE, '_mes_dl')
    shutil.rmtree(dl, ignore_errors=True)
    os.makedirs(dl)
    uid, pw, mes_url = creds()

    try:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    except ImportError:
        pass
    try:
        import selenium  # noqa: F401
    except ImportError:
        sys.exit('selenium 이 설치되지 않았습니다 — install.bat 을 다시 실행하세요')
    os.environ['WDM_SSL_VERIFY'] = '0'
    from selenium import webdriver
    from selenium.webdriver.common.action_chains import ActionChains
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.edge.options import Options
    from selenium.webdriver.edge.service import Service
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait

    opts = Options()
    opts.add_experimental_option('prefs', {'download.default_directory': dl, 'download.prompt_for_download': False, 'download.directory_upgrade': True})
    opts.add_experimental_option('excludeSwitches', ['enable-logging'])
    opts.add_argument('--log-level=3')
    try:
        from webdriver_manager.microsoft import EdgeChromiumDriverManager
        service = Service(EdgeChromiumDriverManager().install())
    except Exception as e:                       # 드라이버 자동 설치가 막히면 PC에 설치된 msedgedriver 사용
        print('Edge 드라이버 자동 설치 실패 — 기본 드라이버로 시도:', e)
        service = Service()
    service.creation_flags = 0x08000000
    driver = webdriver.Edge(service=service, options=opts)
    driver.maximize_window()
    ok_files = []

    def wait_download(before, name, timeout=60):
        while timeout > 0:
            new = set(os.listdir(dl)) - before
            f = next((x for x in new if not x.endswith(('.crdownload', '.tmp'))), None)
            if f:
                time.sleep(1)
                dst = os.path.join(a.out, name)
                if os.path.exists(dst):
                    os.remove(dst)
                shutil.move(os.path.join(dl, f), dst)
                print(f'  ✅ {name}')
                ok_files.append(name)
                return True
            time.sleep(1)
            timeout -= 1
        print(f'  ❌ {name} 다운로드 시간 초과')
        return False

    def export(cell_xpath, name):
        before = set(os.listdir(dl))
        for attempt in range(3):
            try:
                cell = WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH, cell_xpath)))
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", cell)
                ActionChains(driver).move_to_element(cell).click().perform()
                time.sleep(0.5)
                ActionChains(driver).context_click(cell).perform()
                time.sleep(2)
                for btn in driver.find_elements(By.XPATH, "//*[contains(text(), '엑셀 Export') or contains(text(), 'Excel') or contains(text(), '엑셀')]"):
                    if btn.is_displayed():
                        driver.execute_script('arguments[0].click();', btn)
                        ok = wait_download(before, name)
                        ActionChains(driver).send_keys(Keys.ESCAPE).perform()
                        return ok
                ActionChains(driver).send_keys(Keys.ESCAPE).perform()
                time.sleep(2)
            except Exception as e:
                print(f'  ⚠ Export 시도 {attempt + 1} 실패: {e}')
        print(f'  ❌ {name}: 엑셀 Export 버튼을 찾지 못함')
        return False

    FIND_JS = r'''
      var jq = window.$ || window.jQuery; if (!jq) return null;
      var g = arguments[0] ? jq('#' + arguments[0]) : null;
      if (!g || !g.length) { g = null; jq('.jqx-grid').each(function () { if (!g && jq(this).is(':visible')) g = jq(this); }); }
      if (!g || !g.length || typeof g.jqxGrid !== 'function') return null;'''
    COUNT_JS = FIND_JS + r'''
      var rows = g.jqxGrid('getrows') || []; return rows.length;'''
    CLEAR_JS = FIND_JS + r'''
      try { g.jqxGrid('clear'); } catch (e) {} return true;'''
    GRID_JS = FIND_JS + r'''
      var cols = g.jqxGrid('columns'); cols = cols.records || cols;
      var keep = [], head = [];
      for (var i = 0; i < cols.length; i++) { var c = cols[i]; if (!c.datafield || c.hidden) continue; keep.push(c.datafield); head.push(c.text || c.datafield); }
      var rows = g.jqxGrid('getrows') || [], out = [];
      for (var r = 0; r < rows.length; r++) { var a = []; for (var k = 0; k < keep.length; k++) { var v = rows[r][keep[k]]; a.push(v === undefined ? null : (v instanceof Date ? v.toISOString() : v)); } out.push(a); }
      return JSON.stringify({columns: head, rows: out});'''

    def wait_rows(grid_id, timeout=120):
        """조회 버튼을 누른 뒤 표 건수가 0보다 크고 두 번 연속 같아질 때까지 기다림. 끝내 0이면 0"""
        last, t = -1, 0
        while t < timeout:
            time.sleep(3)
            t += 3
            try:
                n = driver.execute_script(COUNT_JS, grid_id)
            except Exception:
                n = None
            if n and n == last:
                return n
            last = n
        return last or 0

    def read(grid_id):
        txt = driver.execute_script(GRID_JS, grid_id)
        return json.loads(txt) if txt else None

    def chunks(step=10):
        """조회 기간을 step일 단위로 나눔(쿼리 화면 10,000행 제한 회피)"""
        f, t = datetime.datetime.strptime(d0, '%Y%m%d').date(), datetime.datetime.strptime(d1, '%Y%m%d').date()
        while f <= t:
            e = min(f + datetime.timedelta(days=step - 1), t)
            yield f.strftime('%Y%m%d'), e.strftime('%Y%m%d')
            f = e + datetime.timedelta(days=1)

    def save(o, name):
        try:
            if not o or not o['rows']:
                print(f'  ⚠ {name}: 표가 비어 있음')
                return False
            for ext in ('.json', '.xlsx'):                 # 같은 이름의 이전 파일(형식이 다른 것 포함) 정리
                old = os.path.join(a.out, name + ext)
                if os.path.exists(old):
                    os.remove(old)
            json.dump(o, open(os.path.join(a.out, name + '.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            print(f"  ✅ {name}.json ({len(o['rows'])}행, 화면에서 직접 읽음)")
            ok_files.append(name)
            return True
        except Exception as e:
            print(f'  ⚠ {name}: 저장 실패 ({e})')
            return False

    def run_chunks(name, grid_id, run_one, step):
        """기간을 나눠 조회한 결과를 하나로 합쳐 저장. 표 직접 읽기가 안 되면 None"""
        merged = None
        for c0, c1 in chunks(step):
            try:
                driver.execute_script(CLEAR_JS, grid_id)
            except Exception:
                pass
            run_one(c0, c1)
            n = wait_rows(grid_id)
            o = read(grid_id) if n else None
            if n and o is None:
                print('  ⚠ 화면 표 직접 읽기 실패 — 엑셀 Export 로 시도')
                return None
            k = len(o['rows']) if o else 0
            print(f'    {c0}~{c1}: {k}행' + ('  ⚠ 10,000행 — 잘렸을 수 있음(기간을 더 나눠야 함)' if k >= 10000 else ''))
            if o:
                if merged is None:
                    merged = o
                elif o['columns'] == merged['columns']:
                    merged['rows'] += o['rows']
                else:
                    print('  ⚠ 기간별 열 구성이 달라 이 구간은 제외')
        if merged:                                       # 구간 경계에 걸친 생산번호의 휴지 등 완전히 같은 행은 하나만
            seen, uniq = set(), []
            for r in merged['rows']:
                k = json.dumps(r, ensure_ascii=False)
                if k not in seen:
                    seen.add(k)
                    uniq.append(r)
            if len(uniq) < len(merged['rows']):
                print(f"    중복 {len(merged['rows']) - len(uniq)}행 제외")
            merged['rows'] = uniq
        save(merged, name)
        return True

    def menu(name):
        driver.switch_to.default_content()
        try:
            driver.execute_script('arguments[0].click();', WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="collapseButton"]'))))
            time.sleep(1)
        except Exception:
            pass
        box = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, '//*[@id="SEARCH_VAL"]')))
        box.send_keys(Keys.CONTROL + 'a', Keys.BACKSPACE, name, Keys.ENTER)
        time.sleep(2)
        driver.execute_script('arguments[0].click();', WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, f"//*[text()='{name}' or contains(text(), '{name}')]"))))
        time.sleep(6)

    def frame_with(xpath, visible=False):
        for fr in reversed(driver.find_elements(By.TAG_NAME, 'iframe')):
            try:
                driver.switch_to.default_content()
                driver.switch_to.frame(fr)
                cond = EC.visibility_of_element_located if visible else EC.presence_of_element_located
                return WebDriverWait(driver, 3).until(cond((By.XPATH, xpath)))
            except Exception:
                pass
        return None

    try:
        driver.get(mes_url)
        print('로그인…')
        WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH, '//*[@id="username"]'))).send_keys(uid)
        driver.find_element(By.XPATH, '//*[@id="password_input"]').send_keys(pw)
        driver.find_element(By.XPATH, '//*[@id="loginsubmit"]').click()
        time.sleep(8)
        # ①② 쿼리 화면
        print(f'쿼리 화면 — 기간 {d0} ~ {d1}')
        menu('쿼리')
        box = frame_with('//*[@id="QUERY_CONTTextArea"]')
        if box is None:
            raise RuntimeError('쿼리 입력창을 찾지 못함')
        def run_sql(sql):
            box.send_keys(Keys.CONTROL + 'a', Keys.BACKSPACE)
            time.sleep(0.5)
            box.send_keys(sql)
            driver.execute_script('arguments[0].click();', driver.find_element(By.XPATH, '//*[@id="mnuCust1Btn"]/span'))
        # 생산은 10일씩(하루 최대 ~540코일 → 10일 ≤ 5,400행), 휴지는 행이 적어 15일씩
        for name, mk, step in [('q_prod.xlsx', q_prod, 10), ('q_brk.xlsx', q_brk, 15)]:
            print(f'▶ {name}')
            if run_chunks(name[:-5], 'gridQueryRslt', lambda c0, c1: run_sql(mk(c0, c1)), step) is None:
                run_sql(mk(d0, d1))
                time.sleep(15)
                export('//*[@id="row0gridQueryRslt"]/div[1]', name)
        # ③ 생산실적 조회(도금) 화면
        print('▶ screen_prod.xlsx (생산실적 조회)')
        menu('생산실적 조회')
        if frame_with('//*[@id="dropdownlistContentS_PLT_CLS"]') is None:
            raise RuntimeError('생산실적 조회 화면을 찾지 못함')
        driver.execute_script("try { var jq = window.$ || window.jQuery; var dd = jq('#S_PLT_CLS'); var it = dd.jqxDropDownList('getItems'); "
                              "for (var i = 0; i < it.length; i++) { if (it[i].label.indexOf('도금') !== -1) { dd.jqxDropDownList('selectIndex', it[i].index); break; } } } catch (e) {}")
        time.sleep(1)
        SET_DATE_JS = r'''
          var jq = window.$ || window.jQuery, s = arguments[1], out = [];
          ['S_PRD_DT_FR', 'S_PRD_DT_TO'].forEach(function (id, i) {
            var v = s[i], d = new Date(+v.slice(0, 4), +v.slice(4, 6) - 1, +v.slice(6, 8));
            try { jq('#' + id).jqxDateTimeInput('setDate', d); out.push(jq('#' + id).jqxDateTimeInput('getText')); } catch (e) { out.push(null); }
          });
          return out;'''

        def run_screen(c0, c1):
            got = driver.execute_script(SET_DATE_JS, None, [c0, c1])
            if not got or None in got:                   # 날짜 위젯 함수가 없으면 키보드 입력
                for xp, v in (('//*[@id="inputS_PRD_DT_FR"]', c0), ('//*[@id="inputS_PRD_DT_TO"]', c1)):
                    el = driver.find_element(By.XPATH, xp)
                    el.click()
                    el.send_keys(Keys.CONTROL + 'a', Keys.BACKSPACE, fmt(v), Keys.TAB)
                got = [driver.find_element(By.XPATH, '//*[@id="inputS_PRD_DT_FR"]').get_attribute('value'),
                       driver.find_element(By.XPATH, '//*[@id="inputS_PRD_DT_TO"]').get_attribute('value')]
            want = [fmt(c0), fmt(c1)]
            if [str(x or '').replace('/', '-').replace('.', '-')[:10] for x in got] != want:
                print(f'    ⚠ 화면 날짜가 {got} 로 들어감(원한 값 {want})')
            driver.execute_script('arguments[0].click();', WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="mnuSearchBtn"]/span'))))
        if run_chunks('screen_prod', None, run_screen, 10) is None:
            export("//div[contains(@class, 'jqx-grid-cell')]", 'screen_prod.xlsx')
    finally:
        driver.quit()
        shutil.rmtree(dl, ignore_errors=True)
    print('받은 파일:', ok_files)
    if len(ok_files) < 3:
        print('⚠ 일부 파일을 받지 못했습니다 — 자동 실행기는 받은 파일로만 돕니다(누적 저장소에 이전 자료가 있으면 그대로 유지)')
    if not a.no_auto and ok_files:
        sys.exit(subprocess.call([sys.executable, '-m', 'cglplan', 'auto', '--config', os.path.join(HERE, 'auto_config.json')], cwd=HERE))


if __name__ == '__main__':
    main()
