@echo off
chcp 65001 >nul
cd /d %~dp0
echo 파이썬 패키지를 설치합니다...
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo 일반 설치 실패 - 회사 인증서 우회 옵션으로 다시 시도합니다...
  py -m pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt
)
echo.
echo 끝났습니다. 위에 빨간 오류(ERROR)가 없으면 성공입니다.
pause
