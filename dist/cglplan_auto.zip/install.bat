@echo off
cd /d "%~dp0"
echo Installing Python packages...
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Retrying with trusted-host option for company certificate...
  py -m pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt
)
echo.
echo Finished. If there is no red ERROR above, it succeeded.
pause
