﻿CGL 가동계획 자동 실행기 (사내 PC용)

1) 파이썬 패키지 설치(최초 1회): install.bat 더블클릭
   (직접 하려면 명령 프롬프트에서: py -m pip install -r requirements.txt)
   (회사 인증서 오류가 나면: py -m pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt)
2) auto_config.example.json 을 복사해 auto_config.json 으로 저장하고 값 채우기
   - supabase.key: Supabase → Project Settings → API Keys → Secret keys 의 키 (절대 공유 금지)
   - password: 대시보드 게시 암호
   - mes_inputs: MES 코드가 내려받는 도금 생산실적 엑셀 경로
3) 연결 확인:  py -m cglplan supatest --config auto_config.json
4) 시험 실행(업로드 없음): py -m cglplan auto --config auto_config.json --dry
5) 실제 실행: run_auto.bat  (윈도우 작업 스케줄러에 매일 등록)
처음엔 published_path 가 test.plan.enc.json(시험 위치)입니다. 확인 후 latest.plan.enc.json 으로 바꾸면 모두가 보는 대시보드에 반영됩니다.
