"""사내 PC 자동 실행기: MES 엑셀 → 누적 → 실적 분석 → 재계획(최적 증명까지) → 암호화 → Supabase 게시 + 누적 실적 업로드.
실행: python -m cglplan auto --config auto_config.json [--dry] [--force]
  --dry   : 업로드하지 않고 out_dir 에만 저장(시험용)
  --force : 새 실적이 없어도 재계획
설정 예시는 auto_config.example.json. 키·암호가 들어가므로 설정 파일은 저장소에 올리지 않는다."""
import datetime as _dt
import glob
import json
import os
import ssl
import time
import traceback
import urllib.request

from . import mes, publish as PB, replan as RP, store as ST, util as U
from .supa import Supa, make_ctx

GITHUB_PUBLISHED = 'https://jmin6035.github.io/gadong-plan-web/published/latest.plan.enc.json'
DEFAULTS = {'window_days': 91, 'published_bucket': 'published', 'published_path': 'latest.plan.enc.json', 'analysis_path': '', 'analysis_password': '', 'data_bucket': 'mes',
            'replan': {'freeze': 2, 'tradeoff': 100, 'stab': 10}, 'push_data': True, 'label': ''}


def load_config(path):
    try:
        cfg = json.loads(open(path, encoding='utf-8-sig').read(), strict=False)   # 메모장 BOM·붙여넣기 줄바꿈 허용
    except json.JSONDecodeError as e:
        raise SystemExit(f'설정 파일 {path} 형식 오류({e.lineno}번째 줄 {e.colno}번째 글자): 따옴표·쉼표·중괄호를 확인하세요')
    if isinstance(cfg.get('supabase'), dict):
        cfg['supabase']['key'] = ''.join(str(cfg['supabase'].get('key', '')).split())      # 키에 섞인 줄바꿈·공백 제거
        cfg['supabase']['url'] = str(cfg['supabase'].get('url', '')).strip()
    out = dict(DEFAULTS)
    out.update(cfg)
    out['replan'] = dict(DEFAULTS['replan'], **(cfg.get('replan') or {}))
    for k in ('mes_inputs', 'store', 'out_dir', 'password'):
        if not out.get(k):
            raise SystemExit(f'설정 파일에 {k} 가 없습니다')
    return out


def _get(url, ssl_verify=True, timeout=60):
    ctx = make_ctx(ssl_verify)
    try:
        with urllib.request.urlopen(urllib.request.Request(url + f'?v={int(time.time())}', headers={'Cache-Control': 'no-cache'}), timeout=timeout, context=ctx) as r:
            return json.loads(r.read())
    except Exception:
        return None


def _stamp(e):
    return (e or {}).get('created') or (e or {}).get('savedAt') or ''


def load_base(cfg, sb, log):
    """기준 계획: 설정의 base_result(로컬 json) 또는 게시본 중 최신(Supabase·GitHub) → 복호화"""
    if cfg.get('base_result'):
        o = json.load(open(cfg['base_result'], encoding='utf-8'))
        log(f"기준 계획: 로컬 파일 {cfg['base_result']}")
    else:
        cands = []
        if sb:
            b = sb.download(cfg['published_bucket'], cfg['published_path'], public=True)
            if b:
                cands.append(('Supabase', json.loads(b)))
        g = _get(GITHUB_PUBLISHED, (cfg.get('supabase') or {}).get('ssl_verify', True))
        if g:
            cands.append(('GitHub', g))
        if not cands:
            return None, None
        src, o = max(cands, key=lambda x: _stamp(x[1]))
        log(f"기준 계획: {src} 게시본 ({_stamp(o)})")
    if o.get('app') == 'cgl-plan-enc':
        o = PB.decrypt(o, cfg['password'])
    return (o['result'], o.get('meta') or {}) if o.get('app') == 'cgl-plan' else (o, {})


def run(cfg, dry=False, force=False):
    os.makedirs(cfg['out_dir'], exist_ok=True)
    t0 = time.time()
    logf = open(os.path.join(cfg['out_dir'], 'auto_log.txt'), 'a', encoding='utf-8')
    now = _dt.datetime.now()

    def log(m):
        line = f'[{now:%Y-%m-%d %H:%M}] {time.time() - t0:5.0f}s {m}'
        print(line, flush=True)
        logf.write(line + '\n')
        logf.flush()

    st = ST.Store(cfg['store'])
    sbc = cfg.get('supabase') or {}
    sb = Supa(sbc['url'], sbc['key'], sbc.get('ssl_verify', True)) if sbc.get('url') and sbc.get('key') else None
    if not sb and not dry:
        raise SystemExit('설정에 supabase.url/key 가 없습니다(시험은 --dry)')
    try:
        # 1) MES 엑셀 → 정제 → 누적
        pats = list(cfg['mes_inputs']) + [pat[:-5] + ext for pat in cfg['mes_inputs'] if pat.lower().endswith('.xlsx') for ext in ('.json', '.csv')]
        paths = sorted({p for pat in pats for p in glob.glob(pat) if not os.path.basename(p).startswith('~$')})   # ~$ = 엑셀이 열어둔 임시파일
        if not paths:
            raise RuntimeError(f"MES 엑셀이 없습니다: {cfg['mes_inputs']}")
        sheets, okp = [], []
        for p in paths:
            try:
                sheets += mes.sheets_from_workbooks([p])
                okp.append(p)
            except Exception as e:
                log(f"  [warn] 읽지 못한 파일(건너뜀): {os.path.basename(p)} — {e}. 엑셀로 열어 '다른 이름으로 저장 → Excel 통합 문서(*.xlsx)'로 다시 저장하거나, 문서보안(DRM) 해제 후 넣으세요")
        if not okp:
            raise RuntimeError('읽을 수 있는 MES 엑셀이 없습니다')
        paths = okp
        cl = mes.clean(mes.tables(sheets))
        for c in cl['checks']:
            log(f"  [{c['level']}] {c['msg']}")
        if any(c['level'] == 'error' for c in cl['checks']):
            raise RuntimeError('MES 엑셀 해석 오류')
        new, chg = st.upsert(cl['coils'])
        nst = st.upsert_stops(cl['stops'])
        last = st.last_day()
        log(f"MES {len(paths)}개 파일, 코일 {len(cl['coils'])}개 → 누적 신규 {new} · 변경 {chg}, 휴지 {len(cl['stops'])}건(신규 {nst}) (누적 마지막 날 {last})")

        # 2) 기준 계획
        R, meta = load_base(cfg, sb, log)
        P = R['P'] if R else U.default_params()

        # 3) 실적 분석(최근 window_days)
        d_from = U.add_days(last, -cfg['window_days'])
        win = st.coils(d_from)
        an = mes.analyze(win, P, stops=st.stops(mes.to_min(d_from)))
        summ = mes.summary(an, cl)
        for c in an['cands']:
            if c['apply']:
                log(f"  반영 권장: {c['label']} {c['cur']} → {c['act']:.4g} ({c['basis']})")

        # 4) 재계획
        auto = {'runAt': _dt.datetime.now(_dt.timezone.utc).isoformat(), 'newCoils': new, 'changedCoils': chg, 'replanned': False, 'notes': []}
        R2 = R
        if R is None:
            auto['notes'].append('게시된 기준 계획이 없어 재계획 생략(분석만)')
            log(auto['notes'][-1])
        else:
            H = U.horizon(P)
            coils_h = st.coils(H['D0'])
            act = mes.to_actual(mes.analyze(coils_h, P, stops=st.stops(mes.to_min(H['D0']))), coils_h, R) if coils_h else {'checks': [{'level': 'error', 'msg': f"아직 계획 기간({H['D0']}~) 실적 없음 — 분석만"}], 'quiet': True}
            for c in act.get('checks', []):
                if not act.get('quiet'):
                    log(f"  [{c['level']}] {c['msg']}")
            if any(c['level'] == 'error' for c in act.get('checks', [])):
                auto['notes'].append('재계획 생략: ' + '; '.join(c['msg'] for c in act['checks'] if c['level'] == 'error'))
                log(auto['notes'][-1])
            elif not force and (R.get('replan') or {}).get('t0') == act['t0'] and not (new or chg):
                auto['notes'].append(f"새 실적 없음(기준일 {act['t0']} 그대로) — 재계획 생략")
                auto['actualTo'] = act['t0']
                log(auto['notes'][-1])
            else:
                o = cfg['replan']
                R2 = RP.replan(R, act, {'freezeDays': o['freeze'], 'lateW': 1 / o['tradeoff'], 'stabW': 1 / o['stab'], 'stabW2': 5000 / o['stab']}, log)
                auto.update(replanned=True, actualTo=act['t0'], optimal=R2['replan'].get('optimal'))
                auto['warns'] = [c['msg'] for c in act.get('checks', []) if c['level'] == 'warn']

        # 5) 게시
        out = {'mes': summ, 'auto': auto}
        if R2 is not None:
            meta = dict(meta or {}, **out)
            env = PB.pack(R2, meta)
            json.dump(env, open(os.path.join(cfg['out_dir'], 'latest_result.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            P2 = R2['P']
            label = cfg['label'] or f"{P2['year']} {P2['months'][0]}~{P2['months'][-1]}월 계획" + (f" (MES 실적 ~{auto['actualTo']})" if auto.get('actualTo') else '')
            enc = json.dumps(PB.encrypt(env, cfg['password'], label))
            if dry:
                open(os.path.join(cfg['out_dir'], cfg['published_path']), 'w', encoding='utf-8').write(enc)
                log(f"[시험] 게시 파일 저장: {os.path.join(cfg['out_dir'], cfg['published_path'])}")
            else:
                sb.upload(cfg['published_bucket'], cfg['published_path'], enc)
                log(f"게시 완료: {cfg['published_bucket']}/{cfg['published_path']} ({label})")
        # 5-2) 분석 화면용 결과(별도 암호, 없으면 게시 암호) — 시험 위치(test.*)면 분석도 test.analysis.enc.json
        apath = cfg['analysis_path'] or ('test.analysis.enc.json' if cfg['published_path'].startswith('test') else 'analysis.enc.json')
        full = dict(mes.export(an, cl, win), analyzedAt=auto['runAt'], auto=auto)
        aenc = json.dumps(PB.encrypt(full, cfg['analysis_password'] or cfg['password'], f"실적 분석 {an['period']['from']}~{an['period']['to']}"))
        if dry:
            open(os.path.join(cfg['out_dir'], apath), 'w', encoding='utf-8').write(aenc)
            log(f'[시험] 분석 파일 저장: {apath}')
        else:
            sb.upload(cfg['published_bucket'], apath, aenc)
            log(f"분석 게시 완료: {cfg['published_bucket']}/{apath}")
        # 5-3) 원자료(최근 window_days 코일·휴지) 암호화 게시 — Claude 주간 분석용(분석 암호). 시험 위치면 test.mesdata.enc.json
        dpath = 'test.mesdata.enc.json' if apath.startswith('test') else 'mesdata.enc.json'
        nz = lambda v: None if isinstance(v, float) and v != v else v
        raw = {'app': 'cgl-mesdata', 'version': 1, 'savedAt': auto['runAt'], 'from': d_from, 'to': last,
               'coilCols': ST.COLS, 'coils': [[nz(c.get(k)) for k in ST.COLS] for c in win],
               'stopCols': ST.SCOLS, 'stops': [[x[k] for k in ST.SCOLS] for x in st.stops(mes.to_min(d_from))]}
        denc = json.dumps(PB.encrypt(raw, cfg['analysis_password'] or cfg['password'], f"MES 원자료 {d_from}~{last}"))
        if dry:
            open(os.path.join(cfg['out_dir'], dpath), 'w', encoding='utf-8').write(denc)
            log(f'[시험] 원자료 저장: {dpath} ({len(win)}코일)')
        else:
            sb.upload(cfg['published_bucket'], dpath, denc)
            log(f"원자료 게시: {cfg['published_bucket']}/{dpath} ({len(win)}코일, 휴지 {len(raw['stops'])}건)")
        # 5-4) 분석용 추가 자료(mes/extra/*.json: 컬러 생산·휴지, 출하, 재고) — 누적해 암호화 게시(Claude 분석용)
        try:
            xn = push_extra(cfg, sb, dry, auto['runAt'], 'test.' if apath.startswith('test') else '')
            if xn:
                log(f'분석용 추가 자료 게시: {xn}')
        except Exception as e:
            log(f'분석용 추가 자료 게시 실패(계획에는 영향 없음): {e}')
        # 6) 누적 실적 업로드(주간 분석용, 비공개 버킷)
        if cfg['push_data']:
            csv_text = st.to_csv()
            ana = json.dumps(dict(summ, daily=an['daily'], auto=auto), ensure_ascii=False, default=lambda x: None)
            if dry:
                open(os.path.join(cfg['out_dir'], 'coils.csv'), 'w', encoding='utf-8-sig').write(csv_text)
                open(os.path.join(cfg['out_dir'], 'analysis.json'), 'w', encoding='utf-8').write(ana)
                log('[시험] 누적 실적 저장: coils.csv, analysis.json')
            else:
                sb.upload(cfg['data_bucket'], 'coils.csv', csv_text, 'text/csv', cache='0')
                sb.upload(cfg['data_bucket'], 'analysis.json', ana, cache='0')
                log(f"누적 실적 업로드: {cfg['data_bucket']}/coils.csv ({csv_text.count(chr(10)) - 1}코일), analysis.json")
        st.log_run(now.isoformat(), True, '; '.join(auto['notes']))
        log('완료')
        return 0
    except Exception as e:
        log(f'실패: {e}')
        logf.write(traceback.format_exc() + '\n')
        st.log_run(now.isoformat(), False, str(e))
        return 1
    finally:
        logf.close()


def push_extra(cfg, sb, dry, run_at, prefix=''):
    """mes/extra/*.json(표: columns·rows)을 out_dir/extra_acc 에 누적(같은 행 중복 제외, snap_* 은 최신으로 교체)해
    published/{prefix}extradata.enc.json 으로 암호화 게시. 반환: 요약 문자열(없으면 '')"""
    dirs = {os.path.dirname(pat) or '.' for pat in cfg['mes_inputs']}
    files = sorted({f for d in dirs for f in glob.glob(os.path.join(d, 'extra', '*.json'))})
    if not files:
        return ''
    acc_dir = os.path.join(cfg['out_dir'], 'extra_acc')
    os.makedirs(acc_dir, exist_ok=True)
    tables = {}
    for f in files:
        name = os.path.splitext(os.path.basename(f))[0]
        new = json.load(open(f, encoding='utf-8'))
        ap = os.path.join(acc_dir, name + '.json')
        old = json.load(open(ap, encoding='utf-8')) if os.path.exists(ap) else None
        if old and not name.startswith('snap_') and old.get('columns') == new.get('columns'):
            seen, rows = set(), []
            for r in new['rows'] + old['rows']:                 # 새 자료 우선
                k = json.dumps(r, ensure_ascii=False)
                if k not in seen:
                    seen.add(k)
                    rows.append(r)
            new = {'columns': new['columns'], 'rows': rows}
        json.dump(new, open(ap, 'w', encoding='utf-8'), ensure_ascii=False)
        tables[name] = new
    body = {'app': 'cgl-extradata', 'version': 1, 'savedAt': run_at, 'tables': tables}
    enc = json.dumps(PB.encrypt(body, cfg['analysis_password'] or cfg['password'], '분석용 추가 자료'))
    path = prefix + 'extradata.enc.json'
    if dry:
        open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(enc)
    else:
        sb.upload(cfg['published_bucket'], path, enc)
    return f"{path} (" + ', '.join(f"{k} {len(v['rows'])}행" for k, v in tables.items()) + ')'


def supatest(cfg):
    """사내 PC에서 Supabase 연결·키·업로드 확인"""
    sbc = cfg.get('supabase') or {}
    sb = Supa(sbc['url'], sbc['key'], sbc.get('ssl_verify', True))
    names = sb.check()
    print('버킷:', names)
    for b in (cfg['published_bucket'], cfg['data_bucket']):
        if b not in names:
            print(f'  ⚠ 버킷 {b} 없음 — Supabase Storage에서 만드세요')
    msg = f'연결 시험 {_dt.datetime.now().isoformat()}'
    sb.upload(cfg['data_bucket'], 'connection_test.txt', msg, 'text/plain', cache='0')
    back = sb.download(cfg['data_bucket'], 'connection_test.txt')
    print('업로드·내려받기:', 'OK' if back and back.decode('utf-8') == msg else f'불일치 {back!r}')
    return 0
