"""게시 파일 암호화/복호화 — 웹 engine/crypto.js 와 같은 형식(gzip → AES-GCM 256, PBKDF2-SHA256 60만 회).
서버가 계산한 결과를 암호화해 대시보드 게시 위치(published/latest.plan.enc.json)에 두면 브라우저가 암호로 연다.
사내망 서버에서 로그인으로 보호할 때는 암호화 없이 평문 결과 JSON을 같은 위치로 제공해도 대시보드가 읽는다."""
import base64
import datetime as _dt
import gzip
import json
import os

ITER = 600000


def _aes():
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM   # 암호화할 때만 필요(plan·replan은 불필요)
    return AESGCM


def _key(pw, salt, it):
    import hashlib
    return hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), salt, it, dklen=32)


def pack(result, meta=None):
    """대시보드가 읽는 결과 JSON 봉투"""
    return {'app': 'cgl-plan', 'version': 1, 'savedAt': _dt.datetime.now(_dt.timezone.utc).isoformat(), 'result': result, 'meta': meta or {}}


def encrypt(obj, pw, label=''):
    data = gzip.compress(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
    salt, iv = os.urandom(16), os.urandom(12)
    ct = _aes()(_key(pw, salt, ITER)).encrypt(iv, data, None)
    b64 = lambda b: base64.b64encode(b).decode('ascii')
    return {'app': 'cgl-plan-enc', 'v': 1, 'label': label, 'created': _dt.datetime.now(_dt.timezone.utc).isoformat().replace('+00:00', 'Z'),
            'kdf': 'PBKDF2-SHA256', 'iter': ITER, 'gzip': True, 'salt': b64(salt), 'iv': b64(iv), 'ct': b64(ct)}


def decrypt(env, pw):
    if env.get('app') != 'cgl-plan-enc':
        raise ValueError('게시 파일 형식이 아닙니다')
    d = base64.b64decode
    try:
        data = _aes()(_key(pw, d(env['salt']), env['iter'])).decrypt(d(env['iv']), d(env['ct']), None)
    except Exception:
        raise ValueError('암호가 틀렸습니다')
    if env.get('gzip'):
        data = gzip.decompress(data)
    return json.loads(data.decode('utf-8'))
