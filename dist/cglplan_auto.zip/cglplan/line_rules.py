"""품목별 필수·우선 라인(사용자 제공 '세부판매계획(품목별적용라인)', 2026-10-13) — data/line_rules.json

규칙 행: 부서 · 용도 · 지역 · 소재 · 기타(고객) · 품목구분1(품명) · 필수라인 · 우선라인1~3
  · 필수라인이 있으면 그 라인만, 없으면 우선라인 순서
  · 같은 부서·품명에 행이 여럿이면(예: PCS5 삼성 3CCL / 엘지 2CCL) 지역·고객·MAC 여부가 맞는 행을 고름
도금: 품목구분1 = MAC·AZ·AL·AL-STS·신도금, 컬러: 품명(PGS, POR-STS, PDF-AL …)
실적 검증(2026-07-01~10-12 컬러 92,919t): 규칙이 있는 87,562t 중 95.6% 가 규칙 라인에서 생산. 나머지 3,874t 는 tools/line_rules_check.py
"""
import json
import os
import re

PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'line_rules.json')
DEPT_OF_GROUP = {'계획재': '컬러건재판매그룹', '주문재': '컬러건재판매그룹', '건재수출': '컬러수출그룹', '가전수출': '컬러수출그룹',
                 '가전내수': '컬러수출그룹', '수요개발': '수요개발그룹'}
_CACHE = {}


def load(path=PATH):
    if path not in _CACHE:
        if not os.path.exists(path):
            _CACHE[path] = []
        else:
            with open(path, encoding='utf-8') as f:
                _CACHE[path] = json.load(f)['rules']
    return _CACHE[path]


def product_key(r):
    """규칙 행 → 엔진 품명 키(color_full.base_name 과 같은 형태): AL 소재 'PGS'→'PGS-AL', STS 소재 'ETC'→'ETC-STS'"""
    p = r['item'].strip()
    if r['mat'] == 'Al' and not p.endswith('-AL'):
        p += '-AL'
    if r['mat'] == 'STS' and 'STS' not in p:
        p += '-STS'
    return p


def _norm(s):
    return re.sub(r'[\s()_.\-]', '', str(s or '')).upper()


def _score(r, mac, region, cust):
    s = 0
    if mac is not None:
        s += 1 if (r['mat'] == 'MAC' or '(MAC' in r['label'].upper()) == bool(mac) else -1
    for want in (region, cust):
        w = _norm(want)
        if not w:
            continue
        for have in (r['region'], r['etc'], r['label']):
            h = _norm(have)
            if h and h not in ('일반', '내수', '수출') and (h in w or w in h):
                s += 2
                break
    return s


def lookup(product, group=None, mac=None, region='', cust='', dept=None, rules=None):
    """→ {'must': 라인 또는 '', 'prefer': [라인…], 'rows': [규칙 행 번호…]} 또는 None(규칙 없음)"""
    rules = load() if rules is None else rules
    dept = dept or DEPT_OF_GROUP.get(group or '')
    cand = [r for r in rules if product_key(r) == product and (not dept or r['dept'] == dept)]
    if not cand:
        cand = [r for r in rules if product_key(r) == product]
    if not cand:
        return None
    best = max(_score(r, mac, region, cust) for r in cand)
    top = [r for r in cand if _score(r, mac, region, cust) == best]
    musts = sorted({r['must'] for r in top if r['must']})
    prefer = []
    for r in top:
        for l in ([r['must']] if r['must'] else []) + r['prefer']:
            if l and l not in prefer:
                prefer.append(l)
    return {'must': musts[0] if len(musts) == 1 and all(r['must'] for r in top) else '', 'prefer': prefer, 'rows': [r['row'] for r in top]}


def lines(product, group=None, mac=None, region='', cust='', dept=None, rules=None):
    """가능 라인(앞 순서 우선). 규칙 없으면 None → 호출 쪽 기존 규칙 사용"""
    x = lookup(product, group, mac, region, cust, dept, rules)
    if not x:
        return None
    return [x['must']] if x['must'] else x['prefer']
