"""컬러 계획재(건재 공통·개별) 일별 생산계획 — TF 산출기준서 + EOQ·추천반순 요약 기준.

입력
  · EOQ 요약(01_사양별_EOQ생산횟수_반순): 사양(품명·두께·폭·색상), 가능 라인(온도 칸 1·2·4), 단판TEST, 월 생산횟수,
    추천 생산반순(우선순위), 월평균 생산량, 목표재고(운영+안전)
  · 산출기준서: 라인스피드표(품명-소재·두께코드·폭코드 → 라인별 mpm), 품목별 휴지시간, 더미 기준
  · MES: 재고현황 월말 재고(snap_stock), 컬러 실적(color_prod: 실속도·계획재 비중), 판매생산속보 월차계획(라인별 월 톤)

계산
  ① 사양별 필요량 = 목표재고 + 월 수요(월평균 생산량) − 기초재고 (음수면 0, 3t 미만이면 생산 안 함)
  ② 생산 횟수 = 월평균 EOQ 생산횟수(반올림, 최소 1)만큼 추천 반순 앞에서부터, 1회 생산량 = 필요량 ÷ 횟수
  ③ 라인: 가능 라인 중 시간당 생산량(두께×폭×속도×7.87)이 큰 라인부터, 그 반순의 계획재 시간이 남는 곳
     넘치면 다른 가능 라인 → 앞 반순 → 뒤 반순 순으로 옮김(반순 몰림 완화)
  ④ 반순 안에서는 색상 > 폭(넓은 것 → 좁은 것) > 두께 순으로 묶어 연속 생산, 반순 첫날부터 채움
  ⑤ 휴지: 색상교체(라인별 시간 − 앞 로트 생산시간, 음수면 0), Roll교체(주문당 0.12회 + 소폭→대폭 1회),
     두께 편차 더미(1·2라인 150%, 4라인 130% 초과), 단판TEST(Y), print(PPG·PPK·PPH) Pattern·Off-set·Ink 교체
  계획재에 쓸 라인 시간 = 월차계획 톤 ÷ 라인 실적 t/hr(휴지 포함) × 7~9월 계획재 비중
"""
import calendar
import datetime as dt
import json
import os
import re
from collections import Counter, defaultdict

LINES = ['1CCL', '2CCL', '3CCL', '4CCL']
LN = {'1CCL': '1', '2CCL': '2', '3CCL': '3', '4CCL': '4'}
WINDOWS = [(1, 1, 5), (2, 6, 10), (3, 11, 15), (4, 16, 20), (5, 21, 25), (6, 26, 31)]   # 반순(5일 단위, 6반순은 말일까지)
PRINT = ('PPG', 'PPK', 'PPH')
DENS = 7.87
# 품목별 휴지시간(분) — 산출기준서 '품목별휴지시간'·'휴지_종합' 값
CC_MIN = {'1CCL': 49.59, '2CCL': 51.72, '3CCL': 48.04, '4CCL': 45.58}        # 하도·상도·이면 색상교체
ROLL_MIN = {'1CCL': 69.36, '2CCL': 69.36, '3CCL': 69.36, '4CCL': 44.67}      # Roll교체(1·2라인 평균, 4라인)
ROLL_RATE = 0.1177                                                          # 주문당 Roll교체 횟수
DUMMY_MIN = 37.68                                                           # 두께편차 Dummy
TEST_MIN = {'base': 42.10, 'print': 53.95}                                  # 생산검증 단판TEST / Print 단판 Test
PATTERN_MIN, OFFSET_MIN, OFFSET_RATE, INK_MIN = 32.97, 33.63, 0.0612, 36.09
DUMMY_RATIO = {'1CCL': 1.5, '2CCL': 1.5, '3CCL': 1.3, '4CCL': 1.3}


def _f(x, d=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


# ---------------------------------------------------------------- 입력 읽기
def load_specs(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = list(wb['01_사양별_EOQ생산횟수_반순'].iter_rows(values_only=True))
    hdr = [str(h).replace('\n', '') if h else f'c{i}' for i, h in enumerate(rows[1])]
    hdr[8:11] = ['온도1', '온도2', '온도4']
    out = []
    for r in rows[2:]:
        if not r[0]:
            continue
        s = dict(zip(hdr, r))
        p = str(s['사양(두께 폭 색상)']).split()
        lines = [l for l, k in (('1CCL', '온도1'), ('2CCL', '온도2'), ('4CCL', '온도4')) if s.get(k) not in (None, '')]
        out.append({
            'name': s['품명'], 'nameMat': s['품명(소재)'], 'kind': s['운영구분(공통/개별)'], 'use': s['용도'], 'owner': s['담당자'],
            'thk': float(p[0]), 'wdt': float(p[1]), 'color': p[2], 'lines': lines,
            'test': str(s['단판TEST 여부']).strip().upper() == 'Y', 'film': s['보호필름'], 'mat': s['적용소재'],
            'eoq': s['EOQ등급'], 'freq': _f(s['월평균 EOQ 생산횟수(회/월)']),
            'banks': [int(x) for x in re.findall(r'\d', str(s['추천 생산반순(우선순위 순)'] or ''))],
            'demand': _f(s['월 평균생산량']), 'target': _f(s['목표재고량(운영+안전_포아송,톤)']),
            'matPri': [(s.get(f'소재우선순위{i}_품종'), s.get(f'소재우선순위{i}_도금량')) for i in (1, 2, 3)
                       if s.get(f'소재우선순위{i}_품종') not in (None, 0, '0')],
        })
    for i, s in enumerate(out):
        s['id'] = i
        s['spec'] = f"{s['thk']:g}×{s['wdt']:g} {s['color']}"
    return out


def load_speed_table(path):
    """산출기준서 '라인스피드': (품명, 소재구분, 두께코드, 폭코드) → {라인: mpm}"""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = list(wb['라인스피드'].iter_rows(values_only=True))
    tb = {}
    for r in rows[1:]:
        if not r[0] or not r[1]:
            continue
        code = str(r[1]).split('_')[-1].strip()
        if len(code) != 2:
            continue
        sp = {l: _f(r[8 + i], None) for i, l in enumerate(LINES)}
        sp = {l: v for l, v in sp.items() if v}
        if sp:
            tb[(r[2], r[3], code[0], code[1])] = sp
    return tb


THK_EDGES = [(0.3, 'A'), (0.4, 'B'), (0.5, 'C'), (0.6, 'D'), (0.7, 'E'), (0.8, 'F'), (0.9, 'G'), (1.0, 'H'), (1.1, 'I'),
             (1.2, 'J'), (1.3, 'K'), (1.4, 'L'), (1.5, 'M'), (1.6, 'N'), (1.7, 'O'), (1.9, 'Q'), (2.0, 'R')]
WDT_EDGES = [(100, 'A'), (200, 'B'), (300, 'C'), (400, 'D'), (500, 'E'), (600, 'F'), (700, 'G'), (800, 'H'), (900, 'I'),
             (1000, 'J'), (1100, 'K'), (1200, 'L'), (1300, 'M'), (1400, 'N'), (1500, 'O')]


def _code(v, edges, last):
    for e, c in edges:
        if v < e - 1e-9:
            return c
    return last


def _mat_cls(s):
    m = str(s['mat'] or '')
    return 'AL' if m.startswith('AL') else ('STS' if 'STS' in m else '일반')


# ---------------------------------------------------------------- MES 자료와 사양 연결
def _codes():
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'color_product_codes.json')
    return json.load(open(p, encoding='utf-8'))['codes']


class Matcher:
    def __init__(self, specs):
        self.idx = defaultdict(list)
        for s in specs:
            self.idx[(s['name'], s['color'])].append(s)
        cd = _codes()
        self.nm = lambda c: (cd.get(c) or {}).get('name', c)

    def __call__(self, code, thk, wdt, color, tolw=15, tolt=0.07):
        best = None
        for s in self.idx.get((self.nm(code), color), []):
            if abs(s['wdt'] - wdt) <= tolw and abs(s['thk'] - thk) <= tolt:
                d = abs(s['thk'] - thk)
                if best is None or d < best[0]:
                    best = (d, s)
        return best[1] if best else None


def stock_by_spec(specs, snap_stock, month=None):
    """재고현황 월말 재고(컬러 제품) → 사양별 톤. month 없으면 가장 최근 달"""
    T = [dict(zip(snap_stock['columns'], r)) for r in snap_stock['rows']]
    month = month or max(r['_기준월'] for r in T)
    m = Matcher(specs)
    st = Counter()
    for r in T:
        if r['_기준월'] != month or r['공장구분'] != 'C' or r['구분명'] != 'P':
            continue
        s = m(r['품명코드'], _f(r['제품두께']), _f(r['제품폭']), r['표면상도코드'], tolt=0.02)
        if s:
            st[s['id']] += _f(r['중량']) / 1000
    return st, month


def actual_stats(specs, color_prod, d0, d1):
    """컬러 실적: 사양별 생산량·라인, 라인별 총생산·계획재 비중·휴지 포함 t/hr, (품명, 라인)별 실속도"""
    T = [dict(zip(color_prod['columns'], r)) for r in color_prod['rows']]
    m = Matcher(specs)
    prod, lt, lh, lplan = Counter(), Counter(), Counter(), Counter()
    sp = defaultdict(list)
    for r in T:
        if not (d0 <= r['PRD_DT'] <= d1):
            continue
        t = _f(r['PDT_WGT']) / 1000
        ln = r['LINE']
        lt[ln] += t
        lh[ln] += (_f(r['WRK_TIME']) + _f(r['PAU_TIME'])) / 60
        s = m(r['PDT_NM'], _f(r['REAL_MSR_THK']), _f(r['PDT_WDT']), r['SUR_FINISH_CD'])
        if s:
            prod[(s['id'], ln)] += t
            lplan[ln] += t
        if _f(r['LINE_SPEED']) > 0:
            sp[(m.nm(r['PDT_NM']), ln)].append((_f(r['REAL_MSR_THK']), _f(r['LINE_SPEED'])))
    share = {l: (lplan[l] / lt[l] if lt[l] else 0) for l in LINES}
    tph = {l: (lt[l] / lh[l] if lh[l] else None) for l in LINES}
    return {'prod': prod, 'lineT': lt, 'share': share, 'tphIncl': tph, 'speed': sp, 'days': (d0, d1)}


# ---------------------------------------------------------------- 속도·휴지
def speed_mpm(s, line, table, act):
    k = (s['name'], _mat_cls(s), _code(s['thk'], THK_EDGES, 'R'), _code(s['wdt'], WDT_EDGES, 'Q'))
    v = (table.get(k) or {}).get(line)
    if v:
        return v, '기준표'
    xs = sorted(v for t, v in act.get((s['name'], line), []) if abs(t - s['thk']) <= 0.12)
    if len(xs) >= 3:
        return xs[len(xs) // 2], '실적'
    xs = sorted(v for _, v in act.get((s['name'], line), []))
    if xs:
        return xs[len(xs) // 2], '실적(품명)'
    xs = sorted(v for (n, l), arr in act.items() if l == line for t, v in arr if abs(t - s['thk']) <= 0.12)
    return (xs[len(xs) // 2], '실적(라인)') if xs else (60.0, '가정')


def tph(s, mpm):
    return s['thk'] / 1000 * s['wdt'] / 1000 * mpm * DENS * 60


def changeover(prev, cur, line, run_min):
    """prev → cur 전환 휴지(분)와 내역. prev None = 반순 첫 로트"""
    d = {}
    isp = cur['name'] in PRINT
    if prev is None or prev['color'] != cur['color']:
        d['색상교체'] = max(0.0, CC_MIN[line] - (run_min if prev is not None else 0)) if prev is not None else CC_MIN[line]
    d['Roll교체'] = ROLL_RATE * ROLL_MIN[line] + (ROLL_MIN[line] if prev is not None and cur['wdt'] > prev['wdt'] + 1 else 0)
    if prev is not None:
        a, b = sorted([prev['thk'], cur['thk']])
        if b / a > DUMMY_RATIO[line] or (_mat_cls(prev) == 'AL') != (_mat_cls(cur) == 'AL'):
            d['두께 더미'] = DUMMY_MIN
    if cur['test']:
        d['단판TEST'] = TEST_MIN['print' if isp else 'base']
    if isp:
        if prev is None or prev['name'] not in PRINT or str(prev['color'])[3:4] != str(cur['color'])[3:4]:
            d['Pattern Roll'] = PATTERN_MIN
        d['Off-set Roll'] = OFFSET_RATE * OFFSET_MIN
        d['Ink 교체'] = INK_MIN
    return sum(d.values()), d


# ---------------------------------------------------------------- 계획
def plan(specs, stock, month_plan, actual, speed_table, year=2026, month=10, min_lot=3.0, start_day=1, made_before=None):
    """month_plan: {라인: 월차계획 톤}. start_day: 이 날부터 계획(그 전은 실적), made_before: 이번 달 이미 생산한 사양별 톤.
    반환: 로트 목록·일별 표·사양별 일정·라인 부하·경고"""
    made_before = made_before or {}
    ndays = calendar.monthrange(year, month)[1]
    wins = [(b, d0, min(d1, ndays)) for b, d0, d1 in WINDOWS]
    # 라인별 계획재 시간(반순별) = 월차 톤 ÷ 휴지 포함 t/hr × 계획재 비중 × (반순 일수/월 일수)
    hours = {}
    for l in LINES:
        t, r, sh = month_plan.get(l) or 0, actual['tphIncl'].get(l), actual['share'].get(l) or 0
        hours[l] = (t / r * sh) if (t and r) else 0.0
    budget = {(l, b): hours[l] * max(0, d1 - max(d0, start_day) + 1) / ndays for l in LINES for b, d0, d1 in wins}
    first_bank = next(b for b, d0, d1 in wins if d1 >= start_day)
    used = Counter()
    lots, warns = [], []
    # 가능 라인 = EOQ 파일(온도 칸) ∪ 최근 실적에서 5t 이상 만든 라인 — 파일의 라인 구분은 과거 생산 이력이라 실적이 있으면 추가
    for s in specs:
        s['linesFile'] = list(s['lines'])
        extra = [l for l in LINES if l != '3CCL' and l not in s['lines'] and actual['prod'].get((s['id'], l), 0) >= 5]
        s['lines'] = s['lines'] + extra
        s['linesAdded'] = extra
    for s in specs:
        s0 = stock.get(s['id'], 0.0)
        s['madeBefore'] = made_before.get(s['id'], 0.0)
        need = s['target'] + s['demand'] - s0 - s['madeBefore']
        s['stock0'], s['need'], s['deferred'] = s0, max(0.0, need), False
        if need < min_lot:
            continue
        if not any(budget[(l, b)] for l in s['lines'] for b in range(1, 7)) and not s['lines']:
            continue
        if s['eoq'] == '집약' and s0 >= s['demand']:          # 집약 사양: 이번 달 결품 위험이 없으면 다음 달로 미룸(소량 잦은 교체 방지)
            s['deferred'] = True
            continue
        n = max(1, round(s['freq']))
        banks = sorted({max(b, first_bank) for b in (s['banks'] or [5])[:n]})   # 지난 반순은 다음 가능한 반순으로
        n = len(banks)
        for b in banks:
            lots.append({'spec': s, 'bank': b, 't': need / n})
    # 큰 로트·적은 가능 라인부터 배정
    lots.sort(key=lambda x: (len(x['spec']['lines']), -x['t']))
    for x in lots:
        s = x['spec']
        cands = []
        for l in s['lines']:
            mpm, src = speed_mpm(s, l, speed_table, actual['speed'])
            cands.append((tph(s, mpm), l, mpm, src))
        cands.sort(reverse=True)
        order = [x['bank']] + [b for b in (x['bank'] - 1, x['bank'] - 2, x['bank'] + 1, x['bank'] - 3, x['bank'] + 2, x['bank'] - 4) if 1 <= b <= 6]
        placed = None
        for b in order:
            for r_, l, mpm, src in cands:
                h = x['t'] / r_ + 1.0                          # 전환 여유 1시간 포함해 자리 확인
                if used[(l, b)] + h <= budget[(l, b)] + 1e-9:
                    placed = (b, l, r_, mpm, src)
                    break
            if placed:
                break
        if not placed:                                         # 어디에도 안 들어가면 초과가 가장 작은 곳(시간 비율)에
            best = None
            for k, b in enumerate(order):
                for r_, l, mpm, src in cands:
                    h = x['t'] / r_ + 1.0
                    over = (used[(l, b)] + h) / max(budget[(l, b)], 1e-6)
                    if best is None or over < best[0] - 1e-9:
                        best = (over, (b, l, r_, mpm, src))
            placed = best[1]
            x['over'] = True
        b, l, r_, mpm, src = placed
        x.update({'bankPlan': b, 'line': l, 'tph': r_, 'mpm': mpm, 'speedSrc': src, 'runH': x['t'] / r_})
        used[(l, b)] += x['runH'] + 1.0
    # 반순·라인별 순서(색상 > 폭 > 두께)와 휴지, 일자 배치
    by = defaultdict(list)
    for x in lots:
        by[(x['line'], x['bankPlan'])].append(x)
    day = defaultdict(lambda: defaultdict(float))            # (일, 라인) → 사양 → 톤
    dayH = Counter()
    for (l, b), xs in by.items():
        maxw = defaultdict(float)
        for x in xs:
            maxw[x['spec']['color']] = max(maxw[x['spec']['color']], x['spec']['wdt'])
        xs.sort(key=lambda x: (-maxw[x['spec']['color']], x['spec']['color'], -x['spec']['wdt'], x['spec']['thk']))
        d0, d1 = next((a, c) for bb, a, c in wins if bb == b)
        d0 = max(d0, start_day)
        clock = (d0 - 1) * 24.0                                # 반순 첫날 0시부터 연속 생산
        prev, prev_run = None, 0.0
        for x in xs:
            co, det = changeover(prev, x['spec'], l, prev_run * 60)
            x['coMin'], x['coDet'] = co, det
            clock += co / 60
            x['startH'] = clock
            # 날짜별로 톤 나누기
            left, rate = x['t'], x['tph']
            while left > 1e-6:
                dd = int(clock // 24) + 1
                room = (dd * 24 - clock) * rate
                put = min(left, room)
                day[(min(dd, ndays), l)][x['spec']['id']] += put
                dayH[(min(dd, ndays), l)] += put / rate
                left -= put
                clock += put / rate
            x['endH'] = clock
            x['day0'], x['day1'] = int(x['startH'] // 24) + 1, min(ndays, int((clock - 1e-9) // 24) + 1)
            if clock > d1 * 24 + 1e-6:
                warns.append(f"{l} {b}반순: 계획재가 반순을 넘김({x['spec']['name']} {x['spec']['spec']} → {x['day1']}일)")
            prev, prev_run = x['spec'], x['runH']
    # 사양별 일정·재고
    spec_rows = []
    for s in specs:
        ls = sorted([x for x in lots if x['spec'] is s], key=lambda x: x['startH'])
        made = sum(x['t'] for x in ls)
        spec_rows.append({'spec': s, 'lots': ls, 'made': made, 'end': s['stock0'] + s['madeBefore'] + made - s['demand']})
    over = [x for x in lots if x.get('over')]
    if over:
        warns.insert(0, f"계획재 시간 부족: {len(over)}개 로트 {sum(x['t'] for x in over):,.0f}t 를 계획재 시간 초과로 배정(라인 부하 시트 참고)")
    load = []
    for l in LINES:
        for b, d0, d1 in wins:
            xs = by.get((l, b), [])
            if not budget[(l, b)] and not xs:
                continue
            run = sum(x['runH'] for x in xs)
            co = sum(x['coMin'] for x in xs) / 60
            load.append({'line': l, 'bank': b, 'days': f'{d0}~{d1}일', 'budgetH': budget[(l, b)], 'runH': run, 'coH': co,
                         't': sum(x['t'] for x in xs), 'lots': len(xs), 'colorChanges': sum(1 for x in xs if '색상교체' in x['coDet'])})
    cap_t = {l: (month_plan.get(l) or 0) * (actual['share'].get(l) or 0) for l in LINES}
    return {'year': year, 'month': month, 'ndays': ndays, 'lots': lots, 'day': day, 'specRows': spec_rows, 'load': load,
            'hours': hours, 'capT': cap_t, 'monthPlan': month_plan, 'share': actual['share'], 'tphIncl': actual['tphIncl'],
            'warns': warns, 'deferred': [s for s in specs if s.get('deferred')], 'startDay': start_day}


def actual_days(specs, color_prod, year, month, before_day):
    """이번 달 before_day 전까지 실적: (일, 라인) → 사양 → 톤, 사양별 합계"""
    m = Matcher(specs)
    day, tot = defaultdict(lambda: defaultdict(float)), Counter()
    pre = f'{year}-{month:02d}-'
    for r in color_prod['rows']:
        x = dict(zip(color_prod['columns'], r))
        if not x['PRD_DT'].startswith(pre) or int(x['PRD_DT'][8:]) >= before_day:
            continue
        s = m(x['PDT_NM'], _f(x['REAL_MSR_THK']), _f(x['PDT_WDT']), x['SUR_FINISH_CD'])
        if s:
            t = _f(x['PDT_WGT']) / 1000
            day[(int(x['PRD_DT'][8:]), x['LINE'])][s['id']] += t
            tot[s['id']] += t
    return day, tot


def month_plan_from_salesrpt(summary):
    """판매생산속보 요약(tools/salesrpt.summary) → {라인: 월차계획 톤}"""
    return {p['line']: p['month'] for p in summary.get('prod', []) if p['line'] in LINES}
