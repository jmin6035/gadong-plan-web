"""MES 실적 쿼리 해석·분석 — 웹 engine/mes.js 와 같은 규칙(결과 일치 검증: tests/test_engine.py).
코일 단위 생산실적으로 속도·손실·M/C를 재산출해 현재 파라미터와 비교하고, 재계획 입력(일별 라인×강종×부서 톤)을 만든다.
시간 정의: 작업시간 = 가동시간 + 휴지시간. 라인 시간 = 제품코일 가동 + M/C(전환) + 배경손실(더미코일·기타 휴지·빈 시간), 겹침 없음."""
import datetime as _dt
import re

import openpyxl

from . import util as U

RULES = {
    'family': [('^GGL', 'AZ'), ('^GA[LTS]', 'AL'), ('^GGM|MAC', 'MAC')],     # 제품명 → 강종군(도금종류 COT_CLS 가 없을 때)
    'cot': {'A': 'AL', 'L': 'AZ', 'M': 'MAC'},                             # 도금종류(COT_CLS) → 강종군. 2026.7~9 13주로 확인(GGM=M, GAS·GAL·GAT=A, GGL=L)
    'alloyName': [('^GAS', 'AL-STS')],                                      # 세부강종(속도 키): GAS = AL-STS(2CGL 자동차, 속도 일치 확인)
    'lineCode': {'A': '1CGL', 'B': '2CGL'},                                 # LINE_CLS
    'dept': {'도금수출그룹': '도금수출', '도금판매그룹': '도금국내', '컬러수출그룹': '자가재', '컬러건재판매그룹': '자가재', '컬러판매그룹': '자가재'},
    'autoDept': '자동차강판판매그룹',
    'dummyDept': '공정출하그룹',
    # 라인번호가 없을 때(생산실적 조회 화면 엑셀) 제품번호 앞 2자리로 라인 추정. AA=1CGL·BA=2CGL (LINE_CLS 와 13주 전부 일치)
    'linePrefix': {'AA': '1CGL', 'BA': '2CGL'},
    'mcRx': 'mode\\s*change',                                               # 휴지 사유명 중 강종전환(M/C)
    'mcGap': 180,                                                           # 이 간격(분) 안의 전환 휴지는 한 번의 M/C 로 묶음
    'speedRunMax': 300, 'longStop': 1440, 'minDays': 28, 'minCoils': 30, 'minTons': 300, 'minEvents': 3, 'tol': 0.05,
}
# MES 쿼리 영문 열 → 화면 엑셀 한글 열(같은 이름으로 다룸)
ALIAS = {'PDT_NO': '제품번호', 'PRD_NO': '생산번호', 'PRD_DT': '생산계상일자', 'LINE_CLS': '라인번호', 'WRK_STA_TM': '작업시작시각', 'WRK_END_TM': '작업종료시각',
         'TOT_WRK_TIME': '작업시간', 'TOT_PAU_TIME': '휴지시간', 'TOT_OPR_TIME': '가동시간', 'COT_CLS': '도금종류', 'PDT_NET_WGT': '제품중량', 'VIW_GRD': '제품등급',
         'CON_NO': '계약번호', 'CON_SEQ': '행번'}
REQ = ['제품번호', '작업시작시각', '작업종료시각', '가동시간', '제품중량']      # 코일 실적 최소 열(부서·계약·제품명은 화면 엑셀과 제품번호로 병합)
_EPOCH = _dt.datetime(1970, 1, 1)


def _str(v):
    if v is None:
        return ''
    if isinstance(v, _dt.datetime):
        return v.strftime('%Y-%m-%d %H:%M')
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _num(v):
    s = _str(v).replace(',', '')
    try:
        return float(s) if s != '' else float('nan')
    except ValueError:
        return float('nan')


def _nz(x):
    return 0 if x != x else x


def to_min(v):
    if isinstance(v, _dt.datetime):
        return round((v - _EPOCH).total_seconds() / 60)
    if isinstance(v, _dt.date):
        return round((_dt.datetime(v.year, v.month, v.day) - _EPOCH).total_seconds() / 60)
    if isinstance(v, (int, float)):
        return round((v - 25569) * 1440)
    m = re.match(r'^(\d{4})[-./](\d{1,2})[-./](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?', _str(v))
    if not m:
        return float('nan')
    d = _dt.datetime(int(m[1]), int(m[2]), int(m[3]), int(m[4] or 0), int(m[5] or 0), int(m[6] or 0))
    return round((d - _EPOCH).total_seconds() / 60)


def min_to_str(t):
    return (_EPOCH + _dt.timedelta(minutes=t)).strftime('%Y-%m-%d %H:%M')


def _day_of(v):
    t = to_min(v)
    return '' if t != t else min_to_str(t)[:10]


def median(a):
    if not a:
        return float('nan')
    s, h = sorted(a), len(a) >> 1
    return s[h] if len(s) % 2 else (s[h - 1] + s[h]) / 2


def _norm_line(s, R=RULES):
    s = (s or '').strip()
    if s.upper() in R['lineCode']:
        return R['lineCode'][s.upper()]
    m = re.search(r'([12])\s*CGL', s, re.I)
    return f'{m[1]}CGL' if m else ''


def tables(sheets):
    out = []
    for rows in sheets:
        hi, best = -1, 0
        for i in range(min(5, len(rows))):
            n = sum(1 for x in rows[i] if _str(x) != '')
            if n > best:
                best, hi = n, i
        if hi < 0 or best < 3:
            continue
        H = [re.sub(r'\s', '', _str(x)) for x in rows[hi]]
        H = [ALIAS.get(h.upper(), h) for h in H]
        recs = []
        for r in rows[hi + 1:]:
            o = {h: (r[j] if j < len(r) else None) for j, h in enumerate(H) if h}
            if any(_str(v) != '' for v in o.values()):
                recs.append(o)
        out.append({'header': H, 'rows': recs})
    return out


def sheets_from_workbooks(paths_or_wbs):
    """엑셀(.xlsx) · MES 화면 표 직접 읽기 결과(.json: {"columns": [...], "rows": [[...]]}) · .csv"""
    import csv as _csv
    import json as _json
    sheets = []
    for x in paths_or_wbs:
        if isinstance(x, str) and x.lower().endswith('.json'):
            o = _json.load(open(x, encoding='utf-8'))
            sheets.append([list(o['columns'])] + [list(r) for r in o['rows']])
            continue
        if isinstance(x, str) and x.lower().endswith('.csv'):
            sheets.append([r for r in _csv.reader(open(x, encoding='utf-8-sig'))])
            continue
        wb = openpyxl.load_workbook(x, read_only=True, data_only=True) if isinstance(x, str) else x
        for ws in wb.worksheets:
            sheets.append([list(r) for r in ws.iter_rows(values_only=True)])
    return sheets


def _is_coil(t):
    return '제품번호' in t['header'] and '작업시작시각' in t['header']


def _is_stop(t):
    return '생산번호' in t['header'] and 'PAU_STA_TM_1' in t['header']


def is_mes_query(tbls):
    return any(_is_coil(t) for t in tbls)


def clean(tbls, R=RULES):
    """정제: 반환 {coils, stops, checks}. 코일 표(생산 쿼리·생산실적 화면)는 제품번호로 병합, 휴지 쿼리는 휴지 건으로"""
    checks = []
    coil_t = [t for t in tbls if _is_coil(t)]
    if not coil_t:
        return {'coils': [], 'stops': [], 'checks': [{'level': 'error', 'msg': '코일 생산실적 표가 없음(제품번호·작업시작시각 열 필요)'}]}
    line_by, grade_by = {}, {}
    for t in tbls:
        if '라인번호' in t['header'] and '생산번호' in t['header']:
            for r in t['rows']:
                l = _norm_line(_str(r.get('라인번호')), R)
                if l:
                    line_by[_str(r.get('생산번호'))] = l
        if '제품등급' in t['header'] and '제품번호' in t['header'] and not _is_coil(t):
            for r in t['rows']:
                g = _str(r.get('제품등급'))
                if g:
                    grade_by[_str(r.get('제품번호'))] = g
    # 제품번호로 병합(먼저 나온 표의 값 우선, 빈 칸만 채움)
    recs, order, dup = {}, [], 0
    for t in coil_t:
        seen = set()
        for r in t['rows']:
            cid = _str(r.get('제품번호'))
            if not cid or re.search(r'합계|소계|total', cid, re.I):
                continue
            if cid in seen:
                dup += 1
                continue
            seen.add(cid)
            if cid not in recs:
                recs[cid] = {}
                order.append(cid)
            m = recs[cid]
            for k, v in r.items():
                if _str(v) != '' and _str(m.get(k)) == '':
                    m[k] = v
    hdr = set(h for t in coil_t for h in t['header'])
    miss = [h for h in REQ if h not in hdr]
    if miss:
        return {'coils': [], 'stops': [], 'checks': [{'level': 'error', 'msg': f"생산실적 열이 없음: {', '.join(miss)}"}]}
    if '계약번호' not in hdr and '부서명' not in hdr:
        checks.append({'level': 'warn', 'msg': '계약번호·부서명이 없어 더미·부서 구분 불가 — 생산실적 화면 엑셀을 같이 넣으세요'})

    def fam_of(cot, p):
        if R['cot'].get(cot):
            return R['cot'][cot]
        for rx, f in R['family']:
            if re.search(rx, p):
                return f
        return ''

    def alloy_of(fam, p):
        for rx, a_ in R['alloyName']:
            if re.search(rx, p):
                return a_
        return fam
    coils = []
    bad = {'noLine': 0, 'time': 0, 'sum': 0, 'dur': 0, 'byPrefix': 0, 'unkCot': {}}
    unk_name, unk_dept, d_con, d_dept = {}, {}, 0, 0
    for cid in order:
        r = recs[cid]
        line = _norm_line(_str(r.get('라인번호')), R) or line_by.get(_str(r.get('생산번호')), '')
        if not line and R['linePrefix'].get(cid[:2]):
            line = R['linePrefix'][cid[:2]]
            bad['byPrefix'] += 1
        if not line:
            bad['noLine'] += 1
            continue
        s, e = to_min(r.get('작업시작시각')), to_min(r.get('작업종료시각'))
        run, stop = _nz(_num(r.get('가동시간'))), _nz(_num(r.get('휴지시간')))
        if s != s or e != e or e < s:
            bad['time'] += 1
            continue
        w = _num(r.get('작업시간'))
        work = run + stop if w != w else w
        if abs(work - run - stop) > 1:
            bad['sum'] += 1
        if abs(e - s - work) > 2:
            bad['dur'] += 1
        pname, dept, con, cot = _str(r.get('제품명')), _str(r.get('부서명')), _str(r.get('계약번호')).upper(), _str(r.get('도금종류')).upper()
        by_con, by_dept = 'D' in con, dept == R['dummyDept']
        if by_con != by_dept and con and dept:
            if by_con:
                d_con += 1
            else:
                d_dept += 1
        dummy = by_con or by_dept
        fam = fam_of(cot, pname)
        if cot and not R['cot'].get(cot):
            bad['unkCot'][cot] = bad['unkCot'].get(cot, 0) + 1
        cls = R['dept'].get(dept, '')
        if dept == R['autoDept']:
            cls = '자동차내수' if re.search('[가-힣]', _str(r.get('최종고객사명'))) else '자동차수출'
        wt = _nz(_num(r.get('제품중량'))) / 1000
        if not dummy and not fam:
            unk_name[pname or cot] = unk_name.get(pname or cot, 0) + wt
        if not dummy and not cls and dept:
            unk_dept[dept] = unk_dept.get(dept, 0) + wt
        day = _day_of(r.get('생산계상일자')) or min_to_str(e - 420)[:10]
        coils.append({'id': cid, 'prd': _str(r.get('생산번호')), 'line': line, 'day': day, 's': s, 'e': e, 'work': work, 'stop': stop, 'run': run, 't': wt,
                      'thick': _num(r.get('제품두께')), 'width': _num(r.get('제품폭')), 'pname': pname, 'dept': dept, 'fam': fam, 'alloy': alloy_of(fam, pname) if fam else '',
                      'cls': cls, 'dummy': dummy, 'grade': grade_by.get(cid) or _str(r.get('제품등급')) or ''})
    coils.sort(key=lambda c: (c['line'], c['s'], c['e']))
    # 휴지 쿼리(생산번호별 휴지 1~3건: 시작·종료·사유)
    prd_line = {c['prd']: c['line'] for c in coils if c['prd']}
    stops, nstop_t = [], 0
    for t in tbls:
        if not _is_stop(t):
            continue
        nstop_t += 1
        for r in t['rows']:
            prd = _str(r.get('생산번호'))
            line = _norm_line(_str(r.get('라인번호')), R) or prd_line.get(prd, '')
            for i in (1, 2, 3):
                a_, b_ = to_min(r.get(f'PAU_STA_TM_{i}')), to_min(r.get(f'PAU_END_TM_{i}'))
                if a_ != a_ or b_ != b_ or b_ <= a_ or not line:
                    continue
                stops.append({'line': line, 'prd': prd, 's': a_, 'e': b_, 't': b_ - a_, 'cls': _str(r.get('PAU_CLS')),
                              'cd': _str(r.get(f'PAU_RSN_CD_{i}')), 'nm': _str(r.get(f'PAU_RSN_CD_{i}_NM')), 'dtl': _str(r.get('PAU_DTL_CLS_NM'))})
    stops.sort(key=lambda x: (x['line'], x['s']))
    if not coils:
        checks.append({'level': 'error', 'msg': '해석된 코일이 없음(라인번호·시각 확인)'})
    if dup:
        checks.append({'level': 'info', 'msg': f'같은 표 안의 중복 제품번호 {dup}건 제외'})
    if len(coil_t) > 1:
        checks.append({'level': 'info', 'msg': f'코일 실적 표 {len(coil_t)}개를 제품번호로 병합'})
    if bad['noLine']:
        checks.append({'level': 'warn', 'msg': f"라인을 못 찾은 코일 {bad['noLine']}건 제외 — 쿼리에 LINE_CLS 열을 넣으세요"})
    if bad['byPrefix']:
        checks.append({'level': 'info', 'msg': f"라인번호 없는 코일 {bad['byPrefix']}건은 제품번호 앞글자로 라인 추정(" + ', '.join(f'{k}={v}' for k, v in R['linePrefix'].items()) + ")"})
    if bad['unkCot']:
        checks.append({'level': 'warn', 'msg': '모르는 도금종류(COT_CLS): ' + ', '.join(f'{k} {v}코일' for k, v in bad['unkCot'].items()) + ' — 규칙 추가 필요'})
    if bad['time']:
        checks.append({'level': 'warn', 'msg': f"작업 시작·종료시각 오류 {bad['time']}건 제외"})
    if bad['sum']:
        checks.append({'level': 'warn', 'msg': f"작업시간 ≠ 가동시간+휴지시간 {bad['sum']}건 — 시간 정의가 바뀌었는지 확인"})
    if bad['dur']:
        checks.append({'level': 'warn', 'msg': f"종료−시작 ≠ 작업시간 {bad['dur']}건"})
    if d_con or d_dept:
        checks.append({'level': 'warn', 'msg': f'더미 판정 불일치: 계약번호 D인데 공정출하그룹 아님 {d_con}건, 공정출하그룹인데 계약번호 D 없음 {d_dept}건 — 둘 다 더미로 봄'})

    def top(o):
        return ', '.join(f"{k or '(빈칸)'} {U.fmt(v)}t" for k, v in sorted(o.items(), key=lambda kv: -kv[1]))
    if unk_name:
        checks.append({'level': 'warn', 'msg': f'강종을 모르는 코일(속도·M/C 분석 제외): {top(unk_name)} — 규칙 추가 필요'})
    if unk_dept:
        checks.append({'level': 'warn', 'msg': f'부서 매핑 없음(속도 분석 제외): {top(unk_dept)}'})
    for l in dict.fromkeys(c['line'] for c in coils):
        cs = [c for c in coils if c['line'] == l]
        ov = sum(1 for i in range(1, len(cs)) if cs[i]['s'] < cs[i - 1]['e'] - 1)
        if ov:
            checks.append({'level': 'warn', 'msg': f'{l}: 작업구간이 겹치는 코일 {ov}건(시간 합계가 과대될 수 있음)'})
        if nstop_t:
            cst = sum(c['stop'] for c in cs)
            sst = sum(x['t'] for x in stops if x['line'] == l and cs[0]['s'] - 60 <= x['s'] <= cs[-1]['e'])
            lv = 'info' if abs(cst - sst) <= max(60, 0.02 * cst) else 'warn'
            checks.append({'level': lv, 'msg': f'{l}: 휴지 대사 — 코일 휴지 합 {U.fmt(cst)}분 vs 휴지 쿼리 합 {U.fmt(sst)}분' + ('' if lv == 'info' else ' (차이 큼 — 휴지 쿼리 기간·누락 확인)')})
    if not nstop_t:
        checks.append({'level': 'info', 'msg': '휴지 쿼리 없음 — M/C·설비정지를 코일 순서로 추정(사유 기반보다 부정확)'})
    graded = [c for c in coils if c['grade']]
    if graded:
        def g(arr):
            o = {}
            for c in arr:
                o[c['grade']] = o.get(c['grade'], 0) + 1
            return ' '.join(f'{k}:{v}' for k, v in sorted(o.items()))
        checks.append({'level': 'info', 'msg': f"제품등급 대조 — 더미 [{g([c for c in graded if c['dummy']])}] / 제품 [{g([c for c in graded if not c['dummy']])}]"})
    return {'coils': coils, 'stops': stops, 'checks': checks}


def _speed_key(c):
    return f"{c['line']}|{c['alloy'] or c['fam']}|{c['cls']}"


def analyze(coils, P, R=RULES, stops=None):
    """라인 시간 = 제품코일 가동 + M/C + 장기정지 + 설비정지(그 외 휴지) + 더미코일 가동(전환 밖) + 기타.
    휴지 쿼리가 있으면 사유로 M/C(Mode change)·설비정지를 나누고, 없으면 코일 강종 순서로 추정"""
    lines, events, speed, cands, reasons = {}, [], [], [], []
    stops = stops or []
    rx = re.compile(R['mcRx'], re.I)
    for l in P['lines']:
        cs = [c for c in coils if c['line'] == l]
        if not cs:
            continue
        W0, W1 = cs[0]['s'], max(c['e'] for c in cs)
        W = W1 - W0
        prod = [c for c in cs if not c['dummy']]
        seq = [c for c in prod if c['fam']]
        ev = [x for x in stops if x['line'] == l and W0 - 60 <= x['s'] <= W1]
        wins, sw, rs, long_min, longs, equip = [], 0, 0, 0, [], 0
        if ev:
            basis = '휴지 사유'
            mcs = [x for x in ev if rx.search(x['nm'])]
            groups = []
            for x in mcs:
                if groups and x['s'] - groups[-1][-1]['e'] <= R['mcGap']:
                    groups[-1].append(x)
                else:
                    groups.append([x])
            in_g = set(id(x) for g in groups for x in g)
            for g in groups:
                s0, e0 = g[0]['s'], max(x['e'] for x in g)
                prev = [c for c in seq if c['e'] <= s0 + 1]
                nxt = next((c for c in seq if c['e'] > e0), None)
                end = (nxt['e'] - nxt['run']) if nxt else e0
                minutes = end - s0
                long = any(x['t'] >= R['longStop'] for x in g)
                dm = [c for c in cs if c['dummy'] and c['s'] < end and c['e'] > s0 - 60]
                frm, to = (prev[-1]['fam'] if prev else ''), (nxt['fam'] if nxt else '')
                kind = '장기정지 후 재가동' if long else ('M/C' if frm and to and frm != to else '전환 휴지(강종 동일)')
                events.append({'line': l, 'at': min_to_str(s0), 'day': nxt['day'] if nxt else min_to_str(s0)[:10], 'from': frm, 'to': to, 'minutes': minutes,
                               'kind': kind, 'stopMin': sum(x['t'] for x in g), 'reason': g[0]['nm'], 'dummyN': len(dm), 'dummyT': sum(c['t'] for c in dm)})
                wins.append((s0 - 60, end))
                if long:
                    rs += minutes
                else:
                    sw += minutes
            for x in ev:
                if id(x) in in_g:
                    continue
                if x['t'] >= R['longStop']:
                    long_min += x['t']
                    longs.append({'at': min_to_str(x['s']), 'minutes': x['t'], 'reason': x['nm']})
                else:
                    equip += x['t']
            rg = {}
            for x in ev:
                k = ('M/C' if id(x) in in_g else ('계획' if x['cls'] == '1' else '비계획'), x['nm'] or '(사유 없음)')
                v = rg.setdefault(k, [0, 0])
                v[0] += x['t']
                v[1] += 1
            for (kind, nm), v in sorted(rg.items(), key=lambda kv: -kv[1][0]):
                reasons.append({'line': l, 'kind': kind, 'reason': nm, 'minutes': v[0], 'n': v[1]})
        else:
            basis = '코일 순서 추정'
            for i in range(1, len(seq)):
                a, b = seq[i - 1], seq[i]
                if a['fam'] == b['fam']:
                    continue
                between = [c for c in cs if c['s'] >= a['e'] and c['e'] <= b['s']]
                minutes = b['s'] + b['stop'] - a['e']
                long = b['stop'] >= R['longStop'] or any(c['stop'] >= R['longStop'] for c in between) or (b['s'] - a['e']) - sum(c['work'] for c in between) >= R['longStop']
                dm = [c for c in between if c['dummy']]
                events.append({'line': l, 'at': min_to_str(a['e']), 'day': b['day'], 'from': a['fam'], 'to': b['fam'], 'minutes': minutes,
                               'kind': '장기정지 후 재가동' if long else 'M/C', 'stopMin': b['stop'], 'reason': '', 'dummyN': len(dm), 'dummyT': sum(c['t'] for c in dm)})
                wins.append((a['e'], b['s'] + b['stop']))
                if long:
                    rs += minutes
                else:
                    sw += minutes
            in_w = lambda c: any(c['s'] < w1 and c['e'] > w0 for w0, w1 in wins)
            for c in cs:
                if not in_w(c) and c['stop'] >= R['longStop']:
                    long_min += c['stop']
                    longs.append({'at': min_to_str(c['s']), 'minutes': c['stop'], 'reason': ''})
        in_w = lambda c: any(c['s'] < w1 and c['e'] > w0 for w0, w1 in wins)
        prod_run = sum(c['run'] for c in prod)
        bg_dummy = sum(c['run'] for c in cs if c['dummy'] and not in_w(c))           # 더미는 가동시간만(더미 코일에 붙은 휴지는 사유별 휴지로)
        if not ev:                                                                 # 사유 없음: 나머지 시간 전부를 설비정지로
            equip = W - prod_run - sw - rs - long_min - bg_dummy
        other = W - prod_run - sw - rs - long_min - equip - bg_dummy
        op_days = (W - rs - long_min) / 1440
        mc = [e for e in events if e['line'] == l and e['kind'] == 'M/C']
        by_dir = {}
        for e in mc:
            by_dir.setdefault(f"{e['from']}→{e['to']}", []).append(e['minutes'])
        nan = float('nan')
        Li = lines[l] = {
            'from': min_to_str(W0), 'to': min_to_str(W1), 'days': W / 1440, 'opDays': op_days, 'coils': len(cs), 'tons': sum(c['t'] for c in prod),
            'dummyN': len(cs) - len(prod), 'dummyT': sum(c['t'] for c in cs if c['dummy']), 'basis': basis,
            'prodRun': prod_run, 'util': prod_run / W if W else nan, 'swMin': sw, 'rsMin': rs, 'longMin': long_min, 'longs': longs,
            'bgDummy': bg_dummy, 'bgStop': equip, 'other': other,
            'bgDummyPerDay': bg_dummy / op_days if op_days > 0 else nan, 'bgStopPerDay': equip / op_days if op_days > 0 else nan,
            'otherPerDay': other / op_days if op_days > 0 else nan,
            'mcN': len(mc), 'mcMedian': median([e['minutes'] for e in mc]), 'mcByDir': {k: median(v) for k, v in sorted(by_dir.items())},
        }
        long_ok = Li['opDays'] >= R['minDays']
        dir_txt = ', '.join(f'{k} {U.fmt(v)}' for k, v in Li['mcByDir'].items())
        cands.append({'path': ['switchDummy', l], 'label': f'{l} 강종전환(M/C) 손실', 'unit': '분/회', 'cur': P['switchDummy'][l], 'act': Li['mcMedian'], 'n': Li['mcN'],
                      'basis': f"M/C {Li['mcN']}건 중앙값(정지 시작~첫 제품코일, {basis})" + (f' · 방향별 {dir_txt}' if dir_txt else ''), 'ok': Li['mcN'] >= R['minEvents']})
        cands.append({'path': ['nonfamDummy', l], 'label': f'{l} 비강종 더미', 'unit': '분/일', 'cur': P['nonfamDummy'][l], 'act': Li['bgDummyPerDay'], 'n': Li['opDays'],
                      'basis': f"가동 {U.fmt(Li['opDays'], 1)}일, 전환 구간 밖 더미코일 가동시간", 'ok': long_ok})
        cands.append({'path': ['equipDown', l], 'label': f'{l} 설비정지', 'unit': '분/일', 'cur': P['equipDown'][l], 'act': Li['bgStopPerDay'], 'n': Li['opDays'],
                      'basis': (f"가동 {U.fmt(Li['opDays'], 1)}일, 전환·장기정지 외 휴지(사유 기준)" if ev else f"가동 {U.fmt(Li['opDays'], 1)}일, 전환·장기정지·더미 외 나머지 시간(추정)"), 'ok': long_ok})
        g = {}
        for c in prod:
            if not c['fam'] or not c['cls'] or not (0 < c['run'] < R['speedRunMax']):
                continue
            x = g.setdefault(_speed_key(c), {'t': 0, 'run': 0, 'n': 0, 'th': 0, 'w': 0})
            x['t'] += c['t']
            x['run'] += c['run']
            x['n'] += 1
            x['th'] += _nz(c['thick']) * c['t']
            x['w'] += _nz(c['width']) * c['t']
        for k, x in sorted(g.items()):
            _, al, cls = k.split('|')
            try:
                cur = U.rate_for(P, l, al, cls)
            except Exception:
                cur = None
            act = x['t'] / x['run']
            s = {'key': k, 'line': l, 'fam': al, 'cls': cls, 'n': x['n'], 't': x['t'], 'run': x['run'], 'act': act, 'cur': cur,
                 'diff': act / cur - 1 if cur else None, 'thick': x['th'] / x['t'], 'width': x['w'] / x['t']}
            speed.append(s)
            if P['rateDept'].get(k) is not None or cur is not None:
                cands.append({'path': ['rateDept', k], 'label': f'{l} {al} {cls} 속도', 'unit': 't/hr', 'scale': 60, 'cur': cur, 'act': act, 'n': x['n'],
                              'basis': f"{x['n']}코일 {U.fmt(x['t'])}t · 평균 {U.fmt(s['thick'], 2)}mm×{U.fmt(s['width'])}",
                              'ok': long_ok and x['n'] >= R['minCoils'] and x['t'] >= R['minTons']})
    for c in cands:
        c['diff'] = c['act'] / c['cur'] - 1 if c['cur'] and c['act'] == c['act'] else None
        c['flag'] = c['diff'] is not None and abs(c['diff']) >= R['tol']
        c['apply'] = c['ok'] and c['flag']
    dm = {}
    for c in coils:
        if not c['dummy'] and c['fam'] and c['cls']:
            k = (c['day'], c['line'], c['alloy'] or c['fam'], c['cls'])
            dm[k] = dm.get(k, 0) + c['t']
    daily = [[*k, U.js_round(t, 3)] for k, t in sorted(dm.items())]
    days = sorted(c['day'] for c in coils)
    return {'period': {'from': days[0] if days else None, 'to': days[-1] if days else None}, 'lines': lines, 'speed': speed, 'events': events,
            'reasons': reasons, 'daily': daily, 'cands': cands}


def apply(P, cands):
    import copy
    Q = copy.deepcopy(P)
    for c in cands:
        if c['act'] == c['act'] and c['act'] > 0:
            Q[c['path'][0]][c['path'][1]] = U.js_round(c['act'], 6 if c['path'][0] == 'rateDept' else 2)
    return Q


def summary(an, cl=None):
    def r(x, k=0):
        return U.js_round(x, k) if isinstance(x, (int, float)) and x == x else None
    return {
        'period': an['period'], 'analyzedAt': _dt.datetime.now(_dt.timezone.utc).isoformat(),
        'lines': {l: {'from': x['from'], 'to': x['to'], 'days': r(x['days'], 1), 'opDays': r(x['opDays'], 1), 'coils': x['coils'], 'tons': r(x['tons']), 'dummyT': r(x['dummyT']),
                      'util': r(x['util'], 4), 'mcN': x['mcN'], 'mcMedian': r(x['mcMedian'], 1), 'bgDummyPerDay': r(x['bgDummyPerDay'], 1),
                      'bgStopPerDay': r(x['bgStopPerDay'], 1), 'otherPerDay': r(x['otherPerDay'], 1), 'longMin': r(x['longMin']), 'basis': x['basis'],
                      'mcByDir': {k: r(v, 1) for k, v in x['mcByDir'].items()}} for l, x in an['lines'].items()},
        'speed': [{'key': s['key'], 'n': s['n'], 't': r(s['t']), 'act': r(s['act'], 6), 'cur': r(s['cur'], 6), 'thick': r(s['thick'], 3)} for s in an['speed']],
        'events': [{'line': e['line'], 'at': e['at'], 'from': e['from'], 'to': e['to'], 'minutes': e['minutes'], 'kind': e['kind']} for e in an['events']],
        'cands': [{'label': c['label'], 'unit': c['unit'], 'scale': c.get('scale', 1), 'cur': r(c['cur'], 6), 'act': r(c['act'], 6), 'ok': c['ok'], 'flag': c['flag']} for c in an['cands']],
        'warns': [c['msg'] for c in (cl or {}).get('checks', []) if c['level'] != 'info'],
    }


def to_actual(an, coils, R, t0_given=None):
    """재계획 입력 {t0, rows, state, extraDown, notes, checks} — 웹 GP.mesToActual 과 같음"""
    P, checks = R['P'], []
    H = U.horizon(P)
    t0 = ''
    for l in P['lines']:
        cs = [c for c in coils if c['line'] == l]
        if not cs:
            continue
        last = cs[-1]
        d = last['day']
        x = d if last['e'] >= to_min(U.add_days(d, 1)) + 360 else U.add_days(d, -1)
        if not t0 or x < t0:
            t0 = x
    if not t0:
        return {'checks': [{'level': 'error', 'msg': '실적 코일 없음'}]}
    if t0_given and t0_given < t0:
        t0 = t0_given
    elif t0_given and t0_given > t0:
        checks.append({'level': 'info', 'msg': f'기준일 {t0_given} → 실적이 다 들어온 마지막 날 {t0}로 조정'})
    if t0 < H['D0']:
        return {'checks': [{'level': 'error', 'msg': f"실적 마지막 완결일 {t0}이 계획 기간({H['D0']}~) 이전 — 재계획할 실적이 없음(실적 분석만 가능)"}]}
    before = [r for r in an['daily'] if r[0] < H['D0']]
    if before:
        checks.append({'level': 'info', 'msg': f"계획 기간 이전 실적 {U.fmt(sum(r[4] for r in before))}t은 재계획에서 제외"})
    raw = sorted(({'d': d, 'l': l, 'al': a_, 'fam': P['alloyFamily'].get(a_, a_), 'c': c, 't': t} for d, l, a_, c, t in an['daily'] if H['D0'] <= d <= t0), key=lambda x: x['d'])
    left = {(b['cls'], b['alloy'], b['due']): b['orig'] for b in R['buckets']}
    rows, over = [], {}
    for x in raw:
        t = x['t']
        bs = sorted((b for b in R['buckets'] if b['cls'] == x['c'] and P['alloyFamily'].get(b['alloy']) == x['fam'] and b['alloy'] in P['allowed'].get(x['l'], [])),
                    key=lambda b: (b['alloy'] != x['al'], b['due']))          # 같은 세부강종(AL-STS 등) 먼저, 그다음 이른 마감
        for b in bs:
            k = (b['cls'], b['alloy'], b['due'])
            take = min(t, max(0, left[k]))
            if take > 1e-6:
                rows.append([x['d'], x['l'], b['alloy'], b['cls'], U.js_round(take, 2), b['due']])
                left[k] -= take
                t -= take
            if t <= 1e-6:
                break
        if t > 0.5:
            k = f"{x['l']} {x['al']} {x['c']}"
            over[k] = over.get(k, 0) + t
    for l in P['lines']:
        cs = [c for c in coils if c['line'] == l]
        first = min(c['day'] for c in cs) if cs else U.add_days(t0, 1)
        if first <= H['D0']:
            continue
        last = U.add_days(first, -1) if first <= t0 else t0
        rows += [list(r) for r in R['rows'] if r[1] == l and H['D0'] <= r[0] <= last]
        checks.append({'level': 'warn', 'msg': f"{l} {U.md(H['D0'])}~{U.md(last)} 실적이 파일에 없음 — 이 기간은 계획대로 생산한 것으로 봄(쿼리 기간을 계획 시작 전부터로 늘리세요)" if cs else f"{l} 실적이 파일에 없음 — {l}은 ~{U.md(t0)} 계획대로 생산한 것으로 봄"})
    for k, t in over.items():
        checks.append({'level': 'warn', 'msg': f'실적 {k} {U.fmt(t)}t: 배정할 미완료 수요 없음(계획 밖 생산) — 재계획에서 제외'})
    state = {}
    for l in P['lines']:
        cs = [c for c in coils if c['line'] == l and not c['dummy'] and c['fam'] and c['day'] <= t0]
        c = next((c for c in R['cal'] if c['line'] == l and c['date'] == t0), None)
        state[l] = cs[-1]['fam'] if cs else (c['fam'] if c else P['initFamily'][l])
    plan_t = sum(r[4] for r in R['rows'] if r[0] <= t0)
    act_t = sum(r[4] for r in rows)
    notes = [f'MES 실적 ~{U.md(t0)}: {U.fmt(act_t)}t (계획 {U.fmt(plan_t)}t, 차이 {U.fmt(act_t - plan_t)}t)']
    checks.append({'level': 'info', 'msg': f'MES 실적 기준일 {t0}, 현재 강종 ' + '·'.join(f'{l} {state[l]}' for l in P['lines'])})
    return {'t0': t0, 'rows': rows, 'state': state, 'extraDown': {}, 'notes': notes, 'checks': checks}


def from_files(paths, P):
    cl = clean(tables(sheets_from_workbooks(paths)))
    if any(c['level'] == 'error' for c in cl['checks']):
        return cl, None
    return cl, analyze(cl['coils'], P, stops=cl['stops'])


def actual_from_tables(tbls, R, t0=None):
    """MES 쿼리 표 → 재계획 입력(정제 경고 포함)"""
    cl = clean(tbls)
    if any(c['level'] == 'error' for c in cl['checks']):
        return {'checks': cl['checks']}
    act = to_actual(analyze(cl['coils'], R['P'], stops=cl['stops']), cl['coils'], R, t0)
    act['checks'] = cl['checks'] + act.get('checks', [])
    return act


def weekly(coils, R=RULES):
    """주별(월요일 시작, 생산계상일자 기준) 라인×강종×부서 제품 톤·가동시간 → 속도 추이. 행: [주, 라인, 강종, 부서, 톤, 가동분, 코일수]"""
    g = {}
    for c in coils:
        if c['dummy'] or not c['fam'] or not c['cls'] or not (0 < c['run'] < R['speedRunMax']):
            continue
        d = _dt.date.fromisoformat(c['day'])
        wk = (d - _dt.timedelta(days=d.weekday())).isoformat()
        x = g.setdefault((wk, c['line'], c['alloy'] or c['fam'], c['cls']), [0.0, 0.0, 0])
        x[0] += c['t']
        x[1] += c['run']
        x[2] += 1
    return [[*k, U.js_round(v[0], 3), U.js_round(v[1], 1), v[2]] for k, v in sorted(g.items())]


def export(an, cl, coils):
    """분석 화면(analysis.html)용 전체 결과 — 웹 GP.mesExport 와 같은 형식"""
    def r(x, k=0):
        return U.js_round(x, k) if isinstance(x, (int, float)) and x == x else None
    out = summary(an, cl)
    out.update({
        'app': 'cgl-analysis', 'version': 1,
        'speed': [{'key': s['key'], 'n': s['n'], 't': r(s['t'], 1), 'run': r(s['run']), 'act': r(s['act'], 6), 'cur': r(s['cur'], 6), 'thick': r(s['thick'], 3), 'width': r(s['width'])} for s in an['speed']],
        'events': [{'line': e['line'], 'at': e['at'], 'from': e['from'], 'to': e['to'], 'minutes': e['minutes'], 'kind': e['kind'], 'stopMin': e['stopMin'], 'reason': e['reason'],
                    'dummyN': e['dummyN'], 'dummyT': r(e['dummyT'], 1)} for e in an['events']],
        'reasons': an['reasons'],
        'cands': [{'path': c['path'], 'label': c['label'], 'unit': c['unit'], 'scale': c.get('scale', 1), 'cur': r(c['cur'], 6), 'act': r(c['act'], 6), 'n': r(c['n'], 1), 'basis': c['basis'],
                   'ok': c['ok'], 'flag': c['flag'], 'apply': c['apply']} for c in an['cands']],
        'daily': an['daily'], 'weekly': weekly(coils),
        'checks': (cl or {}).get('checks', []),
    })
    return out
