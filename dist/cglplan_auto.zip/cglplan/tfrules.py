"""재고 목표 기준(TF 목표 일수·공장 월말 최대) — 포털 '재고 목표 기준' 화면에서 고친 값을 계획 계산에 씀(2026-10-22 사용자: 우리가 수정할 수 있게).
원본 = cglplan/tf_rules.json(설치 묶음에 같이 들어감). 화면에서 저장한 값은 Supabase 표 cgl_tf_rules 에 암호화돼 쌓이고(추가만),
`python tools/tf_rules.py pull` 이 가장 최근 유효한 값을 이 파일로 가져옴 → 다음 계획 계산부터 적용."""
import json
import os

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tf_rules.json')
TABLE = 'cgl_tf_rules'
DAY_KEYS = ('G수출', 'G국내', 'G자가재', 'AL-STS', '임가공', '기타', '건재수출', '가전수출', '가전내수', '주문재', '수요개발')
MAX_KEYS = ('도금 소재(F/H)', '도금 제품(판매재)', '컬러 소재', '컬러 제품')


def validate(o):
    """화면에서 온 값 검사 — 모르는 항목·범위 밖 값이 있으면 ValueError. 정리된 {days, stockMax} 반환"""
    if not isinstance(o, dict):
        raise ValueError('형식 오류')
    d, m = o.get('days') or {}, o.get('stockMax') or {}
    if set(d) != set(DAY_KEYS) or set(m) != set(MAX_KEYS):
        raise ValueError('항목이 맞지 않음')
    out = {'days': {}, 'stockMax': {}}
    for k in DAY_KEYS:
        v = float(d[k])
        if not 0 <= v <= 120:
            raise ValueError(f'{k} 목표 일수 {v} — 0~120일')
        out['days'][k] = int(v) if v == int(v) else v
    for k in MAX_KEYS:
        v = float(m[k])
        if not 0 < v <= 100000:
            raise ValueError(f'{k} 월말 최대 {v} — 0~100,000t')
        out['stockMax'][k] = int(round(v))
    return out


def load():
    o = json.load(open(PATH, encoding='utf-8'))
    return dict(validate(o), src=o.get('src') or {})


R = load()
DAYS, STOCK_MAX, SRC = R['days'], R['stockMax'], R['src']
