"""웹 화면용 자료를 매일 다시 계산한다(사내 PC 자동 실행기 5-5단계, 클라우드에서는 tools/pages_build.py).

만드는 것(모두 published/ 버킷에 게시):
  color_actual.enc.json  컬러 실적(진도·일별·주별·품명·휴지)            ← extradata: color_prod·color_brk·snap_salesrpt
  procure.enc.json       조달 판단(수요·업체는 기준 파일, 재고만 매일)   ← pages_base/procure_base.json + snap_mat_stock_cc·snap_stock + 도금 코일
  planstock.enc.json     계획재 분석·예측(R15 187 사양)                    ← pages_base/planstock_base.json + color_prod·ship·snap_stock (cglplan/planstock.py)
  color_cond.enc.json    컬러 조건 분석(계획 t/hr vs 최근 4주)               ← pages_base/color_cond_base.json + color_prod (cglplan/color_cond.py)
  portal.enc.json        홈 요약(오늘 볼 것·계획 정확도·지표)           ← 위 둘 + 최신 계획(R2) + pages_base/portal_base.json + 정확도 이력
  status.json            자료 상태(암호 없음, 날짜·건수만)               ← 원천별 마지막 날짜·실행 결과
정의는 tools/color_actual.py·procure_data.py·portal_data.py 와 같다(그 스크립트들도 이 모듈을 쓴다).
기준 파일(pages_base/*.json)은 계획이 바뀔 때 클라우드에서 tools/pages_build.py --base 로 다시 만든다.
"""
import datetime as dt
import json
import os
import re
from collections import Counter, defaultdict

from . import salesrpt, util as U, yields as YL

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pages_base')
CCL = ['1CCL', '2CCL', '3CCL', '4CCL']
CGL = ['1CGL', '2CGL']
STOP_CATS = [('색상교체·청소', ('청소', '색상', '준비')), ('테스트·도막조정', ('TEST', '단판', '도막', '조색')),
             ('폭·롤·두께 전환', ('폭', 'ROLL', '두께', 'DUMMY')), ('기타', ())]
FH_OF = {'AL': 'H', 'AL-LG': 'H', 'AZ': 'F', 'MAC': 'F', 'AL-STS': 'N'}
USABLE = ('사용가능', '작업지시대기', '가공대기', '가공대상')
# 마케팅 그룹(MES 판매그룹 이름 기준). 자가재 = 도금이 만든 컬러 소재(MES 에선 컬러 그룹 이름으로 잡힘)
GROUPS = [('G수출', '도금수출', 'G'), ('G국내', '도금판매(국내)', 'G'), ('G자동차', '자동차강판', 'G'), ('G자가재', '도금 자가재(컬러 소재)', 'G'),
          ('C수출', '컬러수출', 'C'), ('C건재', '컬러건재', 'C'), ('C수요', '수요개발', 'C')]
PLAN_GROUP = {'도금수출': 'G수출', '도금국내': 'G국내', '자동차수출': 'G자동차', '자동차내수': 'G자동차', '자가재': 'G자가재'}        # 계획 부서 → 그룹
SHIP_NAME = {'G국내': '도금판매', 'G수출': '도금수출', 'G자동차': '자동차강판', 'C수출': '컬러수출', 'C건재': '컬러건재'}   # 재고 그룹 → 판매생산속보 출하 줄
COLOR_GROUP = {'가전수출': 'C수출', '가전내수': 'C수출', '건재수출': 'C수출', '계획재': 'C건재', '주문재': 'C건재', '수요개발': 'C수요'}   # cglplan/color_full 분류
COIL_GROUP = {'도금수출그룹': 'G수출', '도금판매그룹': 'G국내', '자동차강판판매그룹': 'G자동차',
              '컬러수출그룹': 'G자가재', '컬러건재판매그룹': 'G자가재', '수요개발그룹': 'G자가재', '컬러공장': 'G자가재'}
CPROD_GROUP = {'컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재', '수요개발그룹': 'C수요'}
SHIP_GROUP = {'도금판매': 'G국내', '도금수출': 'G수출', '자동차강판': 'G자동차', '컬러수출': 'C수출', '컬러건재': 'C건재'}
SHIP_DEPT = {'도금판매그룹': 'G국내', '도금수출그룹': 'G수출', '자동차강판판매그룹': 'G자동차', '컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재'}   # MES 출하(ship) 부서 → 그룹(tools/integrated_web 과 같음)
BRK_LINE = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}
SAFETY = {'C': 7, 'G': 5}                                    # 입고 → 투입 여유(팀 소재 리드타임 표 2026-10-12: 컬러 +7일, 도금 자가 +5일)
POSCO_SUPPLIED = {('G', 'N')}                                # 임가공 AL-STS F/H = 포스코 지급(우리 발주 아님)


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def D(s):
    return dt.date.fromisoformat(str(s)[:10])


def week_of(d):
    x = D(d)
    return (x - dt.timedelta(days=x.weekday())).isoformat()


_COLOR_SWAP = None


def stop_cat(t):
    global _COLOR_SWAP
    t = t or ''
    if _COLOR_SWAP is None:
        import re
        _COLOR_SWAP = re.compile(r'(?<![A-Z0-9])(?=[A-Z0-9]*\d)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{5,9}(?![A-Z0-9])(\s*/\s*[A-Z0-9]{4,9})*\s*-+>')   # 'GT1BW10S/VL9N270S -> GS1KS20S' = 도료(색상) 코드 교체
    if _COLOR_SWAP.search(t.upper()) and not any(k in t.upper() for k in ('폭', 'ROLL', '두께', 'DUMMY')):
        return STOP_CATS[0][0]
    for name, keys in STOP_CATS:
        if any(k in t for k in keys):
            return name
    return '기타'


def load_base(name):
    p = os.path.join(BASE, name)
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else None


def _rows(T, name):
    t = T.get(name)
    return [dict(zip(t['columns'], r)) for r in t['rows']] if t else []


_CODES = None


def product_name(code):
    global _CODES
    if _CODES is None:
        _CODES = (load_base('color_product_codes.json') or {}).get('codes', {})
    s = str((_CODES.get(code) or {}).get('name', code) or '').strip()
    import re
    s = re.sub(r'\(MAC\.?\)', '', s, flags=re.I)
    s = re.sub(r'\((가전|후물|프)\)', '', s)
    return s.split('_')[0].strip()


# ------------------------------------------------------------------ 컬러 실적
def show_days(d_first, d_last):
    """일별 그래프 기간: 이번 달 1일부터(7일 미만 지났으면 지난달 1일부터), 자료 시작일 이전은 빼고 — 자료 없는 날을 0으로 그리지 않게"""
    a = d_last.replace(day=1)
    if d_last.day < 7:
        a = (a - dt.timedelta(days=1)).replace(day=1)
    a = max(a, d_first)
    return [(a + dt.timedelta(days=i)).isoformat() for i in range((d_last - a).days + 1)]


def full_months(months, d_first):
    """월별 표: 자료가 1일부터 있는 달만(첫 달이 중간부터면 뺌 — '9월(28일~)' 같은 잘린 달 제외). 다 빠지면 그대로"""
    out = [m for m in months if not (m == d_first.isoformat()[:7] and d_first.day > 1)]
    return out or months


CG_PLAN = ('계획재', '주문재', '건재수출', '가전수출', '가전내수', '수요개발')           # 컬러 계획 그룹(통합 계획 color 행의 g 키)


def con_export(cn, dom=None):
    """계약이 수출인지 — MES 주문 머리 DOM_CLS(E 수출 / D 내수)가 있으면 그것, 없으면 계약번호의 수주형태 글자
    (P… 계약 5번째·C… 계약 2번째 자리, K = 종합상사수출 K0). 2026-10-20 검증: 컬러 계약 5,235건에서 두 기준 예외 없이 일치.
    (10/13 'PG…K = 내수' 예외는 재고현황 수주(임)를 믿은 오류 — PG…K 는 DOM_CLS E·K0, 도착지 GEMLIK·LAZARO CARDENAS 등 실제 수출)"""
    if dom in ('E', 'D'):
        return dom == 'E'
    cn = str(cn or '')
    if len(cn) < 5:
        return False
    return (cn[4] if cn[0] == 'P' else cn[1]) == 'K'


def con_dom_map(T):
    """계약번호 → DOM_CLS (hist_cc_con_dept_a/b · snap_raw_ask_dept)"""
    m = {}
    for n in ('hist_cc_con_dept_a', 'hist_cc_con_dept_b', 'snap_raw_ask_dept'):
        for r in _rows(T, n):
            if r.get('DOM_CLS') in ('E', 'D'):
                m[str(r['CON_NO'])] = r['DOM_CLS']
    return m


def color_grouper(T):
    """MES 컬러 생산 코일 → 계획 그룹(통합 계획과 같은 6개, tools/integrated_plan.py 도 이 함수를 씀)
    · 컬러건재판매그룹 → R15 계획재 사양(두께 ±0.03·폭·상도색상)이면 계획재, 아니면 주문재(건재 주문재)
    · 수요개발그룹 → 수요개발
    · 컬러수출그룹: 주문 용도 CC*(건재) → 건재수출, 그 밖(CE* 가전) → 계약이 수출이면 가전수출, 내수면 가전내수(con_export)
      판매계획 그룹과 같은 뜻: 가전내수 = 엘지(창원·저가내수·저가수출)·삼성 등 내수 계약, 가전수출 = 멕시코·인도·터키 등 수출 계약"""
    dom = con_dom_map(T)
    from . import planstock as PSm
    base = load_base('planstock_base.json') or {}
    m = PSm._M(base['specs']) if base.get('specs') else None

    def g(x):
        dept = str(x.get('DEPT') or '')
        if dept.startswith('컬러건재'):
            return '계획재' if m and m(f(x['REAL_MSR_THK']), f(x['PDT_WDT']), x['SUR_FINISH_CD']) is not None else '주문재'
        if dept.startswith('수요'):
            return '수요개발'
        if str(x.get('ORD_USG_CD') or '').startswith('CC'):
            return '건재수출'
        cn = str(x.get('CON_NO') or '')
        return '가전수출' if con_export(cn, dom.get(cn)) else '가전내수'
    return g


def color_group_daily(T):
    """컬러 가동현황용 일·라인별 실적: {d: {line: [{그룹: t}, 작업+정지 분]}} — 매일 사내 PC 가 다시 계산(계획 그룹으로 분류)"""
    rows = _rows(T, 'color_prod')
    if not rows:
        return None
    grp = color_grouper(T)
    out = defaultdict(lambda: defaultdict(lambda: [defaultdict(float), 0.0, defaultdict(float)]))
    for r in rows:
        x = out[str(r['PRD_DT'])[:10]][r['LINE']]
        t = f(r['PDT_WGT']) / 1000
        x[0][grp(r)] += t
        x[1] += f(r['WRK_TIME']) + f(r['PAU_TIME'])
        x[2][product_name(r['PDT_NM'])] += t
    top = lambda p: [[k, round(v, 1)] for k, v in sorted(p.items(), key=lambda kv: -kv[1])[:5]]
    return {'asOf': max(out), 'days': {d: {l: [{g: round(t, 1) for g, t in v[0].items()}, round(min(1440.0, v[1])), top(v[2])] for l, v in L.items()} for d, L in sorted(out.items())}}


DOWN_KIND = {'색상교체·청소': 'color', '테스트·도막조정': 'test', '폭·롤·두께 전환': 'roll', '기타': 'etc'}


PROD_DAY_START = 420                                            # MES 모든 일수 기준 = 07:00(10/22 사용자) — 07:00~다음날 07:00 이 하루


def color_down_actual(T, d0='2026-10-01'):
    """컬러 지난 날 실제 휴지(분): {d: {line: [[종류, 분], ...]}} — 그날 07시~다음날 07시를 1분 칸으로 나눠 코일 작업 > 휴지 기록 순으로 채우고,
    둘 다 없는 시간 = 'gap'(기록 없는 정지 — TEST 운전·라인 정지처럼 MES 휴지 기록에 안 남는 시간).
    2026-10-21 사용자: 4CCL 10/14 화면은 계획 Test 8h 였는데 실제 TEST 11.8h — 휴지 기록엔 4.8h 뿐이고 10:17~22:25 는 0t·시험 코일만 있어 기록 없는 정지로 잡아야 맞음"""
    prod, brk = _rows(T, 'color_prod'), _rows(T, 'color_brk')
    if not prod:
        return None
    ms = lambda v: f(v) / 1000 + 9 * 3600 if f(v) > 1e11 else None          # 한국 시각 초
    last = max(str(r['PRD_DT'])[:10] for r in prod)
    days = []
    x = D(d0)
    while x <= D(last):
        days.append(x.isoformat()); x += dt.timedelta(days=1)
    if not days:
        return None
    base = (dt.datetime.fromisoformat(days[0]) - dt.datetime(1970, 1, 1)).total_seconds() + PROD_DAY_START * 60   # 하루 = 07:00~다음날 07:00(MES 일수 기준, 10/22 사용자)
    n = len(days) * 1440
    slot = {l: [None] * n for l in CCL}

    def paint(l, s, e, k, over):
        if s is None or e is None or e <= s:
            return
        a, b = max(0, int((s - base) // 60)), min(n, int((e - base) // 60 + 0.999))
        sl = slot[l]
        for i in range(a, b):
            if over or sl[i] is None:
                sl[i] = k
    for r in prod:
        if r.get('LINE') in slot:
            paint(r['LINE'], ms(r.get('WRK_STA_TM')), ms(r.get('WRK_END_TM')), 'run', True)
    seen = set()
    for r in brk:
        l = BRK_LINE.get(str(r.get('LINE_CLS') or '')[:1])
        key = (l, r.get('PAU_STA_TM'))
        if not l or key in seen:
            continue
        seen.add(key)
        paint(l, ms(r.get('PAU_STA_TM')), ms(r.get('PAU_END_TM')), DOWN_KIND.get(stop_cat(r.get('SPL_REM')), 'etc'), False)
    out = {}
    for di, d in enumerate(days):
        for l in CCL:
            c = Counter(slot[l][di * 1440:(di + 1) * 1440])
            c.pop('run', None)
            c['gap'] = c.pop(None, 0)
            v = [[k, m] for k, m in sorted(c.items(), key=lambda kv: -kv[1]) if m > 0]
            if v:
                out.setdefault(d, {})[l] = v
    return {'asOf': last, 'days': out}


def color_actual(T):
    rows = _rows(T, 'color_prod')
    if not rows:
        return None
    last = max(r['PRD_DT'] for r in rows)
    d_last = D(last)
    d_first = D(min(r['PRD_DT'] for r in rows))
    full = lambda w: D(w) >= d_first and D(w) + dt.timedelta(days=6) <= d_last      # 자료 첫 주·마지막 주가 잘린 주는 추이에서 뺌
    weeks = sorted({week_of(r['PRD_DT']) for r in rows if full(week_of(r['PRD_DT']))}) or [week_of(last)]   # 자료가 1주 미만이어도 동작
    w1 = weeks[-1]
    cut4 = weeks[-4] if len(weeks) >= 4 else weeks[0]                       # 품목별 = 최근 4주(자료가 짧으면 있는 만큼)
    w0s = weeks[-13:-1] or weeks[-1:]
    day = defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    mon = defaultdict(float)
    dept = defaultdict(float)
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for r in rows:
        d, l = r['PRD_DT'], r['LINE']
        t = f(r['PDT_WGT']) / 1000
        h = (f(r['WRK_TIME']) + f(r['PAU_TIME'])) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(r['PAU_TIME']) / 60; x[4] += t * f(r['REAL_MSR_THK'])
        mon[(d[:7], l)] += t
        dept[(d[:7], str(r['DEPT'] or '기타'))] += t
        if d >= cut4:
            p = prod[(l, product_name(r['PDT_NM']))]
            p[0] += t; p[1] += h; p[2] += t * f(r['REAL_MSR_THK'])
    stop = defaultdict(float)
    for r in _rows(T, 'color_brk'):
        d = str(r['WRK_DT'])
        d = f'{d[:4]}-{d[4:6]}-{d[6:]}'
        l = BRK_LINE.get(str(r.get('LINE_CLS') or '')[:1], str(r.get('LINE_CLS')))
        stop[(week_of(d), l, stop_cat(r.get('SPL_REM')))] += f(r['PAU_TIME']) / 60

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s / max(n, 1), 'thick': th / t if t else None}
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = show_days(d_first, d_last)
    months = full_months(months, d_first)
    return {'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': last, 'from': min(r['PRD_DT'] for r in rows), 'w1': w1, 'w0': [w0s[0], w0s[-1]], 'nW0': len(w0s), 'plant': 'C', 'byGroup': color_group_daily(T), 'downAct': color_down_actual(T),
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CCL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '컬러']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CCL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 1), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CCL}} for w in weeks],
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CCL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CCL},
            'stops': {'cats': [c for c, _ in STOP_CATS],
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c, _ in STOP_CATS} for l in CCL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c, _ in STOP_CATS} for l in CCL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CCL) / 7, 2) for c, _ in STOP_CATS}} for w in weeks]}}


# ------------------------------------------------------------------ 도금 실적 (컬러 실적과 같은 구성·같은 정의)
G_STOP_CATS = ['강종 전환(M/C)', '정기수리', '설비·운전', '기타']


def g_stop_cat(nm, dtl):
    nm, dtl = str(nm or ''), str(dtl or '')
    if 'mode change' in nm.lower() or 'MODE CHANGE' in dtl.upper():
        return G_STOP_CATS[0]
    if '정기수리' in nm or '정기수리' in dtl:
        return G_STOP_CATS[1]
    if any(k in dtl for k in ('기계', '전기', '운전')):
        return G_STOP_CATS[2]
    return G_STOP_CATS[3]


def plating_actual(T, coils, stops=None):
    """도금 1·2CGL 실적 — color_actual 과 같은 키(lines·month·daily·weekly·monthly·dept·products·stops) + mc(강종 전환 실적).
    톤 = 더미 제외 코일(판매생산속보·재계획과 같은 기준), 속도 = 생산 t ÷ 작업시간(정지 포함 = 달력 시간), 컬러 실적과 같은 정의"""
    C = [c for c in (coils or []) if not c.get('dummy')]
    if not C:
        return None
    last = max(str(c['day']) for c in C)
    d_last = D(last)
    d_first = D(min(str(c['day']) for c in C))
    full = lambda w: D(w) >= d_first and D(w) + dt.timedelta(days=6) <= d_last
    weeks = sorted({week_of(c['day']) for c in C if full(week_of(c['day']))}) or [week_of(last)]
    w1 = weeks[-1]
    cut4 = weeks[-4] if len(weeks) >= 4 else weeks[0]
    w0s = weeks[-13:-1] or weeks[-1:]
    day, mon, dept = defaultdict(float), defaultdict(float), defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for c in coils:                                              # 시간은 더미 코일 포함(M/C 정지가 더미에 붙음), 톤은 더미 제외
        d, l, t = str(c['day']), c['line'], (0.0 if c.get('dummy') else f(c['t']))
        h = f(c.get('work')) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(c.get('stop')) / 60; x[4] += t * f(c.get('thick'))
        mon[(d[:7], l)] += t
        dept[(d[:7], str(c.get('dept') or '기타'))] += t
        if d >= cut4:
            p = prod[(l, f"{c.get('pname') or '-'} · {c.get('alloy') or c.get('fam') or '-'}")]
            p[0] += t; p[1] += h; p[2] += t * f(c.get('thick'))
    prd_day = {c.get('prd'): str(c['day']) for c in coils or []}
    run = defaultdict(float)                                     # 일·라인 가동 분(더미 제외 코일 run) — 화면 가동시간, 생산일 경계에 걸친 코일로 넘치는 날은 1,440분
    for c in C:
        run[(str(c['day']), c['line'])] += f(c.get('run'))
    drun = defaultdict(float)                                    # 더미 코일 가동 분(M/C·전환 때 통판) — 24시간 구성(10/22 사용자: 24시간 안 되는 날 이유)
    for c in coils or []:
        if c.get('dummy'):
            drun[(str(c['day']), c['line'])] += f(c.get('run'))
    stop = defaultdict(float)
    dstop = defaultdict(float)                                   # 일·라인·종류·사유 휴지 분
    mc = defaultdict(lambda: {'h': 0.0, 'nm': ''})
    for x in stops or []:
        d = prd_day.get(x.get('prd')) or (dt.datetime(1970, 1, 1) + dt.timedelta(minutes=f(x.get('s')) - PROD_DAY_START)).date().isoformat()   # 생산번호 없는 휴지 = 07시 기준 날짜
        cat = g_stop_cat(x.get('nm'), x.get('dtl'))
        stop[(week_of(d), x['line'], cat)] += f(x.get('t')) / 60
        if d >= '2026-10-01':
            dstop[(d, x['line'], cat, str(x.get('nm') or x.get('dtl') or '사유 없음').strip())] += f(x.get('t'))
        if cat == G_STOP_CATS[0]:
            m = mc[(d, x['line'])]
            m['h'] += f(x.get('t')) / 60
            m['nm'] = m['nm'] or str(x.get('nm') or '')

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s_ = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s_ / max(n, 1), 'thick': th / t if t else None}
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = show_days(d_first, d_last)
    months = full_months(months, d_first)
    import re
    mcl = []
    for (d, l), m in sorted(mc.items()):
        g = re.search(r'\(\s*(\w+)\s*-?>\s*(\w+)\s*\)', m['nm'])
        fr, to = (g.group(1), g.group(2)) if g else ('', '')
        fam = {'GI': 'MAC'}
        mcl.append({'d': d, 'line': l, 'from': fam.get(fr, fr), 'to': fam.get(to, to), 'h': round(m['h'], 1), 'sd': '정기수리' in m['nm']})
    return {'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': last, 'from': min(str(c['day']) for c in C), 'w1': w1, 'w0': [w0s[0], w0s[-1]], 'nW0': len(w0s), 'plant': 'G',
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CGL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '도금']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CGL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 1), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CGL}} for w in weeks],
            'dayMin': {d: {l: round(min(1440.0, run[(d, l)])) for l in CGL if run[(d, l)] > 0} for d in sorted({k[0] for k in run}) if d >= '2026-10-01'},
            'dayDummy': {d: {l: round(drun[(d, l)]) for l in CGL if drun[(d, l)] > 0} for d in sorted({k[0] for k in drun}) if d >= '2026-10-01'},
            'dayStops': {d: {l: [[c, round(m), nm] for (d2, l2, c, nm), m in sorted(dstop.items(), key=lambda kv: -kv[1]) if d2 == d and l2 == l and m >= 1] for l in CGL}
                         for d in sorted({k[0] for k in dstop})},
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CGL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CGL},
            'stops': {'cats': G_STOP_CATS,
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c in G_STOP_CATS} for l in CGL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c in G_STOP_CATS} for l in CGL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CGL) / 7, 2) for c in G_STOP_CATS}} for w in weeks]},
            'mc': mcl[-12:]}


# ------------------------------------------------------------------ 조달 판단: 재고
def procure_stock(T, coils, today):
    """컬러 = 소재재고List 재고중량(사용 가능 구분, 자가 제외) · 도금 FH = 최근 월말 재고현황 − 그 뒤 도금 실적 사용량(실수율 반영)"""
    st = defaultdict(float)
    for r in _rows(T, 'snap_mat_stock_cc'):
        b = str(r.get('구매처') or '')
        if ':' not in b or b.startswith('A1') or r.get('재고구분') not in USABLE:
            continue
        w = f(r.get('재고중량')) / 1000
        if w > 0:
            st[('C', str(r.get('Zn') or '')[:1])] += w
    S = _rows(T, 'snap_stock')
    months = sorted({str(r['_기준월']) for r in S if r.get('공장구분') == 'G'})
    m_last = months[-1] if months else None
    if m_last:
        for r in S:
            if r['구분명'] == 'R' and r['공장구분'] == 'G' and str(r['_기준월']) == m_last and str(r.get('소재공급업체') or '') != 'A1':
                if not (f(r.get('재고일수')) > 180 or str(r.get('제품등급')).strip() == '5'):
                    st[('G', str(r['품명코드']))] += f(r['중량']) / 1000
        y, m = int(m_last[:4]), int(m_last[4:])
        after = dt.date(y + (m == 12), m % 12 + 1, 1).isoformat()
        for c in coils or []:
            if after <= str(c['day']) < today:
                a = c.get('alloy') or c.get('fam')
                st[('G', FH_OF.get(a, 'F'))] -= f(c['t']) / (YL.plating(c['line'], a, c.get('cls')) / 100)
        E = [r for r in _rows(T, 'snap_raw_ent') if r.get('PLT_CLS') == 'G' and str(r.get('RAW_SUP_CPY') or '') != 'A1']
        e0 = min((str(r['ENT_DT']) for r in E if r.get('ENT_DT')), default='99999999')
        got = e0 <= after.replace('-', '')                          # 입고 원장이 월말 다음 날부터 있을 때만(빠진 날이 없게)
        if got:
            for r in E:
                d = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or '')
                if after.replace('-', '') <= d < today.replace('-', ''):
                    st[('G', str(r.get('RAW_GRP') or 'F'))] += f(r.get('RAW_ENT_WGT')) / 1000
    note = (f"컬러 = 소재재고List(CC) 재고중량 · 도금 FH = {m_last[:4]}.{m_last[4:]}월말 재고 + 이후 MES 입고 − 이후 도금 실적 사용" if m_last and got
            else f"컬러 = 소재재고List(CC) 재고중량 · 도금 FH = {m_last[:4]}.{m_last[4:]}월말 재고 − 이후 도금 실적 사용(입고는 자료 없음)" if m_last else '재고 자료 없음')
    return {f'{k[0]}:{k[1]}': round(max(0.0, v), 1) for k, v in st.items()}, note


def sup_names(T):
    """소재 공급사 코드 → 이름: 누적 기록(pages_base/supplier_names.json) + 오늘 소재재고List 구매처('코드: 이름') + MES 공급사 표(SMKT.CR_SUP, 있으면)"""
    names = dict((load_base('supplier_names.json') or {}).get('names', {}))
    for r in _rows(T, 'snap_mat_stock_cc'):
        b = str(r.get('구매처') or '')
        if ':' in b:
            c, n = (x.strip() for x in b.split(':', 1))
            if c and n:
                names.setdefault(c, n)                                   # 누적 기록에서 고친 이름(C2 등) 유지
    # MES 공급사 표: 업체 구분코드(SUP_CPY_CLS, 15자리) 앞 2자리 = 발주번호 앞 2자리(원료업체만 — 선사·운송 등도 앞자리가 겹침).
    # 소재재고List 구매처와 겹치는 15개 코드가 모두 같은 업체로 확인됨(C2 동부제철 = 현 케이지스틸). 같은 앞자리가 둘이면 끝자리 1(현행) 우선, X(구) 는 뒤
    best = {}
    for r in _rows(T, 'snap_sup_name') + _rows(T, 'snap_sup_name2'):
        c, n = str(r.get('SUP_CPY_CLS') or ''), str(r.get('CPY_NM_KOR_LANG') or r.get('CPY_NM_ENG') or '').strip()
        if r.get('SUP_CPY_CLS_NM') != '원료업체' or not n or not re.fullmatch(r'[0-9A-Z]{2}[0-9X]{13}', c):
            continue
        rank = 0 if c.endswith('1') else 2 if 'X' in c else 1
        if c[:2] not in best or rank < best[c[:2]][0]:
            best[c[:2]] = (rank, n)
    for c, (_, n) in best.items():                                # 이미 아는 코드는 짧은 이름 유지(표 이름은 법인 정식명)
        names.setdefault(c, re.sub(r'\s*(주식회사|유한회사|\(주\))\s*', '', n) or n)
    for r in _rows(T, 'snap_code_detail') + _rows(T, 'snap_code_detail1') + _rows(T, 'snap_code_detail2') + _rows(T, 'snap_code_detail3'):
        if r.get('MASTER_CD') == 'RAW_MFG_CPY_CD' and r.get('CD_VAL') and r.get('CD_NM'):   # MES 코드조회-소재제조업체(SCOMB0030 과 같은 표) — 새 업체도 자동
            names.setdefault(str(r['CD_VAL']), str(r['CD_NM']).strip())
    for r in _rows(T, 'snap_raw_ask'):                               # V 계열 = 해외 업체(V0 DB Inc.·V1 천진TROSCO·V2 REN ZE) — 표에 없는 V3·V4 는 이름 확인 전까지 이렇게 표시
        c = str(r.get('RAW_SUP_CPY') or '')
        if c[:1] == 'V' and c not in names:
            names[c] = f'수입({c}, 업체명 확인 중)'
    return names


def color_supply(T, today):
    """컬러 구매 소재 공급(코드별 날짜별 t): 소재재고List(사용 가능, 자가 제외) = 오늘, MES 미입고 발주 = 입고 예정일.
    톤만 담음(단가 없음) — 웹 컬러 계획 계산(몰기 소재 입고 제약)용으로 color_calc_mes 에 'color_supply' 표로 실림"""
    st, _ = procure_stock(T, [], today)
    sup = defaultdict(Counter)
    for k, t in st.items():
        pl, c = k.split(':', 1)
        if pl == 'C' and t > 0:
            sup[c][today] += t
    mo, _ = open_orders(T, today, load_base('procure_base.json') or {})
    for a in mo or []:
        if a.get('plant') == 'C':
            sup[a['code']][a['date']] += a['t']
    return sup


STALE_DAYS = 30                                                      # 기발주: 예정일(발주일+리드타임)이 이만큼 지나면 충당에서 제외(확인 목록)
G_GROUPS = ('F', 'H', 'T', 'Y', 'N')                                # F/H 계열·도금용 SUS = 도금 소재, 나머지 = 컬러 구매 소재


def open_orders(T, today, base):
    """MES 미입고 발주(기발주) = 발주(SMAT.MO_GC_ORD_ASK) − 입고(SMAT.MO_ENT), 발주 행번별.
    · 빼는 것: 자가(A1, 도금→컬러 사내 공급)·삭제(WRK_CLS D)·주문량의 10% 또는 1t 이하 잔량(입고 끝난 것으로 봄 — 입고/주문 중앙값 0.98)
    · 입고 합계(snap_raw_ent_sum, 240일)가 있으면 180일 발주 전부, 없으면 입고 원장(60일) 시작일 이후 발주만(그 전 발주는 앞선 입고를 몰라 뺌)
    · 입고 예정일 = 발주일 + 그 업체·소재 리드타임(업체 기준정보, MES 발주→입고 실적) — MES 의 납기 칸은 발주일과 거의 같아 쓰지 않음.
      예정일이 지났는데 안 들어온 것은 내일 입고로 봄(지연 표시)"""
    A, S_, E = _rows(T, 'snap_raw_ask'), _rows(T, 'snap_raw_ent_sum'), _rows(T, 'snap_raw_ent')
    if not A or not (S_ or E):
        return [], None
    rec, start = Counter(), '00000000'
    if S_:
        for r in S_:
            rec[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] += f(r.get('ENT_WGT'))
    else:
        start = min(str(r['ENT_DT']) for r in E if r.get('ENT_DT'))
        for r in E:
            rec[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] += f(r.get('RAW_ENT_WGT'))
    lt = {}
    for s in base.get('suppliers', []):
        lt.setdefault((s['plant'], s['code'], s['sup']), s['lt'])
        lt.setdefault(('*', s['sup']), s['lt'])
        lt[('code', s['plant'], s['code'])] = max(lt.get(('code', s['plant'], s['code']), 0), s['lt'])
    D = lambda s: dt.date(int(s[:4]), int(s[4:6]), int(s[6:8]))
    t0, tomorrow, out, stale = D(today.replace('-', '')), None, [], []
    tomorrow = (t0 + dt.timedelta(days=1)).isoformat()
    for r in A:
        sup, grp, od = str(r.get('RAW_SUP_CPY') or ''), str(r.get('RAW_GRP') or ''), str(r.get('RAW_ORD_DT') or '')
        if not od or od < start or sup == 'A1' or r.get('WRK_CLS') == 'D' or not grp:
            continue
        o = f(r.get('RAW_PUR_SEQ_ORD_WGT'))
        got = rec[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])]
        left = o - got
        # 입고가 시작된 발주의 10t 미만 잔량은 코일 1개(도금 소재 99%가 11.7t 이상)가 못 되는 발주·입고 중량 차이 → 마감으로 봄
        if left <= max(1000.0, 0.1 * o) or (got > 0 and left < 10000.0):
            continue
        plant = 'G' if grp in G_GROUPS else 'C'
        days = lt.get((plant, grp, sup)) or lt.get(('*', sup)) or lt.get(('code', plant, grp)) or 60
        eta = (D(od) + dt.timedelta(days=int(days))).isoformat()
        late = eta <= today
        if (t0 - dt.date.fromisoformat(eta)).days > STALE_DAYS:                       # 예정일 30일+ 지남 = 들어온다고 보기 어려움 → 충당에서 빼고 확인 목록으로(부족을 숨기지 않게)
            stale.append({'eta': eta, 'plant': 'G' if grp in G_GROUPS else 'C', 'code': grp, 't': round(left / 1000, 1), 'sup': sup, 'po': f"{r['RAW_PUR_NO']}-{r['RAW_PUR_SEQ']}",
                          'days': (t0 - dt.date.fromisoformat(eta)).days, 'note': f"{od[4:6]}/{od[6:]} 발주 + 리드타임 {days}일 → 예정 {eta[5:7]}/{eta[8:]}, {(t0 - dt.date.fromisoformat(eta)).days}일 지남"})
            continue
        out.append({'date': tomorrow if late else eta, 'plant': plant, 'code': grp, 't': round(left / 1000, 1), 'sup': sup, 'po': f"{r['RAW_PUR_NO']}-{r['RAW_PUR_SEQ']}",
                    'src': 'mes', 'note': f"MES 미입고 발주 · {od[4:6]}/{od[6:]} 발주 + 리드타임 {days}일" + (' · 예정일 지남(내일 입고로 봄)' if late else '')})
    stale.sort(key=lambda x: -x['t'])
    return out, {'n': len(out), 't': round(sum(x['t'] for x in out)), 'from': start if start != '00000000' else None, 'full': bool(S_),
                 'stale': stale, 'staleT': round(sum(x['t'] for x in stale)), 'staleDays': STALE_DAYS}


def procure(T, coils, today, base=None):
    base = base or load_base('procure_base.json')
    if not base:
        return None
    stock, note = procure_stock(T, coils, today)
    ps = load_base('planstock_base.json') or {}
    sm = max((str(r['_기준월']) for r in _rows(T, 'snap_stock')), default='202609')
    y, m = int(sm[:4]), int(sm[4:])
    snap_end = (dt.date(y + (m // 12), m % 12 + 1, 1) - dt.timedelta(days=1)).isoformat()
    arr = [{'date': a, 'plant': 'G', 'code': 'F', 't': t, 'sup': '수입 FH', 'note': f'{thk}×{wdt} {coat} ({o} 발주)'}            # 수입 FH 기발주(○월적, 기초재고 파일)
           for a, o, thk, wdt, coat, t in ps.get('fhOrdered', []) if a > snap_end]
    mo, minfo = open_orders(T, today, base)
    if mo:                                                       # MES 미입고 발주가 있으면 그것을 씀 — 수입 FH(V3)도 MES 발주에 있어 앞날 일정은 MES 로 대체(이중 계상 방지)
        arr = ([] if 'MES 입고' in note else [a for a in arr if a['date'] <= today]) + mo   # 재고에 MES 입고를 넣었으면 지난 수입 FH 도 이미 재고에 있음
    # 도금 FH 재고는 월말 재고 − 이후 사용(입고 자료 없음) → 월말 이후 들어온 수입 FH 기발주도 입고로 더함(날짜가 지났으면 이미 들어온 것)
    return dict(base, today=today, built=dt.datetime.now().isoformat(timespec='minutes'), stock=stock, stockNote=note, known=arr, knownInfo=minfo, supNames=sup_names(T))


FH_DUE_GRP = {'F': 'F/H(AZ·MAC용)', 'H': 'F/H(AL용)', 'N': 'AL-STS 임가공'}


def _ymd(v):
    v = str(v or '')
    return dt.date(int(v[:4]), int(v[4:6]), int(v[6:8])) if len(v) >= 8 and v[:2] == '20' else None


def fh_tf_due(od, sup):
    """TF 기준 납기(팀 소재 리드타임 표 2026-10-12): POSCO F/H = 매주 발주 +5주, 수입 FH(V 계열) = 발주 다음다음 달 7일경"""
    if str(sup).startswith('V'):
        y, m = od.year + (od.month + 1) // 12, (od.month + 1) % 12 + 1
        return dt.date(y, m, 7)
    return od + dt.timedelta(days=35)


def fh_due(T):
    """F/H 납기 비교(2026-10-21 사용자: TF 기준 납기 vs 인도납기일 기준 납기 — 종류·사양별로 어떤 게 얼마나 차이 나는지 한눈에).
    발주 행번마다 TF 납기(fh_tf_due) · MES 인도납기일(ORD_DLV_DT) · 실제 입고(입고 원장 실입고일, 원장에 없으면 입고 합계 첫·마지막 중간).
    종류 = POSCO F/H(AL용·AZ/MAC용) · 수입 FH, 사양 = 두께·폭 구간. 차이는 발주량(입고 비교는 입고량) 가중 중앙값, + = 늦음"""
    A = {(r['RAW_PUR_NO'], r['RAW_PUR_SEQ']): r for r in _rows(T, 'snap_raw_ask')}
    kind = lambda a: ('수입 FH' if str(a.get('RAW_SUP_CPY') or '').startswith('V') else FH_DUE_GRP.get(a.get('RAW_GRP')))
    ok = lambda a: a and a.get('RAW_GRP') in ('F', 'H') and (a.get('RAW_SUP_CPY') in ('P1', 'P2') or str(a.get('RAW_SUP_CPY') or '').startswith('V')) \
        and a.get('WRK_CLS') != 'D' and _ymd(a.get('ORD_DLV_DT')) and _ymd(a.get('RAW_ORD_DT'))
    tb = lambda t: '~0.39' if t < 0.40 else '0.40~0.59' if t < 0.60 else '0.60~0.79' if t < 0.80 else '0.80~1.19' if t < 1.20 else '1.20~'
    wb = lambda w: '~999' if w < 1000 else '1,000~1,219' if w < 1220 else '1,220~1,249' if w < 1250 else '1,250~'
    L, got = defaultdict(list), Counter()
    # 규격(10/22 사용자: SMATA1080 '규격' 칸별로) — 발주 표 소재규격코드, 없으면 입고 표(MO_ENT) 규격. 이름 = 코드표 PRC_ORD_SPEC_CD, 없으면 입고 표 규격약호
    # 묶음 = 규격 이름(CSP1-HA·CSP2-HA 등 — 코드는 달라도 이름이 같으면 한 줄, 10/22 사용자 'CSP1·CSP2 규격 구분'). 이름 = 입고 표 규격약호, 없으면 코드표
    SPN = {r['CD_VAL']: r['CD_NM'] for nm in ('snap_code_detail', 'snap_code_detail1', 'snap_code_detail2') for r in _rows(T, nm) if r.get('MASTER_CD') == 'PRC_ORD_SPEC_CD'}
    SPC = {}
    for r in _rows(T, 'snap_raw_ent_spec'):
        if r.get('RAW_SPEC_CD'):
            SPC[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] = r['RAW_SPEC_CD']
            if r.get('SPEC_NM'):
                SPN[r['RAW_SPEC_CD']] = r['SPEC_NM']
    for r in _rows(T, 'snap_raw_ask_spec'):
        if r.get('RAW_SPEC_CD'):
            SPC[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] = r['RAW_SPEC_CD']
    spec = lambda k: (lambda c: (SPN.get(c) or c) if c else None)(SPC.get(k))
    GS = defaultdict(lambda: {'tfd': [], 'dud': [], 'ard': [], 't': 0.0, 'n': 0})
    for e in _rows(T, 'snap_raw_ent'):
        k = (e['RAW_PUR_NO'], e['RAW_PUR_SEQ'])
        if not ok(A.get(k)) or e.get('REAL_ENT_YN') in ('N', 'S'):
            continue
        arr = _ymd(e.get('REAL_ENT_DT')) if e.get('REAL_ENT_YN') == 'Y' else _ymd(e.get('ENT_DT'))
        if arr:
            L[k].append((arr, f(e.get('RAW_ENT_WGT')) / 1000))
    for x in _rows(T, 'snap_raw_ent_sum'):
        k = (x['RAW_PUR_NO'], x['RAW_PUR_SEQ'])
        if not ok(A.get(k)):
            continue
        got[k] = f(x.get('ENT_WGT')) / 1000
        if k in L or f(x.get('PLAN_WGT')) > 0:
            continue
        a0, a1 = _ymd(x.get('FIRST_DT')), _ymd(x.get('LAST_DT'))
        if a0 and a1 and a1 >= a0:
            L[k] = [(a0 + (a1 - a0) / 2, f(x.get('ENT_WGT')) / 1000)]
    def wq(xs, q=0.5):
        xs = sorted(xs); tot = sum(w for _, w in xs); c = 0
        for d, w in xs:
            c += w
            if c >= tot * q:
                return d
        return None
    today = max((_ymd(r.get('REAL_ENT_DT')) or dt.date(2000, 1, 1)) for r in _rows(T, 'snap_raw_ent')) if _rows(T, 'snap_raw_ent') else dt.date.today()
    G, GG, opn, days = defaultdict(lambda: {'due': [], 'arrTf': [], 'arrDue': [], 'tfd': [], 'dud': [], 'ard': [], 't': 0.0, 'n': 0, 'open': 0.0}), {}, [], []
    for k, a in A.items():
        if not ok(a):
            continue
        od, due, sup = _ymd(a['RAW_ORD_DT']), _ymd(a['ORD_DLV_DT']), a.get('RAW_SUP_CPY')
        if od < dt.date(2026, 1, 1):
            continue
        tf, w = fh_tf_due(od, sup), f(a.get('RAW_PUR_SEQ_ORD_WGT')) / 1000
        key = (kind(a), tb(f(a.get('RAW_THK'))), wb(f(a.get('RAW_WDT'))))
        for kk in (key, (key[0], '', '')):
            g = G[kk]; g['n'] += 1; g['t'] += w; g['due'].append(((due - tf).days, w)); g['tfd'].append(((tf - od).days, w)); g['dud'].append(((due - od).days, w))
            for arr, aw in L.get(k, []):
                g['arrTf'].append(((arr - tf).days, aw)); g['arrDue'].append(((arr - due).days, aw)); g['ard'].append(((arr - od).days, aw))
        sp = spec(k)
        if sp:
            g = GS[(key[0], sp)]; g['n'] += 1; g['t'] += w; g['tfd'].append(((tf - od).days, w)); g['dud'].append(((due - od).days, w))
            g['ard'] += [((arr - od).days, aw) for arr, aw in L.get(k, [])]
        days.append(od)
        left = w - got.get(k, sum(aw for _, aw in L.get(k, [])))
        if left >= max(10.0, 0.1 * w) and abs((due - tf).days) >= 7 and max(tf, due) >= today - dt.timedelta(days=7):   # 아직 남은 발주(코일 1개 이상) 중 두 기준이 1주 넘게 다른 것
            G[(key[0], '', '')]['open'] += left
            opn.append({'po': f"{k[0]}-{k[1]}", 'kind': key[0], 'thk': f(a.get('RAW_THK')), 'wdt': f(a.get('RAW_WDT')), 'od': od.isoformat(), 'tf': tf.isoformat(),
                        'due': due.isoformat(), 'diff': (due - tf).days, 't': round(left, 1), 'sup': sup})
    if not days:
        return None
    def row(kk, g):
        mae = lambda xs: round(sum(abs(d) * w for d, w in xs) / max(1e-9, sum(w for _, w in xs)), 1) if xs else None
        return {'kind': kk[0], 'thk': kk[1], 'wdt': kk[2], 'n': g['n'], 't': round(g['t']), 'dueTf': wq(g['due']), 'dueTfQ1': wq(g['due'], .25), 'dueTfQ3': wq(g['due'], .75),
                'arrT': round(sum(w for _, w in g['arrTf'])), 'arrTf': wq(g['arrTf']), 'arrDue': wq(g['arrDue']), 'maeTf': mae(g['arrTf']), 'maeDue': mae(g['arrDue']),
                'openDiffT': round(g['open']), 'tfDays': wq(g['tfd']), 'dueDays': wq(g['dud']), 'arrDays': wq(g['ard'])}   # 발주 → TF 납기·인도납기·실제 입고 일수(중앙값)
    KO = ['F/H(AL용)', 'F/H(AZ·MAC용)', '수입 FH']
    rows = [row(kk, g) for kk, g in G.items() if kk[1] and g['t'] >= 100]
    rows.sort(key=lambda r: (KO.index(r['kind']) if r['kind'] in KO else 9, r['dueTf'] if r['dueTf'] is not None else 0))
    byKind = [row(kk, g) for kk, g in sorted(G.items(), key=lambda x: KO.index(x[0][0]) if x[0][0] in KO else 9) if not kk[1]]
    opn.sort(key=lambda x: (x['tf'], x['po']))
    return {'from': min(days).isoformat(), 'to': max(days).isoformat(), 'nPo': sum(g['n'] for kk, g in G.items() if not kk[1]),
            'basis': {'P': '발주 + 35일(매주 발주 +5주)', 'V': '발주 다음다음 달 7일경'}, 'byKind': byKind, 'rows': rows, 'open': opn[:300],
            'bySpec': sorted(({'kind': kk, 'spec': sp, 'n': g['n'], 't': round(g['t']), 'tfDays': wq(g['tfd']), 'dueDays': wq(g['dud']), 'arrDays': wq(g['ard'])}
                              for (kk, sp), g in GS.items() if g['t'] >= 50), key=lambda r: (KO.index(r['kind']) if r['kind'] in KO else 9, -r['t']))}


def due_track(T, hist, today):
    """발주 인도납기일(ORD_DLV_DT) 변경 이력 — 매일 MES 발주 자료를 지난 값과 비교해 바뀐 행번을 쌓음(사내 PC out_dir/due_hist.json, 2026-10-21 사용자 "변경 이력 매일 쌓아").
    hist = {'start', 'po': {행번: [인도납기, 처음 본 날]}, 'chg': [[바뀐 날, 행번, 이전, 이후, 업체, 소재, 두께, 폭]]} — 반환 (새 hist, 화면 요약)"""
    h = hist if isinstance(hist, dict) and 'po' in hist else {'start': today, 'po': {}, 'chg': []}
    po, chg = h['po'], h['chg']
    for r in _rows(T, 'snap_raw_ask'):
        due = str(r.get('ORD_DLV_DT') or '')
        if not due or r.get('WRK_CLS') == 'D':
            continue
        k = f"{r['RAW_PUR_NO']}-{r['RAW_PUR_SEQ']}"
        if k in po and po[k][0] != due:
            chg.append([today, k, po[k][0], due, r.get('RAW_SUP_CPY'), r.get('RAW_GRP'), f(r.get('RAW_THK')), f(r.get('RAW_WDT'))])
            po[k][0] = due
        elif k not in po:
            po[k] = [due, today]
    cut = (D(today) - dt.timedelta(days=400)).isoformat()
    h['chg'] = [c for c in chg if c[0] >= cut]
    sh = lambda c: (_ymd(c[3]) - _ymd(c[2])).days if _ymd(c[2]) and _ymd(c[3]) else None
    rec = [c for c in h['chg'] if c[0] >= (D(today) - dt.timedelta(days=60)).isoformat()]
    summ = {'start': h['start'], 'nPo': len(po), 'nChg': len(h['chg']),
            'recent': [{'d': c[0], 'po': c[1], 'from': c[2], 'to': c[3], 'shift': sh(c), 'sup': c[4], 'grp': FH_DUE_GRP.get(c[5], c[5]), 'thk': c[6], 'wdt': c[7]} for c in sorted(rec, key=lambda c: c[0], reverse=True)[:300]]}
    return h, summ


def split_order(short, elig, left):
    """부족량을 업체별로: 27년 배정 비중대로(배정 합 0 이면 균등) → 리드타임 > 남은 일수인 업체 몫은 맞추는 업체로 배정 비중대로 넘김. web/procure.js judge 와 같은 규칙"""
    if not elig:
        return []
    ws = sum(float(s.get('share') or 0) for s in elig)
    parts = [{'s': s, 't': short * ((float(s.get('share') or 0) / ws) if ws > 0 else 1 / len(elig)), 'late': s['lt'] > left, 'moved': 0.0} for s in elig]
    ok = [p for p in parts if not p['late']]
    late_t = sum(p['t'] for p in parts if p['late'])
    if late_t > 0 and ok:
        ow = sum(float(p['s'].get('share') or 0) for p in ok)
        for p in ok:
            p['moved'] = late_t * ((float(p['s'].get('share') or 0) / ow) if ow > 0 else 1 / len(ok))
            p['t'] += p['moved']
        for p in parts:
            if p['late']:
                p['from'], p['t'] = p['t'], 0.0
    return parts


def procure_summary(P, plant=None):
    """조달 판단 화면 기본값(여유 일수, 기발주 = MES 미입고 발주 자동, 업체 기준정보 초기값)으로 1순위 발주 시한·대체·기발주 확인 건수"""
    today = D(P['today'])
    lots = dict(P['stock'])
    inbound = sorted((a['date'], f"{a['plant']}:{a['code']}", a['t']) for a in P.get('known') or [])   # 필요일까지 들어오는 기발주는 충당에 씀
    sup = defaultdict(list)
    for s in P['suppliers']:
        sup[(s['plant'], s['code'])].append(s)
    mon = today - dt.timedelta(days=today.weekday())
    near, alt, chk, short4 = [], 0, 0, 0.0
    units = []
    for u in P['units']:                                          # 오늘 이전 날짜 소요는 뺌(재고가 이미 실적 사용을 뺀 값 — 화면 ui/proccalc.js 와 같음)
        if u.get('days'):
            keep = {d: t for d, t in u['days'].items() if d >= P['today']}
            kt = sum(keep.values())
            if kt < 0.5:
                continue
            u = dict(u, t=kt, first=min(keep))
        units.append(u)
    for u in sorted(units, key=lambda x: (x['first'], x['code'])):
        if plant and u['plant'] != plant:
            continue
        if (u['plant'], u['code']) in POSCO_SUPPLIED:
            continue
        need_by = D(u['first']) - dt.timedelta(days=SAFETY[u['plant']])
        left = (need_by - today).days
        while inbound and inbound[0][0] <= need_by.isoformat():
            _, kk, tt = inbound.pop(0)
            lots[kk] = lots.get(kk, 0.0) + tt
        k = f"{u['plant']}:{u['code']}"
        q = min(lots.get(k, 0.0), u['t'])
        lots[k] = lots.get(k, 0.0) - q
        short = u['t'] - q
        if short < 1:
            continue
        cand = sorted(sup.get((u['plant'], u['code']), []), key=lambda s: s['prio'])
        spec = lambda s: not u.get('thk') or not s.get('thk') or (u['thk'][0] >= s['thk'][0] - .005 and u['thk'][1] <= s['thk'][1] + .005)
        parts = split_order(short, [s for s in cand if spec(s)], left)          # 화면(procure.js)과 같은 나눔: 27년 배정 비중 → 늦는 업체 몫은 맞추는 업체로
        ok = [p for p in parts if not p['late'] and p['t'] >= 1]
        wk = (D(u['wk']) - mon).days // 7
        if 1 <= wk < 4:
            short4 += short
            if not ok and cand:
                chk += 1
            elif any(p['late'] and p.get('from', 0) >= 1 for p in parts):
                alt += 1
        for p in ok:
            dl = need_by - dt.timedelta(days=p['s']['lt'])
            if 0 <= (dl - today).days <= 14:
                near.append({'plant': u['plant'], 'mat': P['matCode'].get(u['code'], u['code']), 'first': u['first'], 'deadline': dl.isoformat(), 't': round(p['t']),
                             'sup': (P.get('supNames') or {}).get(p['s']['sup']) or p['s']['name']})
    near.sort(key=lambda x: x['deadline'])
    return {'near': len(near), 'nearTop': near[:6], 'nearAll': near[:40], 'alt': alt, 'check': chk, 'short4w': round(short4)}


# ------------------------------------------------------------------ 계획 정확도(전날 계획 vs 실적)
def coil_daily(coils):
    a = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy'):                                  # 더미 코일 제외(실적 분석·재계획과 같은 기준)
            a[(str(c['day']), c['line'])] += f(c['t'])
    return a


def plan_daily(R):
    a = defaultdict(float)
    for r in (R or {}).get('rows', []):
        a[(r[0], r[1])] += f(r[4])
    return a


def accuracy(hist, R_prev, coils, upto):
    """hist: [[날짜, 라인, 계획t, 실적t]] — R_prev(이번 실행 전 게시 계획)가 그날을 어떻게 잡았는지 vs 실적. 이미 있는 날은 덮지 않음"""
    pd_, ad = plan_daily(R_prev), coil_daily(coils)
    for h in hist:                                              # 실적은 MES 가 나중에 고치거나 늦게 들어오므로 최신 값으로 갱신
        if (h[0], h[1]) in ad:
            h[3] = round(ad[(h[0], h[1])], 1)
    have = {(h[0], h[1]) for h in hist}
    t0 = ((R_prev or {}).get('replan') or {}).get('t0') or ''
    days = sorted({d for (d, _) in ad if d > t0 and d <= upto})
    for d in days:
        for l in CGL:
            if (d, l) not in have and ((d, l) in pd_ or (d, l) in ad):
                hist.append([d, l, round(pd_.get((d, l), 0.0), 1), round(ad.get((d, l), 0.0), 1)])
    hist.sort()
    return hist


def accuracy_summary(hist, n=14):
    out = {}
    for l in CGL:
        h = [x for x in hist if x[1] == l][-n:]
        if not h:
            continue
        p, a = sum(x[2] for x in h), sum(x[3] for x in h)
        mape = sum(abs(x[3] - x[2]) for x in h) / max(1, p)
        out[l] = {'days': len(h), 'plan': round(p), 'actual': round(a), 'bias': round((a / p - 1) * 100, 1) if p else None,
                  'mae': round(mape * 100, 1), 'under': sum(1 for x in h if x[3] < x[2] * 0.95), 'last': h[-5:]}
    return out


# ------------------------------------------------------------------ 오늘 볼 것(예외)
def exceptions(today, ca, pr_sum, R2, acc, stock_rows, data_last):
    E = []
    add = lambda lvl, area, text, link, who: E.append({'lvl': lvl, 'area': area, 'text': text, 'link': link, 'who': who})
    # 자료
    if data_last and (D(today) - D(data_last)).days > 1:
        add('bad', '자료', f'실적 자료 갱신 중단: {data_last}({(D(today) - D(data_last)).days}일 전) — 사내 PC 자동 실행 확인 필요', 'health.html', '생산기획')
    # 도금: 최근 계획 대비 실적
    for l, x in (acc or {}).items():
        last = x['last'][-3:]
        fresh = data_last and last and (D(data_last) - D(last[-1][0])).days <= 1          # 최근 이틀이 실제 최신 실적일 때만(오래된 이력으로 경고하지 않음)
        if fresh and len(last) >= 2 and all(r[3] < r[2] * 0.9 for r in last[-2:]):
            add('warn', '도금', f"{l} 2일 연속 계획 대비 90% 미만 (최근 {', '.join(f'{r[0][5:]}: {r[3]:,.0f}/{r[2]:,.0f}t' for r in last[-2:])}) — 속도·강종 순서 확인 필요", 'integrated.html', '생산기획')
    if R2:
        t0 = (R2.get('replan') or {}).get('t0') or today
        lim = (D(t0) + dt.timedelta(days=3)).isoformat()
        tight = [r for r in R2['rows'] if t0 < r[0] <= lim and (D(r[5]) - D(r[0])).days <= 1]
        if sum(f(r[4]) for r in tight) >= 300:
            add('warn', '도금', f'향후 3일 내 납기 1일 이내 생산 물량 {sum(f(r[4]) for r in tight):,.0f}t ({len(tight)}건) — 정지·지연 시 즉시 납기 지연', 'status.html', '생산기획')
    # 컬러
    if ca:
        M = {x['line']: x for x in ca['month']['rows']}
        nb = min(12, max(0, len(ca['weekly']) - 1))                          # 비교 기준 주 수(자료가 짧으면 4주 미만 → 주간 비교 생략)
        for x in ca['lines']:
            d = (x['w1']['tpd'] / x['w0']['tpd'] - 1) * 100 if x['w0']['tpd'] and nb >= 4 else None
            m = M.get(x['line'])
            r = m['actual'] / m['sched'] * 100 if m and m.get('sched') else None
            if (d is not None and d <= -20) or (r is not None and r < 95):
                add('warn', '컬러', f"{x['line']} 지난주 {x['w1']['tpd']:,.0f}t/일" + (f'({nb}주 대비 {d:+.0f}%)' if d is not None else '') + (f', 이번 달 일정 대비 {r:.0f}%' if r is not None else '') + f" · 휴지 {x['w1']['stopH']:.1f}h/가동일", 'color_actual.html', '생산기획')
    # 소재
    if pr_sum:
        soon = [x for x in pr_sum.get('nearTop', []) if (D(x['deadline']) - D(today)).days <= 3]
        for x in soon[:3]:
            add('bad' if x['deadline'] <= today else 'warn', '소재', f"{x['mat']} {int(x['first'][5:7])}/{int(x['first'][8:10])} 소요분 중 {x['sup']} 몫 {x['t']:,}t, {int(x['deadline'][5:7])}/{int(x['deadline'][8:10])}까지 발주", 'procure.html', '구매')
        if pr_sum.get('check'):
            add('warn', '소재', f"2~4주 내 리드타임 이내 부족 {pr_sum['check']}건 — 기발주 여부 확인(입고예정 입력)", 'procure.html', '구매')
    # 재고
    for s in stock_rows or []:
        if s.get('target'):
            r = s['current'] / s['target']
            if r > 1.3 or r < 0.7:
                add('warn' if r < 1.6 else 'bad', '재고', f"{s['name']} {s['current']:,.0f}t — 목표 {s['target']:,.0f}t의 {r * 100:.0f}%", 'report.html', '판매·생산기획')
    order = {'bad': 0, 'warn': 1}
    E.sort(key=lambda e: order.get(e['lvl'], 2))
    return E


# ------------------------------------------------------------------ 자료 상태
def stock_daily(T):
    """실제 재고 일별 = 판매생산속보 원천 표(SMKT.OS_GC_COMPR_PROMPT_RPT_7·8·9)의 합계 칸(TOT_WGT) — 속보 재고 현황과 같은 값(10/13 5항목 모두 일치 확인).
    7: 소재(CLS G = F/H, CLS_1 1·2·3 / CLS C = 컬러용, CLS_1 4 자가재 제외) · 8: 도금 제품(CLS 1·2·3 판매재, 4 자가재) · 9: 컬러 제품(CLS 1 건재·3 수요개발·5 수출).
    이번 달 1일부터(월 단위) + 전월 말 하루(출발점). [[날짜, 항목, t]]"""
    R7, R8, R9 = _rows(T, 'stock_rpt7'), _rows(T, 'stock_rpt8'), _rows(T, 'stock_rpt9')
    G8, G9 = {'5': 'g:G국내', '6': 'g:G수출', '7': 'g:G자동차'}, {'1': 'g:C건재', '5': 'g:C수출'}
    if not (R7 or R8 or R9):
        return []
    acc = defaultdict(float)
    for r in R7:
        d, c, c1 = str(r['WRK_DT']), r.get('CLS'), str(r.get('CLS_1'))
        if c == 'G' and c1 in ('1', '2', '3'):
            acc[(d, '도금 소재(F/H)')] += f(r.get('TOT_WGT'))
        elif c == 'C' and c1 != '4':
            acc[(d, '컬러 소재')] += f(r.get('TOT_WGT'))
    for r in R8:
        d, c = str(r['WRK_DT']), str(r.get('CLS'))
        if c in ('1', '2', '3'):
            acc[(d, '도금 제품(판매재)')] += f(r.get('TOT_WGT'))
        elif c == '4':
            acc[(d, '도금 제품(자가재)')] += f(r.get('TOT_WGT'))
        if c in G8:                                                  # 재고 추이 그룹(부서별 행): 5 도금판매 · 6 도금수출 · 7 자동차강판
            acc[(d, G8[c])] += f(r.get('TOT_WGT'))
    for r in R9:
        c = str(r.get('CLS'))
        if c in ('1', '3', '5'):
            acc[(str(r['WRK_DT']), '컬러 제품')] += f(r.get('TOT_WGT'))
        if c in G9:                                                  # 1 컬러건재 · 5 컬러수출(가전·건재) — 3 수요개발은 그룹 없음
            acc[(str(r['WRK_DT']), G9[c])] += f(r.get('TOT_WGT'))
    last = max(d for d, _ in acc)
    m0 = last[:6] + '01'
    prev = max((d for d, _ in acc if d < m0), default=m0)                # 전월 말(출발점, 예: 9/30) — 재고 추이 '공장별 전체'가 전월 말부터
    return [[f'{d[:4]}-{d[4:6]}-{d[6:]}', k, round(v)] for (d, k), v in sorted(acc.items()) if d >= m0 or d == prev]


def ship_day(T, d0):
    """그룹별 하루 출하 실적(2026-10-20 회의: 가동 캘린더 그룹별 생산·출하·재고) — MES 출하(ship) 판매 출고(OUT_RSN_CD 1300), 부서 → 그룹. {d0, asOf, g: {그룹: {날짜: t}}}"""
    out, last = defaultdict(lambda: defaultdict(float)), None
    for r in _rows(T, 'ship'):
        g, d = SHIP_DEPT.get(r.get('DEPT')), str(r.get('OUT_DT') or '')[:10]
        if not g or str(r.get('OUT_RSN_CD')) != '1300' or d < d0:
            continue
        out[g][d] += f(r.get('WGT')) / 1000
        last = max(last or d, d)
    return {'d0': d0, 'asOf': last, 'g': {g: {d: round(v, 1) for d, v in sorted(x.items())} for g, x in out.items()}} if out else None


def mat_recv(T, d0):
    """구매 소재 입고 실적(2026-10-20 회의: 소재 캘린더 월별 계획·발주·입고) — MES 소재 입고(snap_raw_ent), 자사(A1, 도금 → 컬러 자가재) 빼고,
    실입고 N(아직 안 들어옴) 빼고. {'공장|소재그룹|날짜': t}"""
    out = defaultdict(float)
    for r in _rows(T, 'snap_raw_ent'):
        d = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or '')
        if len(d) != 8 or d < d0.replace('-', '') or str(r.get('RAW_SUP_CPY') or '') == 'A1' or r.get('REAL_ENT_YN') == 'N':
            continue
        out[f"{r.get('PLT_CLS')}|{r.get('RAW_GRP')}|{d[:4]}-{d[4:6]}-{d[6:]}"] += f(r.get('RAW_ENT_WGT')) / 1000
    return {k: round(v, 1) for k, v in sorted(out.items())}


ACT_PLANT = {'F': 'G', 'H': 'G', 'N': 'G', 'T': 'G'}       # 소재 그룹 → 공장(입고 원장 PLT_CLS 실측: F·H·N·T = 도금, 나머지 = 컬러)


def mat_act(T, d0):
    """소재 캘린더 지난 날 실적(2026-10-21 사용자: ~어제까지 MES 에 발주·입고가 다 나오는데 왜 비어 있나) — 날짜·공장·소재그룹·업체(발주번호 앞 2자리)별 t.
    발주 = snap_raw_ask 발주일(RAW_ORD_DT)·발주량, 입고 = snap_raw_ent 실입고일·입고량. 자사(A1, 도금 → 컬러 자가재) 제외. {'ord'|'inb': {'공장|그룹|업체|날짜': t}}"""
    out = {'ord': defaultdict(float), 'inb': defaultdict(float)}
    dd = d0.replace('-', '')
    ymd = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
    for r in _rows(T, 'snap_raw_ask'):
        d, sup = str(r.get('RAW_ORD_DT') or ''), str(r.get('RAW_SUP_CPY') or '')
        if len(d) != 8 or d < dd or sup == 'A1':
            continue
        grp = str(r.get('RAW_GRP') or '')
        pl = ACT_PLANT.get(grp) or 'C'
        out['ord'][f"{pl}|{grp}|{sup}|{ymd(d)}"] += f(r.get('RAW_PUR_SEQ_ORD_WGT')) / 1000
    for r in _rows(T, 'snap_raw_ent'):
        d, sup = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or ''), str(r.get('RAW_SUP_CPY') or '')
        if len(d) != 8 or d < dd or sup == 'A1' or r.get('REAL_ENT_YN') == 'N':
            continue
        out['inb'][f"{r.get('PLT_CLS')}|{r.get('RAW_GRP')}|{sup}|{ymd(d)}"] += f(r.get('RAW_ENT_WGT')) / 1000
    return {k: {kk: round(v, 1) for kk, v in sorted(x.items()) if v >= 0.05} for k, x in out.items()}


DEPT_GRP = {'도금판매그룹': '도금국내', '도금수출그룹': '도금수출', '자동차강판판매그룹': '자동차강판',
            '컬러수출그룹': '컬러수출', '컬러건재판매그룹': '컬러건재', '수요개발그룹': '수요개발'}


def mat_group(T, d0):
    """소재 입고·발주를 판매그룹으로(2026-10-20 사용자: 소재 캘린더 그룹 = 판매그룹, 컬러는 더 나눠서) — 소재 발주(snap_raw_ask) 계약·행번 →
    판매 부서 + 주문 용도·사양(snap_raw_ask_dept, 없으면 hist_cc_con_dept·hist_cg_con_dept 부서만).
    도금: 도금수출·도금국내·자동차강판, 컬러 부서 계약이면 자가재. 컬러: color_grouper 와 같은 6개 —
    건재판매 → 컬러건재(소재 발주엔 색이 없어 계획재·주문재 구분 안 함), 수요개발, 컬러수출 → 용도 CC* 건재수출 / 수출 계약(con_export) 가전수출 / 가전내수.
    {'recv': {'공장|그룹|날짜': t}, 'po': {'발주번호-행번': 그룹}}"""
    det, nm, code_nm = {}, {}, {}
    clr = {}                                                      # 계약 하나에 행이 여러 개(소재·도장) — 소재 발주는 색상 빈 소재 행에 걸림 → 같은 계약 도장 행의 색·두께·폭
    for r in _rows(T, 'snap_raw_ask_dept'):
        det[(r['CON_NO'], str(r.get('CON_SEQ')))] = r
        if r.get('CLR_SER_NO_TOP'):
            clr.setdefault(r['CON_NO'], r)
        if r.get('DEPART_NM'):
            nm[r['CON_NO']] = r['DEPART_NM']; code_nm[str(r.get('DEPART_CD'))] = r['DEPART_NM']
    for n in ('hist_cc_con_dept_a', 'hist_cc_con_dept_b'):
        for r in _rows(T, n):
            if r.get('DEPART_NM'):
                nm.setdefault(r['CON_NO'], r['DEPART_NM']); code_nm.setdefault(str(r.get('DEPART_CD')), r['DEPART_NM'])
    for r in _rows(T, 'hist_cg_con_dept'):
        if code_nm.get(str(r.get('DEPART_CD'))):
            nm.setdefault(r['CON_NO'], code_nm[str(r.get('DEPART_CD'))])
    dom = con_dom_map(T)

    def grp(plant, con, seq):
        dept = nm.get(con) or ''
        g = DEPT_GRP.get(dept)
        if not g:
            return '미상(계약 부서 없음)'
        if plant == 'G':
            return '자가재' if g in ('컬러수출', '컬러건재', '수요개발') else g
        d = det.get((con, str(seq)))
        if d and not d.get('CLR_SER_NO_TOP') and clr.get(con):
            d = dict(d, CLR_SER_NO_TOP=clr[con]['CLR_SER_NO_TOP'], ORD_CTV_THK=clr[con].get('ORD_CTV_THK') or d.get('ORD_CTV_THK'),
                     ORD_CTV_WDT=clr[con].get('ORD_CTV_WDT') or d.get('ORD_CTV_WDT'), ORD_USG_CD=d.get('ORD_USG_CD') or clr[con].get('ORD_USG_CD'))
        if g == '컬러건재':                                       # 소재 발주엔 색이 거의 없어(10/20: 669건 중 21건) 계획재·주문재를 못 나눔 → 한 줄
            return '컬러건재'
        if g == '컬러수출':
            if d and str(d.get('ORD_USG_CD') or '').startswith('CC'):
                return '건재수출'
            if not d:
                return '컬러수출(세부 대기)'
            return '가전수출' if con_export(con, d.get('DOM_CLS') or dom.get(str(con))) else '가전내수'
        return g if g in ('수요개발',) else g
    ask = {(r['RAW_PUR_NO'], str(r['RAW_PUR_SEQ'])): r for r in _rows(T, 'snap_raw_ask')}
    po = {f"{k[0]}-{k[1]}": grp('G' if str(r.get('RAW_GRP')) in ('F', 'H', 'T', 'N', 'Y') else 'C', r.get('CON_NO'), r.get('CON_SEQ')) for k, r in ask.items()}
    recv = defaultdict(float)
    for r in _rows(T, 'snap_raw_ent'):
        d = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or '')
        if len(d) != 8 or d < d0.replace('-', '') or str(r.get('RAW_SUP_CPY') or '') == 'A1' or r.get('REAL_ENT_YN') == 'N':
            continue
        if r.get('PLT_CLS') == 'G' and str(r.get('RAW_GRP')) == 'N':     # 도금용 SUS — 소재 그룹별 보기(matRecv 화면)와 같게 뺌(계획 대상 아님)
            continue
        a = ask.get((r.get('RAW_PUR_NO'), str(r.get('RAW_PUR_SEQ'))))
        g = grp(r.get('PLT_CLS'), a.get('CON_NO'), a.get('CON_SEQ')) if a else '미상(발주 없음)'
        recv[f"{r.get('PLT_CLS')}|{g}|{d[:4]}-{d[4:6]}-{d[6:]}"] += f(r.get('RAW_ENT_WGT')) / 1000
    return {'recv': {k: round(v, 1) for k, v in sorted(recv.items())}, 'po': po}


def stock_roll(T, R2, pb):
    """재고 추이를 매일 다시 굴림(2026-10-14 사용자: 가동 계획처럼 재고 추이도 매일 롤링):
    출발 = 어제 말 실제 재고(판매생산속보 원천 표, 그룹별) → 이후 날마다 + 생산(도금 = 오늘 아침 재계획, 컬러 = 확정 통합 계획) − 판매(확정 통합 계획의 하루 출고)
    → 주말(일요일)·12/31 값. 지난 주말은 실제 값"""
    rb = (pb or {}).get('stockRollBase') or {}
    out, weeks = rb.get('outDay'), rb.get('weeks')
    if not out or not weeks:
        return None
    act = defaultdict(dict)
    for d, k, t in stock_daily(T):
        if k.startswith('g:'):
            act[k[2:]][d] = t
    if not act:
        return None
    last = min(max(v) for v in act.values())
    d0 = D(rb.get('d0') or '2026-10-01')
    prod = defaultdict(float)
    for r in (R2 or {}).get('rows', []):
        if r[0] > last and PLAN_GROUP.get(r[3]):
            prod[(r[0], PLAN_GROUP[r[3]])] += f(r[4])
    for k, t in (pb.get('groupPlanDaily') or {}).items():
        d, g = k.split('|', 1)
        if d > last and g.startswith('C'):
            prod[(d, g)] += f(t)
    # 이번 달 남은 출고 = 속보 월차 − 실적(그룹별) — 계획 출고를 날마다 그대로 빼면 출하가 밀리거나 앞선 만큼이 틀림(10/21: 자동차는 일정의 122% 출하했는데 월말 −1.3천t 로 나옴).
    # 날짜별 모양(MES 월중 출하 분포)은 그대로 두고 크기만 맞춤. 다음 달부터는 계획 출고 그대로
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else {}
    shp = {x['name']: x for x in SR.get('ship', [])}
    nm_last = (D(last) + dt.timedelta(days=1)).isoformat()[:7]
    res, days, outA = {}, {}, {}
    for g, o in out.items():
        if last not in act.get(g, {}):
            continue
        o2 = plan_out(g, [f(v) for v in o], d0, last, shp.get(SHIP_NAME.get(g)))
        outA[g] = [round(v, 1) for v in o2]
        s, ser = act[g][last], {}
        for i, ot in enumerate(o2):
            d = (d0 + dt.timedelta(days=i)).isoformat()
            if d <= last:
                ser[d] = act[g].get(d)
                continue
            s += prod[(d, g)] - ot
            ser[d] = round(s)
        res[g] = [ser.get(w) for w in weeks]
        days[g] = [ser.get((d0 + dt.timedelta(days=i)).isoformat()) for i in range(len(o))]   # 가동 캘린더 제품 재고 줄(일별, 지난 날 = 실제)
    return {'asOf': last, 'weeks': weeks, 'v': res, 'd0': d0.isoformat(), 'days': days, 'out': outA}


SPREAD = ('G국내', 'G자동차', 'C건재', 'C수출', 'C수요')     # 국내·컬러 출고는 날마다 나감 — 판매계획 납기(월말)에 한꺼번에 몰아 두면 월말 하루 수천 t 로 보임(10/21 사용자 지적)


def plan_out(g, o, d0, last, sr):
    """그룹 g 의 날짜별 계획 출고(o, d0 부터) 다듬기 — 재고 추이·가동 캘린더 출하 줄이 같은 값을 씀.
    · 이번 달 남은 날: 합 = 속보 월차 − 실적(그룹별). 국내·컬러는 남은 날에 고르게, 도금수출은 선적창 모양(계획 출고 비례) 유지
    · 다음 달부터: 국내·컬러는 그 달 합을 날마다 고르게, 도금수출은 계획 출고 그대로"""
    n = len(o)
    ds = [(d0 + dt.timedelta(days=i)).isoformat() for i in range(n)]
    o = list(o)
    months = sorted({d[:7] for d in ds})
    for m in months:
        idx = [i for i in range(n) if ds[i][:7] == m and ds[i] > last]
        if not idx:
            continue
        tot = sum(o[i] for i in idx)
        if m == last[:7] and sr and sr.get('month'):
            want = max(0.0, sr['month'] - sr['actual'])
        else:
            want = tot
        if g in SPREAD or tot <= 0:
            for i in idx:
                o[i] = want / len(idx)
        else:
            k = want / tot
            for i in idx:
                o[i] *= k
    return o



def status(T, coils, auto, pages, run_at):
    def last_of(name, key):
        rs = T.get(name)
        if not rs:
            return None
        i = rs['columns'].index(key) if key in rs['columns'] else None
        v = [str(r[i])[:10] for r in rs['rows'] if i is not None and r[i]]
        return max(v) if v else None
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    feeds = [
        {'name': '도금 생산 실적(코일)', 'last': max((str(c['day']) for c in coils), default=None), 'n': len(coils or [])},
        {'name': '컬러 생산 실적', 'last': last_of('color_prod', 'PRD_DT'), 'n': len((T.get('color_prod') or {}).get('rows', []))},
        {'name': '판매생산속보(진도·재고)', 'last': (SR or {}).get('asOf', '')[:10] or None},
        {'name': '출하', 'last': last_of('ship', 'OUT_DT')},
        {'name': '소재재고List(컬러)', 'last': last_of('snap_mat_stock_cc', '입고일')},
        {'name': '실제 재고(속보 원천 표)', 'last': (lambda v: f'{v[:4]}-{v[4:6]}-{v[6:8]}' if v else None)(max((str(r.get('WRK_DT')) for r in _rows(T, 'stock_rpt9')), default=None))},
        {'name': '재고현황(월말)', 'last': (lambda m: f'{m[:4]}-{m[4:]}' if m else None)(max((str(r[0]) for r in (T.get('snap_stock') or {}).get('rows', [])), default=None))},
    ]
    return {'app': 'cgl-status', 'runAt': run_at, 'ok': True, 'auto': {k: auto.get(k) for k in ('actualTo', 'replanned', 'optimal', 'notes', 'newCoils')} if auto else None,
            'feeds': feeds, 'pages': pages}


# ------------------------------------------------------------------ 전체
def groups(T, coils, SR, gpd, g_last, R2=None):
    """마케팅 그룹별 이번 달 생산(월 계획·실적)과 출하(판매생산속보 월차·일정누계·실적).
    날짜까지의 계획 누계는 넣지 않음 — 계획 모델은 마감일만 지키면 부서를 어느 날 만들지 임의라 그룹별 일자 비교는 의미가 없음.
    대신 after = 실적 다음 날부터 이달 말까지 남은 계획(도금 = 최신 재계획 R2, 없으면 확정 계획 / 컬러 = 편성) → 월말 예상 = 실적 + after
    생산 실적: 도금 = MES 코일(더미 제외) 판매그룹, 컬러 = MES 컬러 생산 DEPT. 계획: 도금 = 확정 V1 일별, 컬러 = 통합 계획 편성"""
    cp = T.get('color_prod')
    c_last = max((r[cp['columns'].index('PRD_DT')] for r in cp['rows']), default=None) if cp and cp['rows'] else None
    act = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy') and g_last and str(c['day'])[:7] == g_last[:7] and str(c['day']) <= g_last:
            g = COIL_GROUP.get(c.get('dept'))
            if g:
                act[g] += f(c['t'])
    if cp and c_last:
        I = cp['columns'].index
        if 'DEPT' in cp['columns']:
            for r in cp['rows']:
                g = CPROD_GROUP.get(r[I('DEPT')])
                if g and r[I('PRD_DT')][:7] == c_last[:7] and r[I('PRD_DT')] <= c_last:
                    act[g] += f(r[I('PDT_WGT')]) / 1000
    ship = {SHIP_GROUP[x['name']]: x for x in (SR or {}).get('ship', []) if x['name'] in SHIP_GROUP}
    out = []
    for key, name, pl in GROUPS:
        last = g_last if pl == 'G' else c_last
        if not last:
            continue
        m = last[:7]
        mon = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m)
        if pl == 'G' and R2 and R2.get('rows'):
            after = sum(f(r[4]) for r in R2['rows'] if last < r[0] and r[0][:7] == m and PLAN_GROUP.get(r[3]) == key)
            src = '재계획'
        else:
            after = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m and k[:10] > last)
            src = '확정 계획' if pl == 'G' else '편성'
        sh = ship.get(key)
        if not mon and not act[key] and not sh:
            continue
        out.append({'key': key, 'name': name, 'pl': pl, 'prod': {'asOf': last, 'month': round(mon), 'actual': round(act[key]), 'after': round(after), 'afterSrc': src},
                    'ship': {'asOf': (SR or {}).get('asOf'), 'month': round(sh['month']), 'sched': round(sh['sched']), 'actual': round(sh['actual'])} if sh else None})
    return out


def lines_now(T, coils, SR, R2, g_last):
    """라인 타일: 판매생산속보 월차·일정누계·실적누계(공식) + 이번 달 일 생산(MES) + 도금 현재 강종·다음 전환(최신 계획)"""
    prod = {x['line']: x for x in (SR or {}).get('prod', []) if x['line'] in ('1CGL', '2CGL') + tuple(CCL)}
    day, fam = defaultdict(float), defaultdict(lambda: defaultdict(float))
    for c in coils or []:
        if not c.get('dummy'):
            day[(str(c['day']), c['line'])] += f(c['t'])
            if str(c['day']) == g_last:
                fam[c['line']][c.get('fam')] += f(c['t'])
    cp = T.get('color_prod')
    c_last = None
    if cp and cp['rows']:
        I = cp['columns'].index
        c_last = max(r[I('PRD_DT')] for r in cp['rows'])
        for r in cp['rows']:
            day[(r[I('PRD_DT')], r[I('LINE')])] += f(r[I('PDT_WGT')]) / 1000
    nxt = {}
    for c in sorted((R2 or {}).get('cal', []), key=lambda c: c['date']):
        ev = str(c.get('event') or '')
        if g_last and c['date'] > g_last and c['line'] not in nxt and ('M/C' in ev or 'S/D' in ev or '정기' in ev):
            nxt[c['line']] = [c['date'], ev.split(' · ')[0]]
    out = []
    for l in ('1CGL', '2CGL') + tuple(CCL):
        last = g_last if l.endswith('CGL') else c_last
        if not last:
            continue
        ds = [(D(last) - dt.timedelta(days=i)).isoformat() for i in range(D(last).day - 1, -1, -1)]   # 이번 달 1일 ~ 마지막 날(월차와 같은 기간, 2026-10-14 사용자: 무조건 월 단위로 시작)
        x = prod.get(l) or {}
        fm = fam.get(l)
        out.append({'line': l, 'pl': 'G' if l.endswith('CGL') else 'C', 'asOf': last, 'month': x.get('month'), 'sched': x.get('sched'), 'actual': x.get('actual'),
                    'tph': x.get('tph'), 'days': [[d, round(day[(d, l)])] for d in ds],
                    'fam': max(fm, key=fm.get) if fm else None, 'next': nxt.get(l)})
    return out


WO_LINE_G = {'A': '1CGL', 'B': '2CGL'}
WO_LINE_C = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}


def work_orders(T, coils, R2, g_last, today=None):
    """MES 작업지시 vs 최신 계획.
    도금(SSCH.PF_CG_WORK_FIN): 미완료 지시 코일의 강종 = 생산번호 셋째 글자(지난 코일 기록에서 글자→강종을 매일 다시 뽑음),
      톤 = 최근 코일 평균 무게로 추정. 계획의 향후 3일 강종에 없는 강종이 대기 중이면 '불일치'.
    컬러(SSCH.PF_CC_WORK_ORD): 라인별 앞으로 7일 작업 예정 톤(지시 예정 중량, kg)과 확정 비율"""
    out = {}
    wg = _rows(T, 'snap_wo_cg')
    if wg and coils:
        key = defaultdict(Counter)
        wt = defaultdict(list)
        for c in coils:
            p_ = str(c.get('prd') or '')
            if len(p_) >= 3 and c.get('alloy'):
                key[p_[2]][c['alloy']] += 1
            if not c.get('dummy') and c.get('alloy'):
                wt[(c['line'], c['alloy'])].append(f(c['t']))
        k2a = {k: v.most_common(1)[0][0] for k, v in key.items()}
        fam_of = lambda a: 'AL' if a in ('AL', 'AL-STS', 'AL-LG') else a
        cal = {(c['date'], c['line']): c.get('fam') for c in (R2 or {}).get('cal', [])}
        lines = []
        for code, l in WO_LINE_G.items():
            pend = [w for w in wg if w['LINE_CLS'] == code and w['FIN_YN'] != 'Y']
            q = Counter()
            for w in pend:
                q[k2a.get(str(w['PRD_NO'] or '')[2:3], '?')] += 1
            tons = {a: round(n * (sum(wt[(l, a)][-200:]) / len(wt[(l, a)][-200:]) if wt[(l, a)] else 0)) for a, n in q.items()}
            nxt = [(D(g_last) + dt.timedelta(days=i)).isoformat() for i in (1, 2, 3)] if g_last else []
            plan = [[d, cal.get((d, l))] for d in nxt]
            pf = {x[1] for x in plan if x[1]}
            bad = sorted({fam_of(a) for a in q if a != '?' and fam_of(a) not in pf}) if pf else []
            ds = sorted({w['WRK_DRT_DT'] for w in pend})
            lines.append({'line': l, 'coils': len(pend), 'byAlloy': [[a, n, tons.get(a, 0)] for a, n in q.most_common()],
                          'issued': [ds[0], ds[-1]] if ds else None, 'plan': plan, 'mismatch': bad})
        out['plating'] = {'asOf': max((w['WRK_DRT_DT'] for w in wg), default=None), 'lines': lines, 'keyMap': k2a}
    wc = _rows(T, 'snap_wo_cc')
    if wc:
        base = max(str(w['WRK_DRT_DT']) for w in wc)
        d0 = D(f'{base[:4]}-{base[4:6]}-{base[6:]}')
        days = [(d0 + dt.timedelta(days=i)).strftime('%Y%m%d') for i in range(7)]
        lines = []
        for code, l in WO_LINE_C.items():
            rows = [w for w in wc if w['WRK_DRT_LINE'] == code]
            by = [round(sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows if str(w['WRK_SCHE_DT']) == d) / 1000) for d in days]
            conf = sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows if w['WRK_DRT_CONF'] == 'Y'); tot = sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows)
            last = max((str(w['WRK_SCHE_DT']) for w in rows if w['WRK_SCHE_DT']), default=None)
            lines.append({'line': l, 'days': by, 'confRate': round(conf / tot, 2) if tot else None, 'until': f'{last[:4]}-{last[4:6]}-{last[6:]}' if last else None})
        out['color'] = {'days': [f'{d[:4]}-{d[4:6]}-{d[6:]}' for d in days], 'lines': lines, 'downConflicts': wo_down_conflicts(T, wc, today or base[:4] + '-' + base[4:6] + '-' + base[6:])}
    return out or None


def wo_down_conflicts(T, wc, today, min_t=50):
    """오늘 이후 컬러 휴지계획(수리·S/D·계획휴지, 하루 종일 — 반나절 정지는 남은 시간에 생산 가능)과 겹치는 날에 예정된 작업지시(라인·휴지 구분별).
    이미 생산이 시작된 지시(컬러 실적에 같은 주문 번호)는 남은 양의 예정일이 옛 값일 수 있어 뺌 — 실제 생산일과 예정일은 65%가 ±1일(2026-10-12 확인)"""
    started = {(r['CON_NO'], r['CON_SEQ']) for r in _rows(T, 'color_prod') or []}
    KN = {'plan': '계획휴지', 'sd': 'S/D', 'repair': '수리'}
    down = {(it['line'], it['date']): KN[it['kind']] for it in (load_base('color_downtime.json') or {}).get('items', [])
            if it['kind'] in KN and f(it['min']) >= 1440 and it['date'] >= today}
    tons = defaultdict(lambda: defaultdict(float))
    for w in wc:
        d, l = str(w.get('WRK_SCHE_DT') or ''), WO_LINE_C.get(w['WRK_DRT_LINE'])
        if len(d) == 8 and (w.get('CON_NO'), w.get('CON_SEQ')) not in started:
            iso = f'{d[:4]}-{d[4:6]}-{d[6:]}'
            if (l, iso) in down:
                tons[(l, down[(l, iso)])][iso] += f(w.get('WRK_DRT_SCHE_WGT')) / 1000
    ok = (load_base('confirmations.json') or {}).get('downConflict', [])
    conf = lambda l, k, ds: next((c for c in ok if c['line'] == l and c['kind'] == k and c['from'] <= ds[0] and ds[-1] <= c['to']), None)   # 현장 확인 끝난 휴지(같은 기간 안)
    out = []
    for (l, k), v in sorted(tons.items()):
        if sum(v.values()) >= min_t:
            c = conf(l, k, sorted(v))
            out.append({'line': l, 'kind': k, 'dates': sorted(v), 't': round(sum(v.values())), 'confirmed': {'at': c['at'], 'note': c['note']} if c else None})
    return out



def week_events(today, R2, pr_all, ps, days=14):
    """홈 '2주 일정': 오늘부터 14일 — 도금 M/C·정기수리·추가정지(최신 계획), 컬러 S/D·수리·계획휴지(휴지계획),
    소재 발주 마감(소재 발주 기본값), 계획재 소재 발주 마감(계획재 캘린더). [{d, kind, text, pl}]"""
    t0 = D(today)
    t1 = (t0 + dt.timedelta(days=days - 1)).isoformat()
    ev = []
    for c in (R2 or {}).get('cal', []) or []:
        e = str(c.get('event') or '')
        if today <= c['date'] <= t1 and (e or c.get('blackout')):
            ev.append({'d': c['date'], 'kind': 'plating', 'pl': 'G', 'text': f"{c['line']} {'정기수리' if c.get('blackout') else e}"})
    dn = load_base('color_downtime.json') or {}
    KN = {'plan': '계획휴지', 'sd': 'S/D', 'repair': '수리'}
    ok = (load_base('confirmations.json') or {}).get('downConflict', [])
    for it in dn.get('items', []):
        if today <= it['date'] <= t1 and it['kind'] in KN:
            cf = any(c['line'] == it['line'] and c['kind'] == KN[it['kind']] and c['from'] <= it['date'] <= c['to'] for c in ok)   # 현장 확인 끝난 휴지
            ev.append({'d': it['date'], 'kind': 'color', 'pl': 'C', 'text': f"{it['line']} {KN[it['kind']]} {round(it['min'] / 60, 1):g}h" + (' · 확인됨' if cf else '')})
    for x in (pr_all or {}).get('nearAll', []):
        if today <= x['deadline'] <= t1:
            ev.append({'d': x['deadline'], 'kind': 'order', 'pl': x['plant'], 'text': f"{x['mat']} {x['t']:,}t 발주"})
    for o in (ps or {}).get('orders', []):
        if today <= o['o1'] <= t1 and o['t'] - o.get('ordered', 0) >= 1:
            ev.append({'d': o['o1'], 'kind': 'plan', 'pl': 'C', 'text': f"계획재 {o['kind']} {round(o['t'] - o.get('ordered', 0)):,}t 발주"})
    seen, out = set(), []
    for e in sorted(ev, key=lambda z: (z['d'], z['kind'])):
        k = (e['d'], e['text'])
        if k not in seen:
            seen.add(k); out.append(e)
    return {'from': today, 'days': days, 'events': out}

def build_all(T, coils, R_prev, R2, auto=None, hist=None, today=None, run_at=None, stops=None, duehist=None):
    run_at = run_at or dt.datetime.now(dt.timezone.utc).isoformat(timespec='minutes')
    today = today or U.prod_today()                              # 생산일(07시 기준)
    ca = color_actual(T)
    ga = plating_actual(T, coils, stops)
    pr = procure(T, coils, today)
    due_h = None
    if pr:                                                     # POSCO F/H 인도납기 대비 입고(사양별) · 인도납기 변경 이력(매일 쌓음) — 소재 발주 화면 탭
        try:
            pr['fhDue'] = fh_due(T)
            due_h, pr['dueTrack'] = due_track(T, duehist, today)
        except Exception as e:
            pr['fhDueErr'] = str(e)[:200]
    pb = load_base('portal_base.json') or {}
    data_last = max((str(c['day']) for c in coils), default=None) if coils else (ca or {}).get('asOf')
    hist = accuracy(list(hist or pb.get('accHist', [])), R_prev, coils, data_last or today)
    acc = accuracy_summary(hist)
    if ga is not None and isinstance(ga, dict):                 # 도금 가동 현황 '계획 대비 실적' = 날마다 그날 아침 계획 vs 실적(최근 3주, 사용자 10/21)
        cut = (D(data_last or today) - dt.timedelta(days=21)).isoformat()
        ga['accHist'] = [h for h in hist if h[0] >= cut]
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    pr_all = procure_summary(pr) if pr else None
    portal = dict(pb.get('static', {}))
    portal.update({'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': data_last, 'today': today,
                   'procure': pr_all, 'procureBy': {'G': procure_summary(pr, 'G'), 'C': procure_summary(pr, 'C')} if pr else None,
                   'acc': acc, 'exceptions': exceptions(today, ca, pr_all, R2, acc, (SR or {}).get('stock'), data_last),
                   'colorNow': {'month': ca['month'], 'w1': ca['w1'], 'tpd': [round(x['w1']['tpd']) for x in ca['lines']], 'tpd0': [round(x['w0']['tpd']) for x in ca['lines']]} if ca else None})
    if R2:                                                     # 최신 계획 기준 빠듯함·계획 대비 실적
        t0 = (R2.get('replan') or {}).get('t0') or data_last or today
        tight = [r for r in R2['rows'] if r[0] > t0 and (D(r[5]) - D(r[0])).days <= 2]
        pl = portal.setdefault('plating', {})
        pl.update({'tightN': len(tight), 'tightT': round(sum(f(r[4]) for r in tight)), 'slack': {k: round(v) for k, v in (R2.get('slack') or {}).items()}})
        rp = R2.get('replan') or {}
        due_late = sum(f(r[4]) * (D(r[0]) - D(r[5])).days for r in R2['rows'] if r[0] > t0 and r[0] > r[5])   # 원래 납기 기준(재계획 지연 값엔 자가재 반순 가중분이 섞임)
        pl['now'] = {'t0': rp.get('t0'), 'short': round(f((R2.get('milp') or {}).get('short'))), 'late': round(due_late),
                     'shortBy': (rp.get('shortBy') or [])[:5], 'lockNotes': rp.get('lockNotes') or [], 'proposal': rp.get('proposal')}
    base_plan = pb.get('basePlanDaily') or {}                  # 확정 계획(V1) 일별 — 계획 대비 실적 누계
    if base_plan and coils:
        ad = coil_daily(coils)
        q0 = pb.get('q0', '2026-10-01')
        act = sum(v for (d, l), v in ad.items() if q0 <= d <= data_last)
        pln = sum(v for k, v in base_plan.items() if q0 <= k.split('|')[0] <= data_last)
        portal['roll'] = {'asOf': data_last, 'actual': round(act), 'plan': round(pln)}
    portal['lines'] = lines_now(T, coils, SR, R2, data_last if coils else None)
    portal["wo"] = work_orders(T, coils, R2, data_last if coils else None, today)
    for x in ((portal['wo'] or {}).get('plating') or {}).get('lines', []):
        if x['mismatch']:
            portal['exceptions'].insert(0, {'lvl': 'warn', 'area': '도금', 'text': f"{x['line']} 현장 작업지시에 {'·'.join(x['mismatch'])} 대기 — 계획의 향후 3일 강종({'·'.join(sorted({p[1] for p in x['plan'] if p[1]}))})과 다름. 강종 순서·M/C 날짜 확인", 'link': 'status.html', 'who': '생산기획'})
    for x in [x for x in ((portal['wo'] or {}).get('color') or {}).get('downConflicts', []) if not x.get('confirmed')]:
        md = lambda s: f'{int(s[5:7])}/{int(s[8:])}'
        rng = md(x['dates'][0]) + (f"~{md(x['dates'][-1])}" if len(x['dates']) > 1 else '')
        portal['exceptions'].insert(0, {'lvl': 'warn', 'area': '컬러', 'text': f"{x['line']} {rng} {x['kind']} 계획인데 현장 작업지시 {x['t']:,}t가 이 날짜로 예정 — {x['kind']} 일정 또는 작업 예정일 확인", 'link': 'color_status.html', 'who': '생산기획'})
    if R2 and R2.get('rows'):                                # 월별 도금 계획 = 최신 계획(지난 날은 실적 + 앞으로는 재계획), 라인별
        ms_ = portal.get('months') or sorted({r[0][:7] for r in R2['rows']})
        portal['planMonth'] = {'src': '최신 재계획 ' + str((R2.get('replan') or {}).get('t0') or ''), 'months': ms_,
                               'g1': [round(sum(f(r[4]) for r in R2['rows'] if r[1] == '1CGL' and r[0][:7] == m)) for m in ms_],
                               'g2': [round(sum(f(r[4]) for r in R2['rows'] if r[1] == '2CGL' and r[0][:7] == m)) for m in ms_]}
    portal['sr'] = {'asOf': SR['asOf'], 'ship': SR['ship'], 'stock': [{k: x[k] for k in ('name', 'target', 'current')} for x in SR['stock']]} if SR else None
    portal['stockTrend'] = stock_daily(T)
    portal['stockRoll'] = stock_roll(T, R2, load_base('portal_base.json'))
    q0_ = (load_base('portal_base.json') or {}).get('q0', '2026-10-01')
    portal['shipDay'] = ship_day(T, q0_)
    portal['matRecv'] = mat_recv(T, q0_)
    portal['matGrp'] = mat_group(T, q0_)
    portal['matAct'] = mat_act(T, q0_)
    if pb.get('groupPlanDaily'):
        portal['groups'] = groups(T, coils, SR, pb['groupPlanDaily'], data_last if coils else None, R2)
        portal['colorPlanFrom'] = pb.get('colorPlanFrom')
    try:
        from . import planstock as PS
        ps = PS.build(T, today)
        if ps:
            ps['built'] = dt.datetime.now().isoformat(timespec='minutes')
            nf = ps['flags'].get('short', 0) + ps['flags'].get('low', 0)
            if nf:
                portal['exceptions'].append({'lvl': 'warn', 'area': '컬러', 'text': f"계획재 {nf}개 사양 월말 결품·안전재고 미만 예상 (재고 {round(ps['tot']['stock']):,}t, 목표 {round(ps['tot']['target']):,}t)", 'link': 'planstock.html', 'who': '컬러건재'})
            portal['planstock'] = {'stock': round(ps['tot']['stock']), 'target': round(ps['tot']['target']), 'end': round(ps['tot']['end'][0]) if ps['tot']['end'] else None, 'flags': ps['flags']}
    except Exception as e:                                     # 계획재 화면 실패는 다른 화면에 영향 없음
        ps = None
        print('계획재 분석 실패:', e)
    try:
        from . import color_cond as CC
        cc = CC.build(T)
    except Exception as e:
        cc = None
        print('컬러 조건 분석 실패:', e)
    portal['week'] = week_events(today, R2, pr_all, ps)
    pages = {'color_actual': ca['asOf'] if ca else None, 'plating_actual': ga['asOf'] if ga else None, 'procure': today if pr else None, 'portal': data_last}
    st = status(T, coils, auto or {}, pages, run_at)
    return {'color_actual': ca, 'plating_actual': ga, 'procure': pr, 'portal': portal, 'status': st, 'accHist': hist, 'planstock': ps, 'color_cond': cc, 'dueHist': due_h}


def publish(cfg, sb, dry, T, coils, R_prev, R2, auto, log, encrypt, stops=None):
    """auto.run 5-5단계: 계산 → 암호화 게시(status.json 은 평문). 실패해도 계획 게시에는 영향 없음"""
    hp = os.path.join(cfg['out_dir'], 'acc_hist.json')
    hist = json.load(open(hp, encoding='utf-8')) if os.path.exists(hp) else None
    dp = os.path.join(cfg['out_dir'], 'due_hist.json')            # 발주 인도납기 변경 이력(매일 쌓음)
    try:
        dh = json.load(open(dp, encoding='utf-8')) if os.path.exists(dp) else None
    except Exception:
        dh = None
    O = build_all(T, coils, R_prev, R2, auto, hist, run_at=auto.get('runAt'), stops=stops, duehist=dh)
    json.dump(O['accHist'], open(hp, 'w', encoding='utf-8'), ensure_ascii=False)
    if O.get('dueHist'):
        json.dump(O['dueHist'], open(dp, 'w', encoding='utf-8'), ensure_ascii=False)
    pw = cfg.get('analysis_password') or cfg['password']
    pre = 'test.' if cfg['published_path'].startswith('test') else ''
    done = []
    for name, label in (('color_actual', '컬러 실적'), ('plating_actual', '도금 실적'), ('procure', '소재 조달 판단'), ('portal', '포털 요약'), ('planstock', '계획재 분석'), ('color_cond', '컬러 조건 분석')):
        if not O[name]:
            continue
        body = json.dumps(encrypt(O[name], pw, label))
        path = f'{pre}{name}.enc.json'
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(body)
        else:
            sb.upload(cfg['published_bucket'], path, body, cache='60')
        done.append(path)
    try:                                                         # 웹 '컬러 계획 계산'용 MES 자료(계산에 쓰는 표·열만, 개인정보 제외)
        from . import colorcalc as CC, store as ST
        nz = lambda v: None if isinstance(v, float) and v != v else v
        cm = CC.mes_payload(T, ST.COLS, [[nz(c.get(k)) for k in ST.COLS] for c in coils or []], auto.get('runAt'))
        body = json.dumps(encrypt(cm, pw, '컬러 계획 계산 자료'))
        path = f'{pre}color_calc_mes.enc.json'
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(body)
        else:
            sb.upload(cfg['published_bucket'], path, body, cache='60')
        done.append(path)
    except Exception as e:                                       # 계산 자료 실패는 다른 화면 게시에 영향 없음
        log(f'컬러 계획 계산 자료 게시 건너뜀: {e}')
    if auto.get('remoteOnly') and sb and not dry:                 # 2시간 원격 조회엔 실적 표가 없음 → 빈 원천 날짜는 직전 게시값 유지(아침 실행이 멈췄는지 가려지지 않게)
        try:
            prev = {f['name']: f for f in (json.loads(sb.download(cfg['published_bucket'], pre + 'status.json')) or {}).get('feeds', [])}
            O['status']['feeds'] = [f if f.get('last') else dict(prev.get(f['name'], f)) for f in O['status']['feeds']]
        except Exception as e:
            log(f'직전 자료 상태 읽기 실패(그대로 게시): {e}')
    stj = json.dumps(O['status'], ensure_ascii=False)
    if dry:
        open(os.path.join(cfg['out_dir'], pre + 'status.json'), 'w', encoding='utf-8').write(stj)
    else:
        sb.upload(cfg['published_bucket'], pre + 'status.json', stj, cache='60')
    log(f"화면 자료 게시: {', '.join(done)}, {pre}status.json · 오늘 볼 것 {len(O['portal'].get('exceptions', []))}건")
    return O
