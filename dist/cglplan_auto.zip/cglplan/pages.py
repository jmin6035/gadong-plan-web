"""웹 화면용 자료를 매일 다시 계산한다(사내 PC 자동 실행기 5-5단계, 클라우드에서는 tools/pages_build.py).

만드는 것(모두 published/ 버킷에 게시):
  color_actual.enc.json  컬러 실적(진도·일별·주별·품명·휴지)            ← extradata: color_prod·color_brk·snap_salesrpt
  procure.enc.json       조달 판단(수요·업체는 기준 파일, 재고만 매일)   ← pages_base/procure_base.json + snap_mat_stock_cc·snap_stock + 도금 코일
  portal.enc.json        홈 요약(오늘 볼 것·계획 정확도·지표)           ← 위 둘 + 최신 계획(R2) + pages_base/portal_base.json + 정확도 이력
  status.json            자료 상태(암호 없음, 날짜·건수만)               ← 원천별 마지막 날짜·실행 결과
정의는 tools/color_actual.py·procure_data.py·portal_data.py 와 같다(그 스크립트들도 이 모듈을 쓴다).
기준 파일(pages_base/*.json)은 계획이 바뀔 때 클라우드에서 tools/pages_build.py --base 로 다시 만든다.
"""
import datetime as dt
import json
import os
from collections import Counter, defaultdict

from . import salesrpt, yields as YL

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pages_base')
CCL = ['1CCL', '2CCL', '3CCL', '4CCL']
CGL = ['1CGL', '2CGL']
STOP_CATS = [('색상교체·청소', ('청소', '색상', '준비')), ('테스트·도막조정', ('TEST', '단판', '도막', '조색')),
             ('폭·롤·두께 전환', ('폭', 'ROLL', '두께', 'DUMMY')), ('기타', ())]
FH_OF = {'AL': 'H', 'AL-LG': 'H', 'AZ': 'F', 'MAC': 'F', 'AL-STS': 'N'}
USABLE = ('사용가능', '작업지시대기', '가공대기', '가공대상')
BRK_LINE = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}
SAFETY = 5


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def D(s):
    return dt.date.fromisoformat(str(s)[:10])


def week_of(d):
    x = D(d)
    return (x - dt.timedelta(days=x.weekday())).isoformat()


def stop_cat(t):
    t = t or ''
    for name, keys in STOP_CATS:
        if any(k in t for k in keys):
            return name
    return '기타'


def load_base(name):
    p = os.path.join(BASE, name)
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else None


def _rows(T, name):
    t = T.get(name)
    return [dict(zip(t['columns'], r)) for r in t['rows']] if t else []


_CODES = None


def product_name(code):
    global _CODES
    if _CODES is None:
        _CODES = (load_base('color_product_codes.json') or {}).get('codes', {})
    s = str((_CODES.get(code) or {}).get('name', code) or '').strip()
    import re
    s = re.sub(r'\(MAC\.?\)', '', s, flags=re.I)
    s = re.sub(r'\((가전|후물|프)\)', '', s)
    return s.split('_')[0].strip()


# ------------------------------------------------------------------ 컬러 실적
def color_actual(T):
    rows = _rows(T, 'color_prod')
    if not rows:
        return None
    last = max(r['PRD_DT'] for r in rows)
    d_last = D(last)
    full = lambda w: D(w) + dt.timedelta(days=6) <= d_last
    weeks = sorted({week_of(r['PRD_DT']) for r in rows if full(week_of(r['PRD_DT']))})
    w1 = weeks[-1]
    w0s = weeks[-13:-1] or weeks[-1:]
    day = defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    mon = defaultdict(float)
    dept = defaultdict(float)
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for r in rows:
        d, l = r['PRD_DT'], r['LINE']
        t = f(r['PDT_WGT']) / 1000
        h = (f(r['WRK_TIME']) + f(r['PAU_TIME'])) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(r['PAU_TIME']) / 60; x[4] += t * f(r['REAL_MSR_THK'])
        mon[(d[:7], l)] += t
        dept[(d[:7], str(r['DEPT'] or '기타'))] += t
        if d >= weeks[-4]:
            p = prod[(l, product_name(r['PDT_NM']))]
            p[0] += t; p[1] += h; p[2] += t * f(r['REAL_MSR_THK'])
    stop = defaultdict(float)
    for r in _rows(T, 'color_brk'):
        d = str(r['WRK_DT'])
        d = f'{d[:4]}-{d[4:6]}-{d[6:]}'
        l = BRK_LINE.get(str(r.get('LINE_CLS') or '')[:1], str(r.get('LINE_CLS')))
        stop[(week_of(d), l, stop_cat(r.get('SPL_REM')))] += f(r['PAU_TIME']) / 60

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s / max(n, 1), 'thick': th / t if t else None}
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = [(d_last - dt.timedelta(days=i)).isoformat() for i in range(34, -1, -1)]
    return {'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': last, 'w1': w1, 'w0': [w0s[0], w0s[-1]],
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CCL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '컬러']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CCL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 1), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CCL}} for w in weeks],
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CCL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CCL},
            'stops': {'cats': [c for c, _ in STOP_CATS],
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c, _ in STOP_CATS} for l in CCL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c, _ in STOP_CATS} for l in CCL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CCL) / 7, 2) for c, _ in STOP_CATS}} for w in weeks]}}


# ------------------------------------------------------------------ 조달 판단: 재고
def procure_stock(T, coils, today):
    """컬러 = 소재재고List 재고중량(사용 가능 구분, 자가 제외) · 도금 FH = 최근 월말 재고현황 − 그 뒤 도금 실적 사용량(실수율 반영)"""
    st = defaultdict(float)
    for r in _rows(T, 'snap_mat_stock_cc'):
        b = str(r.get('구매처') or '')
        if ':' not in b or b.startswith('A1') or r.get('재고구분') not in USABLE:
            continue
        w = f(r.get('재고중량')) / 1000
        if w > 0:
            st[('C', str(r.get('Zn') or '')[:1])] += w
    S = _rows(T, 'snap_stock')
    months = sorted({str(r['_기준월']) for r in S if r.get('공장구분') == 'G'})
    m_last = months[-1] if months else None
    if m_last:
        for r in S:
            if r['구분명'] == 'R' and r['공장구분'] == 'G' and str(r['_기준월']) == m_last and str(r.get('소재공급업체') or '') != 'A1':
                if not (f(r.get('재고일수')) > 180 or str(r.get('제품등급')).strip() == '5'):
                    st[('G', str(r['품명코드']))] += f(r['중량']) / 1000
        y, m = int(m_last[:4]), int(m_last[4:])
        after = dt.date(y + (m == 12), m % 12 + 1, 1).isoformat()
        for c in coils or []:
            if after <= str(c['day']) < today:
                a = c.get('alloy') or c.get('fam')
                st[('G', FH_OF.get(a, 'F'))] -= f(c['t']) / (YL.plating(c['line'], a, c.get('cls')) / 100)
    note = f"컬러 = 소재재고List(CC) 재고중량 · 도금 FH = {m_last[:4]}.{m_last[4:]}월말 재고 − 이후 도금 실적 사용(입고는 자료 없음)" if m_last else '재고 자료 없음'
    return {f'{k[0]}:{k[1]}': round(max(0.0, v), 1) for k, v in st.items()}, note


def procure(T, coils, today, base=None):
    base = base or load_base('procure_base.json')
    if not base:
        return None
    stock, note = procure_stock(T, coils, today)
    return dict(base, today=today, built=dt.datetime.now().isoformat(timespec='minutes'), stock=stock, stockNote=note)


def procure_summary(P, plant=None):
    """조달 판단 화면 기본값(여유 5일, 기발주 미입력, 업체 기준정보 초기값)으로 1순위 발주 시한·대체·기발주 확인 건수"""
    today = D(P['today'])
    lots = dict(P['stock'])
    sup = defaultdict(list)
    for s in P['suppliers']:
        sup[(s['plant'], s['code'])].append(s)
    mon = today - dt.timedelta(days=today.weekday())
    near, alt, chk, short4 = [], 0, 0, 0.0
    for u in sorted(P['units'], key=lambda x: (x['first'], x['code'])):
        if plant and u['plant'] != plant:
            continue
        need_by = D(u['first']) - dt.timedelta(days=SAFETY)
        left = (need_by - today).days
        k = f"{u['plant']}:{u['code']}"
        q = min(lots.get(k, 0.0), u['t'])
        lots[k] = lots.get(k, 0.0) - q
        short = u['t'] - q
        if short < 1:
            continue
        cand = sorted(sup.get((u['plant'], u['code']), []), key=lambda s: s['prio'])
        ok = [s for s in cand if s['lt'] <= left and (not u.get('thk') or not s.get('thk') or (u['thk'][0] >= s['thk'][0] - .005 and u['thk'][1] <= s['thk'][1] + .005))]
        wk = (D(u['wk']) - mon).days // 7
        if 1 <= wk < 4:
            short4 += short
            if not ok and cand:
                chk += 1
            elif ok and ok[0] is not cand[0]:
                alt += 1
        if cand:
            dl = need_by - dt.timedelta(days=cand[0]['lt'])
            if 0 <= (dl - today).days <= 14:
                near.append({'plant': u['plant'], 'mat': P['matCode'].get(u['code'], u['code']), 'first': u['first'], 'deadline': dl.isoformat(), 't': round(short), 'sup': cand[0]['name']})
    near.sort(key=lambda x: x['deadline'])
    return {'near': len(near), 'nearTop': near[:6], 'alt': alt, 'check': chk, 'short4w': round(short4)}


# ------------------------------------------------------------------ 계획 정확도(전날 계획 vs 실적)
def coil_daily(coils):
    a = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy'):                                  # 더미 코일 제외(실적 분석·재계획과 같은 기준)
            a[(str(c['day']), c['line'])] += f(c['t'])
    return a


def plan_daily(R):
    a = defaultdict(float)
    for r in (R or {}).get('rows', []):
        a[(r[0], r[1])] += f(r[4])
    return a


def accuracy(hist, R_prev, coils, upto):
    """hist: [[날짜, 라인, 계획t, 실적t]] — R_prev(이번 실행 전 게시 계획)가 그날을 어떻게 잡았는지 vs 실적. 이미 있는 날은 덮지 않음"""
    pd_, ad = plan_daily(R_prev), coil_daily(coils)
    for h in hist:                                              # 실적은 MES 가 나중에 고치거나 늦게 들어오므로 최신 값으로 갱신
        if (h[0], h[1]) in ad:
            h[3] = round(ad[(h[0], h[1])], 1)
    have = {(h[0], h[1]) for h in hist}
    t0 = ((R_prev or {}).get('replan') or {}).get('t0') or ''
    days = sorted({d for (d, _) in ad if d > t0 and d <= upto})
    for d in days:
        for l in CGL:
            if (d, l) not in have and ((d, l) in pd_ or (d, l) in ad):
                hist.append([d, l, round(pd_.get((d, l), 0.0), 1), round(ad.get((d, l), 0.0), 1)])
    hist.sort()
    return hist


def accuracy_summary(hist, n=14):
    out = {}
    for l in CGL:
        h = [x for x in hist if x[1] == l][-n:]
        if not h:
            continue
        p, a = sum(x[2] for x in h), sum(x[3] for x in h)
        mape = sum(abs(x[3] - x[2]) for x in h) / max(1, p)
        out[l] = {'days': len(h), 'plan': round(p), 'actual': round(a), 'bias': round((a / p - 1) * 100, 1) if p else None,
                  'mae': round(mape * 100, 1), 'under': sum(1 for x in h if x[3] < x[2] * 0.95), 'last': h[-5:]}
    return out


# ------------------------------------------------------------------ 오늘 볼 것(예외)
def exceptions(today, ca, pr_sum, R2, acc, stock_rows, data_last):
    E = []
    add = lambda lvl, area, text, link, who: E.append({'lvl': lvl, 'area': area, 'text': text, 'link': link, 'who': who})
    # 자료
    if data_last and (D(today) - D(data_last)).days > 1:
        add('bad', '자료', f'실적 자료가 {data_last} 에서 멈춤({(D(today) - D(data_last)).days}일 전) — 사내 PC 자동 실행 확인', 'health.html', '생산기획')
    # 도금: 최근 계획 대비 실적
    for l, x in (acc or {}).items():
        last = x['last'][-3:]
        if len(last) >= 2 and all(r[3] < r[2] * 0.9 for r in last[-2:]):
            add('warn', '도금', f"{l} 이틀 연속 계획의 90% 미만 (최근 {', '.join(f'{r[0][5:]}: {r[3]:,.0f}/{r[2]:,.0f}t' for r in last[-2:])}) — 속도·강종 순서 확인", 'integrated.html', '생산기획')
    if R2:
        t0 = (R2.get('replan') or {}).get('t0') or today
        lim = (D(t0) + dt.timedelta(days=3)).isoformat()
        tight = [r for r in R2['rows'] if t0 < r[0] <= lim and (D(r[5]) - D(r[0])).days <= 1]
        if sum(f(r[4]) for r in tight) >= 300:
            add('warn', '도금', f'앞으로 3일 안에 납기 1일 이내로 만드는 물량 {sum(f(r[4]) for r in tight):,.0f}t ({len(tight)}건) — 정지·지연 시 바로 납기 지연', 'status.html', '생산기획')
    # 컬러
    if ca:
        M = {x['line']: x for x in ca['month']['rows']}
        for x in ca['lines']:
            d = (x['w1']['tpd'] / x['w0']['tpd'] - 1) * 100 if x['w0']['tpd'] else 0
            m = M.get(x['line'])
            r = m['actual'] / m['sched'] * 100 if m and m.get('sched') else None
            if d <= -20 or (r is not None and r < 95):
                add('warn', '컬러', f"{x['line']} 지난주 {x['w1']['tpd']:,.0f}t/일(12주 대비 {d:+.0f}%)" + (f', 이번 달 일정 대비 {r:.0f}%' if r is not None else '') + f" · 휴지 {x['w1']['stopH']:.1f}h/가동일", 'color_actual.html', '생산기획')
    # 소재
    if pr_sum:
        soon = [x for x in pr_sum.get('nearTop', []) if (D(x['deadline']) - D(today)).days <= 3]
        for x in soon[:3]:
            add('bad' if x['deadline'] <= today else 'warn', '소재', f"{x['mat']} {x['first'][5:]} 필요분 {x['t']:,}t — 1순위 {x['sup']} 발주 시한 {x['deadline'][5:]}", 'procure.html', '구매')
        if pr_sum.get('check'):
            add('warn', '소재', f"2~4주 안 리드타임 안쪽 부족 {pr_sum['check']}건 — 기발주 확인(입고예정 입력)", 'procure.html', '구매')
    # 재고
    for s in stock_rows or []:
        if s.get('target'):
            r = s['current'] / s['target']
            if r > 1.3 or r < 0.7:
                add('warn' if r < 1.6 else 'bad', '재고', f"{s['name']} {s['current']:,.0f}t — 목표 {s['target']:,.0f}t의 {r * 100:.0f}%", 'report.html', '판매·생산기획')
    order = {'bad': 0, 'warn': 1}
    E.sort(key=lambda e: order.get(e['lvl'], 2))
    return E


# ------------------------------------------------------------------ 자료 상태
def status(T, coils, auto, pages, run_at):
    def last_of(name, key):
        rs = T.get(name)
        if not rs:
            return None
        i = rs['columns'].index(key) if key in rs['columns'] else None
        v = [str(r[i])[:10] for r in rs['rows'] if i is not None and r[i]]
        return max(v) if v else None
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    feeds = [
        {'name': '도금 생산 실적(코일)', 'last': max((str(c['day']) for c in coils), default=None), 'n': len(coils or [])},
        {'name': '컬러 생산 실적', 'last': last_of('color_prod', 'PRD_DT'), 'n': len((T.get('color_prod') or {}).get('rows', []))},
        {'name': '판매생산속보(진도·재고)', 'last': (SR or {}).get('asOf', '')[:10] or None},
        {'name': '출하', 'last': last_of('ship', 'OUT_DT')},
        {'name': '소재재고List(컬러)', 'last': last_of('snap_mat_stock_cc', '입고일')},
        {'name': '재고현황(월말)', 'last': (lambda m: f'{m[:4]}-{m[4:]}' if m else None)(max((str(r[0]) for r in (T.get('snap_stock') or {}).get('rows', [])), default=None))},
    ]
    return {'app': 'cgl-status', 'runAt': run_at, 'ok': True, 'auto': {k: auto.get(k) for k in ('actualTo', 'replanned', 'optimal', 'notes', 'newCoils')} if auto else None,
            'feeds': feeds, 'pages': pages}


# ------------------------------------------------------------------ 전체
def build_all(T, coils, R_prev, R2, auto=None, hist=None, today=None, run_at=None):
    run_at = run_at or dt.datetime.now(dt.timezone.utc).isoformat(timespec='minutes')
    today = today or (dt.datetime.utcnow() + dt.timedelta(hours=9)).date().isoformat()
    ca = color_actual(T)
    pr = procure(T, coils, today)
    pb = load_base('portal_base.json') or {}
    data_last = max((str(c['day']) for c in coils), default=None) if coils else (ca or {}).get('asOf')
    hist = accuracy(list(hist or pb.get('accHist', [])), R_prev, coils, data_last or today)
    acc = accuracy_summary(hist)
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    pr_all = procure_summary(pr) if pr else None
    portal = dict(pb.get('static', {}))
    portal.update({'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': data_last, 'today': today,
                   'procure': pr_all, 'procureBy': {'G': procure_summary(pr, 'G'), 'C': procure_summary(pr, 'C')} if pr else None,
                   'acc': acc, 'exceptions': exceptions(today, ca, pr_all, R2, acc, (SR or {}).get('stock'), data_last),
                   'colorNow': {'month': ca['month'], 'w1': ca['w1'], 'tpd': [round(x['w1']['tpd']) for x in ca['lines']], 'tpd0': [round(x['w0']['tpd']) for x in ca['lines']]} if ca else None})
    if R2:                                                     # 최신 계획 기준 빠듯함·계획 대비 실적
        t0 = (R2.get('replan') or {}).get('t0') or data_last or today
        tight = [r for r in R2['rows'] if r[0] > t0 and (D(r[5]) - D(r[0])).days <= 2]
        pl = portal.setdefault('plating', {})
        pl.update({'tightN': len(tight), 'tightT': round(sum(f(r[4]) for r in tight)), 'slack': {k: round(v) for k, v in (R2.get('slack') or {}).items()}})
    base_plan = pb.get('basePlanDaily') or {}                  # 확정 계획(V1) 일별 — 계획 대비 실적 누계
    if base_plan and coils:
        ad = coil_daily(coils)
        q0 = pb.get('q0', '2026-10-01')
        act = sum(v for (d, l), v in ad.items() if q0 <= d <= data_last)
        pln = sum(v for k, v in base_plan.items() if q0 <= k.split('|')[0] <= data_last)
        portal['roll'] = {'asOf': data_last, 'actual': round(act), 'plan': round(pln)}
    pages = {'color_actual': ca['asOf'] if ca else None, 'procure': today if pr else None, 'portal': data_last}
    st = status(T, coils, auto or {}, pages, run_at)
    return {'color_actual': ca, 'procure': pr, 'portal': portal, 'status': st, 'accHist': hist}


def publish(cfg, sb, dry, T, coils, R_prev, R2, auto, log, encrypt):
    """auto.run 5-5단계: 계산 → 암호화 게시(status.json 은 평문). 실패해도 계획 게시에는 영향 없음"""
    hp = os.path.join(cfg['out_dir'], 'acc_hist.json')
    hist = json.load(open(hp, encoding='utf-8')) if os.path.exists(hp) else None
    O = build_all(T, coils, R_prev, R2, auto, hist, run_at=auto.get('runAt'))
    json.dump(O['accHist'], open(hp, 'w', encoding='utf-8'), ensure_ascii=False)
    pw = cfg.get('analysis_password') or cfg['password']
    pre = 'test.' if cfg['published_path'].startswith('test') else ''
    done = []
    for name, label in (('color_actual', '컬러 실적'), ('procure', '소재 조달 판단'), ('portal', '포털 요약')):
        if not O[name]:
            continue
        body = json.dumps(encrypt(O[name], pw, label))
        path = f'{pre}{name}.enc.json'
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(body)
        else:
            sb.upload(cfg['published_bucket'], path, body, cache='60')
        done.append(path)
    stj = json.dumps(O['status'], ensure_ascii=False)
    if dry:
        open(os.path.join(cfg['out_dir'], pre + 'status.json'), 'w', encoding='utf-8').write(stj)
    else:
        sb.upload(cfg['published_bucket'], pre + 'status.json', stj, cache='60')
    log(f"화면 자료 게시: {', '.join(done)}, {pre}status.json · 오늘 볼 것 {len(O['portal'].get('exceptions', []))}건")
    return O
