"""웹 화면용 자료를 매일 다시 계산한다(사내 PC 자동 실행기 5-5단계, 클라우드에서는 tools/pages_build.py).

만드는 것(모두 published/ 버킷에 게시):
  color_actual.enc.json  컬러 실적(진도·일별·주별·품명·휴지)            ← extradata: color_prod·color_brk·snap_salesrpt
  procure.enc.json       조달 판단(수요·업체는 기준 파일, 재고만 매일)   ← pages_base/procure_base.json + snap_mat_stock_cc·snap_stock + 도금 코일
  planstock.enc.json     계획재 분석·예측(R15 187 사양)                    ← pages_base/planstock_base.json + color_prod·ship·snap_stock (cglplan/planstock.py)
  color_cond.enc.json    컬러 조건 분석(계획 t/hr vs 최근 4주)               ← pages_base/color_cond_base.json + color_prod (cglplan/color_cond.py)
  portal.enc.json        홈 요약(오늘 볼 것·계획 정확도·지표)           ← 위 둘 + 최신 계획(R2) + pages_base/portal_base.json + 정확도 이력
  status.json            자료 상태(암호 없음, 날짜·건수만)               ← 원천별 마지막 날짜·실행 결과
정의는 tools/color_actual.py·procure_data.py·portal_data.py 와 같다(그 스크립트들도 이 모듈을 쓴다).
기준 파일(pages_base/*.json)은 계획이 바뀔 때 클라우드에서 tools/pages_build.py --base 로 다시 만든다.
"""
import datetime as dt
import json
import os
from collections import Counter, defaultdict

from . import salesrpt, yields as YL

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pages_base')
CCL = ['1CCL', '2CCL', '3CCL', '4CCL']
CGL = ['1CGL', '2CGL']
STOP_CATS = [('색상교체·청소', ('청소', '색상', '준비')), ('테스트·도막조정', ('TEST', '단판', '도막', '조색')),
             ('폭·롤·두께 전환', ('폭', 'ROLL', '두께', 'DUMMY')), ('기타', ())]
FH_OF = {'AL': 'H', 'AL-LG': 'H', 'AZ': 'F', 'MAC': 'F', 'AL-STS': 'N'}
USABLE = ('사용가능', '작업지시대기', '가공대기', '가공대상')
# 마케팅 그룹(MES 판매그룹 이름 기준). 자가재 = 도금이 만든 컬러 소재(MES 에선 컬러 그룹 이름으로 잡힘)
GROUPS = [('G수출', '도금수출', 'G'), ('G국내', '도금판매(국내)', 'G'), ('G자동차', '자동차강판', 'G'), ('G자가재', '도금 자가재(컬러 소재)', 'G'),
          ('C수출', '컬러수출', 'C'), ('C건재', '컬러건재', 'C'), ('C수요', '수요개발', 'C')]
PLAN_GROUP = {'도금수출': 'G수출', '도금국내': 'G국내', '자동차수출': 'G자동차', '자동차내수': 'G자동차', '자가재': 'G자가재'}        # 계획 부서 → 그룹
COLOR_GROUP = {'가전수출': 'C수출', '가전내수': 'C수출', '건재수출': 'C수출', '계획재': 'C건재', '주문재': 'C건재', '수요개발': 'C수요'}   # cglplan/color_full 분류
COIL_GROUP = {'도금수출그룹': 'G수출', '도금판매그룹': 'G국내', '자동차강판판매그룹': 'G자동차',
              '컬러수출그룹': 'G자가재', '컬러건재판매그룹': 'G자가재', '수요개발그룹': 'G자가재', '컬러공장': 'G자가재'}
CPROD_GROUP = {'컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재', '수요개발그룹': 'C수요'}
SHIP_GROUP = {'도금판매': 'G국내', '도금수출': 'G수출', '자동차강판': 'G자동차', '컬러수출': 'C수출', '컬러건재': 'C건재'}
BRK_LINE = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}
SAFETY = {'C': 7, 'G': 5}                                    # 입고 → 투입 여유(팀 소재 리드타임 표 2026-10-12: 컬러 +7일, 도금 자가 +5일)
POSCO_SUPPLIED = {('G', 'N')}                                # 임가공 AL-STS F/H = 포스코 지급(우리 발주 아님)


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def D(s):
    return dt.date.fromisoformat(str(s)[:10])


def week_of(d):
    x = D(d)
    return (x - dt.timedelta(days=x.weekday())).isoformat()


def stop_cat(t):
    t = t or ''
    for name, keys in STOP_CATS:
        if any(k in t for k in keys):
            return name
    return '기타'


def load_base(name):
    p = os.path.join(BASE, name)
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else None


def _rows(T, name):
    t = T.get(name)
    return [dict(zip(t['columns'], r)) for r in t['rows']] if t else []


_CODES = None


def product_name(code):
    global _CODES
    if _CODES is None:
        _CODES = (load_base('color_product_codes.json') or {}).get('codes', {})
    s = str((_CODES.get(code) or {}).get('name', code) or '').strip()
    import re
    s = re.sub(r'\(MAC\.?\)', '', s, flags=re.I)
    s = re.sub(r'\((가전|후물|프)\)', '', s)
    return s.split('_')[0].strip()


# ------------------------------------------------------------------ 컬러 실적
def color_actual(T):
    rows = _rows(T, 'color_prod')
    if not rows:
        return None
    last = max(r['PRD_DT'] for r in rows)
    d_last = D(last)
    d_first = D(min(r['PRD_DT'] for r in rows))
    full = lambda w: D(w) >= d_first and D(w) + dt.timedelta(days=6) <= d_last      # 자료 첫 주·마지막 주가 잘린 주는 추이에서 뺌
    weeks = sorted({week_of(r['PRD_DT']) for r in rows if full(week_of(r['PRD_DT']))}) or [week_of(last)]   # 자료가 1주 미만이어도 동작
    w1 = weeks[-1]
    cut4 = weeks[-4] if len(weeks) >= 4 else weeks[0]                       # 품목별 = 최근 4주(자료가 짧으면 있는 만큼)
    w0s = weeks[-13:-1] or weeks[-1:]
    day = defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    mon = defaultdict(float)
    dept = defaultdict(float)
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for r in rows:
        d, l = r['PRD_DT'], r['LINE']
        t = f(r['PDT_WGT']) / 1000
        h = (f(r['WRK_TIME']) + f(r['PAU_TIME'])) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(r['PAU_TIME']) / 60; x[4] += t * f(r['REAL_MSR_THK'])
        mon[(d[:7], l)] += t
        dept[(d[:7], str(r['DEPT'] or '기타'))] += t
        if d >= cut4:
            p = prod[(l, product_name(r['PDT_NM']))]
            p[0] += t; p[1] += h; p[2] += t * f(r['REAL_MSR_THK'])
    stop = defaultdict(float)
    for r in _rows(T, 'color_brk'):
        d = str(r['WRK_DT'])
        d = f'{d[:4]}-{d[4:6]}-{d[6:]}'
        l = BRK_LINE.get(str(r.get('LINE_CLS') or '')[:1], str(r.get('LINE_CLS')))
        stop[(week_of(d), l, stop_cat(r.get('SPL_REM')))] += f(r['PAU_TIME']) / 60

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s / max(n, 1), 'thick': th / t if t else None}
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = [(d_last - dt.timedelta(days=i)).isoformat() for i in range(34, -1, -1)]
    return {'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': last, 'from': min(r['PRD_DT'] for r in rows), 'w1': w1, 'w0': [w0s[0], w0s[-1]], 'plant': 'C',
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CCL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '컬러']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CCL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 1), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CCL}} for w in weeks],
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CCL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CCL},
            'stops': {'cats': [c for c, _ in STOP_CATS],
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c, _ in STOP_CATS} for l in CCL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c, _ in STOP_CATS} for l in CCL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CCL) / 7, 2) for c, _ in STOP_CATS}} for w in weeks]}}


# ------------------------------------------------------------------ 도금 실적 (컬러 실적과 같은 구성·같은 정의)
G_STOP_CATS = ['강종 전환(M/C)', '정기수리', '설비·운전', '기타']


def g_stop_cat(nm, dtl):
    nm, dtl = str(nm or ''), str(dtl or '')
    if 'mode change' in nm.lower() or 'MODE CHANGE' in dtl.upper():
        return G_STOP_CATS[0]
    if '정기수리' in nm or '정기수리' in dtl:
        return G_STOP_CATS[1]
    if any(k in dtl for k in ('기계', '전기', '운전')):
        return G_STOP_CATS[2]
    return G_STOP_CATS[3]


def plating_actual(T, coils, stops=None):
    """도금 1·2CGL 실적 — color_actual 과 같은 키(lines·month·daily·weekly·monthly·dept·products·stops) + mc(강종 전환 실적).
    톤 = 더미 제외 코일(판매생산속보·재계획과 같은 기준), 속도 = 생산 t ÷ 작업시간(정지 포함 = 달력 시간), 컬러 실적과 같은 정의"""
    C = [c for c in (coils or []) if not c.get('dummy')]
    if not C:
        return None
    last = max(str(c['day']) for c in C)
    d_last = D(last)
    d_first = D(min(str(c['day']) for c in C))
    full = lambda w: D(w) >= d_first and D(w) + dt.timedelta(days=6) <= d_last
    weeks = sorted({week_of(c['day']) for c in C if full(week_of(c['day']))}) or [week_of(last)]
    w1 = weeks[-1]
    cut4 = weeks[-4] if len(weeks) >= 4 else weeks[0]
    w0s = weeks[-13:-1] or weeks[-1:]
    day, mon, dept = defaultdict(float), defaultdict(float), defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for c in coils:                                              # 시간은 더미 코일 포함(M/C 정지가 더미에 붙음), 톤은 더미 제외
        d, l, t = str(c['day']), c['line'], (0.0 if c.get('dummy') else f(c['t']))
        h = f(c.get('work')) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(c.get('stop')) / 60; x[4] += t * f(c.get('thick'))
        mon[(d[:7], l)] += t
        dept[(d[:7], str(c.get('dept') or '기타'))] += t
        if d >= cut4:
            p = prod[(l, f"{c.get('pname') or '-'} · {c.get('alloy') or c.get('fam') or '-'}")]
            p[0] += t; p[1] += h; p[2] += t * f(c.get('thick'))
    prd_day = {c.get('prd'): str(c['day']) for c in coils or []}
    stop = defaultdict(float)
    mc = defaultdict(lambda: {'h': 0.0, 'nm': ''})
    for x in stops or []:
        d = prd_day.get(x.get('prd')) or (dt.datetime(1970, 1, 1) + dt.timedelta(minutes=f(x.get('s')))).date().isoformat()
        cat = g_stop_cat(x.get('nm'), x.get('dtl'))
        stop[(week_of(d), x['line'], cat)] += f(x.get('t')) / 60
        if cat == G_STOP_CATS[0]:
            m = mc[(d, x['line'])]
            m['h'] += f(x.get('t')) / 60
            m['nm'] = m['nm'] or str(x.get('nm') or '')

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s_ = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s_ / max(n, 1), 'thick': th / t if t else None}
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = [(d_last - dt.timedelta(days=i)).isoformat() for i in range(34, -1, -1)]
    import re
    mcl = []
    for (d, l), m in sorted(mc.items()):
        g = re.search(r'\(\s*(\w+)\s*-?>\s*(\w+)\s*\)', m['nm'])
        fr, to = (g.group(1), g.group(2)) if g else ('', '')
        fam = {'GI': 'MAC'}
        mcl.append({'d': d, 'line': l, 'from': fam.get(fr, fr), 'to': fam.get(to, to), 'h': round(m['h'], 1), 'sd': '정기수리' in m['nm']})
    return {'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': last, 'from': min(str(c['day']) for c in C), 'w1': w1, 'w0': [w0s[0], w0s[-1]], 'plant': 'G',
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CGL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '도금']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CGL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 1), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CGL}} for w in weeks],
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CGL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CGL},
            'stops': {'cats': G_STOP_CATS,
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c in G_STOP_CATS} for l in CGL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c in G_STOP_CATS} for l in CGL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CGL) / 7, 2) for c in G_STOP_CATS}} for w in weeks]},
            'mc': mcl[-12:]}


# ------------------------------------------------------------------ 조달 판단: 재고
def procure_stock(T, coils, today):
    """컬러 = 소재재고List 재고중량(사용 가능 구분, 자가 제외) · 도금 FH = 최근 월말 재고현황 − 그 뒤 도금 실적 사용량(실수율 반영)"""
    st = defaultdict(float)
    for r in _rows(T, 'snap_mat_stock_cc'):
        b = str(r.get('구매처') or '')
        if ':' not in b or b.startswith('A1') or r.get('재고구분') not in USABLE:
            continue
        w = f(r.get('재고중량')) / 1000
        if w > 0:
            st[('C', str(r.get('Zn') or '')[:1])] += w
    S = _rows(T, 'snap_stock')
    months = sorted({str(r['_기준월']) for r in S if r.get('공장구분') == 'G'})
    m_last = months[-1] if months else None
    if m_last:
        for r in S:
            if r['구분명'] == 'R' and r['공장구분'] == 'G' and str(r['_기준월']) == m_last and str(r.get('소재공급업체') or '') != 'A1':
                if not (f(r.get('재고일수')) > 180 or str(r.get('제품등급')).strip() == '5'):
                    st[('G', str(r['품명코드']))] += f(r['중량']) / 1000
        y, m = int(m_last[:4]), int(m_last[4:])
        after = dt.date(y + (m == 12), m % 12 + 1, 1).isoformat()
        for c in coils or []:
            if after <= str(c['day']) < today:
                a = c.get('alloy') or c.get('fam')
                st[('G', FH_OF.get(a, 'F'))] -= f(c['t']) / (YL.plating(c['line'], a, c.get('cls')) / 100)
    note = f"컬러 = 소재재고List(CC) 재고중량 · 도금 FH = {m_last[:4]}.{m_last[4:]}월말 재고 − 이후 도금 실적 사용(입고는 자료 없음)" if m_last else '재고 자료 없음'
    return {f'{k[0]}:{k[1]}': round(max(0.0, v), 1) for k, v in st.items()}, note


def procure(T, coils, today, base=None):
    base = base or load_base('procure_base.json')
    if not base:
        return None
    stock, note = procure_stock(T, coils, today)
    return dict(base, today=today, built=dt.datetime.now().isoformat(timespec='minutes'), stock=stock, stockNote=note)


def procure_summary(P, plant=None):
    """조달 판단 화면 기본값(여유 5일, 기발주 미입력, 업체 기준정보 초기값)으로 1순위 발주 시한·대체·기발주 확인 건수"""
    today = D(P['today'])
    lots = dict(P['stock'])
    sup = defaultdict(list)
    for s in P['suppliers']:
        sup[(s['plant'], s['code'])].append(s)
    mon = today - dt.timedelta(days=today.weekday())
    near, alt, chk, short4 = [], 0, 0, 0.0
    for u in sorted(P['units'], key=lambda x: (x['first'], x['code'])):
        if plant and u['plant'] != plant:
            continue
        if (u['plant'], u['code']) in POSCO_SUPPLIED:
            continue
        need_by = D(u['first']) - dt.timedelta(days=SAFETY[u['plant']])
        left = (need_by - today).days
        k = f"{u['plant']}:{u['code']}"
        q = min(lots.get(k, 0.0), u['t'])
        lots[k] = lots.get(k, 0.0) - q
        short = u['t'] - q
        if short < 1:
            continue
        cand = sorted(sup.get((u['plant'], u['code']), []), key=lambda s: s['prio'])
        ok = [s for s in cand if s['lt'] <= left and (not u.get('thk') or not s.get('thk') or (u['thk'][0] >= s['thk'][0] - .005 and u['thk'][1] <= s['thk'][1] + .005))]
        wk = (D(u['wk']) - mon).days // 7
        if 1 <= wk < 4:
            short4 += short
            if not ok and cand:
                chk += 1
            elif ok and ok[0] is not cand[0]:
                alt += 1
        if cand:
            dl = need_by - dt.timedelta(days=cand[0]['lt'])
            if 0 <= (dl - today).days <= 14:
                near.append({'plant': u['plant'], 'mat': P['matCode'].get(u['code'], u['code']), 'first': u['first'], 'deadline': dl.isoformat(), 't': round(short), 'sup': cand[0]['name']})
    near.sort(key=lambda x: x['deadline'])
    return {'near': len(near), 'nearTop': near[:6], 'alt': alt, 'check': chk, 'short4w': round(short4)}


# ------------------------------------------------------------------ 계획 정확도(전날 계획 vs 실적)
def coil_daily(coils):
    a = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy'):                                  # 더미 코일 제외(실적 분석·재계획과 같은 기준)
            a[(str(c['day']), c['line'])] += f(c['t'])
    return a


def plan_daily(R):
    a = defaultdict(float)
    for r in (R or {}).get('rows', []):
        a[(r[0], r[1])] += f(r[4])
    return a


def accuracy(hist, R_prev, coils, upto):
    """hist: [[날짜, 라인, 계획t, 실적t]] — R_prev(이번 실행 전 게시 계획)가 그날을 어떻게 잡았는지 vs 실적. 이미 있는 날은 덮지 않음"""
    pd_, ad = plan_daily(R_prev), coil_daily(coils)
    for h in hist:                                              # 실적은 MES 가 나중에 고치거나 늦게 들어오므로 최신 값으로 갱신
        if (h[0], h[1]) in ad:
            h[3] = round(ad[(h[0], h[1])], 1)
    have = {(h[0], h[1]) for h in hist}
    t0 = ((R_prev or {}).get('replan') or {}).get('t0') or ''
    days = sorted({d for (d, _) in ad if d > t0 and d <= upto})
    for d in days:
        for l in CGL:
            if (d, l) not in have and ((d, l) in pd_ or (d, l) in ad):
                hist.append([d, l, round(pd_.get((d, l), 0.0), 1), round(ad.get((d, l), 0.0), 1)])
    hist.sort()
    return hist


def accuracy_summary(hist, n=14):
    out = {}
    for l in CGL:
        h = [x for x in hist if x[1] == l][-n:]
        if not h:
            continue
        p, a = sum(x[2] for x in h), sum(x[3] for x in h)
        mape = sum(abs(x[3] - x[2]) for x in h) / max(1, p)
        out[l] = {'days': len(h), 'plan': round(p), 'actual': round(a), 'bias': round((a / p - 1) * 100, 1) if p else None,
                  'mae': round(mape * 100, 1), 'under': sum(1 for x in h if x[3] < x[2] * 0.95), 'last': h[-5:]}
    return out


# ------------------------------------------------------------------ 오늘 볼 것(예외)
def exceptions(today, ca, pr_sum, R2, acc, stock_rows, data_last):
    E = []
    add = lambda lvl, area, text, link, who: E.append({'lvl': lvl, 'area': area, 'text': text, 'link': link, 'who': who})
    # 자료
    if data_last and (D(today) - D(data_last)).days > 1:
        add('bad', '자료', f'실적 자료가 {data_last} 에서 멈춤({(D(today) - D(data_last)).days}일 전) — 사내 PC 자동 실행 확인', 'health.html', '생산기획')
    # 도금: 최근 계획 대비 실적
    for l, x in (acc or {}).items():
        last = x['last'][-3:]
        fresh = data_last and last and (D(data_last) - D(last[-1][0])).days <= 1          # 최근 이틀이 실제 최신 실적일 때만(오래된 이력으로 경고하지 않음)
        if fresh and len(last) >= 2 and all(r[3] < r[2] * 0.9 for r in last[-2:]):
            add('warn', '도금', f"{l} 이틀 연속 계획의 90% 미만 (최근 {', '.join(f'{r[0][5:]}: {r[3]:,.0f}/{r[2]:,.0f}t' for r in last[-2:])}) — 속도·강종 순서 확인", 'integrated.html', '생산기획')
    if R2:
        t0 = (R2.get('replan') or {}).get('t0') or today
        lim = (D(t0) + dt.timedelta(days=3)).isoformat()
        tight = [r for r in R2['rows'] if t0 < r[0] <= lim and (D(r[5]) - D(r[0])).days <= 1]
        if sum(f(r[4]) for r in tight) >= 300:
            add('warn', '도금', f'앞으로 3일 안에 납기 1일 이내로 만드는 물량 {sum(f(r[4]) for r in tight):,.0f}t ({len(tight)}건) — 정지·지연 시 바로 납기 지연', 'status.html', '생산기획')
    # 컬러
    if ca:
        M = {x['line']: x for x in ca['month']['rows']}
        nb = min(12, max(0, len(ca['weekly']) - 1))                          # 비교 기준 주 수(자료가 짧으면 4주 미만 → 주간 비교 생략)
        for x in ca['lines']:
            d = (x['w1']['tpd'] / x['w0']['tpd'] - 1) * 100 if x['w0']['tpd'] and nb >= 4 else None
            m = M.get(x['line'])
            r = m['actual'] / m['sched'] * 100 if m and m.get('sched') else None
            if (d is not None and d <= -20) or (r is not None and r < 95):
                add('warn', '컬러', f"{x['line']} 지난주 {x['w1']['tpd']:,.0f}t/일" + (f'({nb}주 대비 {d:+.0f}%)' if d is not None else '') + (f', 이번 달 일정 대비 {r:.0f}%' if r is not None else '') + f" · 휴지 {x['w1']['stopH']:.1f}h/가동일", 'color_actual.html', '생산기획')
    # 소재
    if pr_sum:
        soon = [x for x in pr_sum.get('nearTop', []) if (D(x['deadline']) - D(today)).days <= 3]
        for x in soon[:3]:
            add('bad' if x['deadline'] <= today else 'warn', '소재', f"{x['mat']} {x['first'][5:]} 필요분 {x['t']:,}t — 1순위 {x['sup']} 발주 시한 {x['deadline'][5:]}", 'procure.html', '구매')
        if pr_sum.get('check'):
            add('warn', '소재', f"2~4주 안 리드타임 안쪽 부족 {pr_sum['check']}건 — 기발주 확인(입고예정 입력)", 'procure.html', '구매')
    # 재고
    for s in stock_rows or []:
        if s.get('target'):
            r = s['current'] / s['target']
            if r > 1.3 or r < 0.7:
                add('warn' if r < 1.6 else 'bad', '재고', f"{s['name']} {s['current']:,.0f}t — 목표 {s['target']:,.0f}t의 {r * 100:.0f}%", 'report.html', '판매·생산기획')
    order = {'bad': 0, 'warn': 1}
    E.sort(key=lambda e: order.get(e['lvl'], 2))
    return E


# ------------------------------------------------------------------ 자료 상태
def status(T, coils, auto, pages, run_at):
    def last_of(name, key):
        rs = T.get(name)
        if not rs:
            return None
        i = rs['columns'].index(key) if key in rs['columns'] else None
        v = [str(r[i])[:10] for r in rs['rows'] if i is not None and r[i]]
        return max(v) if v else None
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    feeds = [
        {'name': '도금 생산 실적(코일)', 'last': max((str(c['day']) for c in coils), default=None), 'n': len(coils or [])},
        {'name': '컬러 생산 실적', 'last': last_of('color_prod', 'PRD_DT'), 'n': len((T.get('color_prod') or {}).get('rows', []))},
        {'name': '판매생산속보(진도·재고)', 'last': (SR or {}).get('asOf', '')[:10] or None},
        {'name': '출하', 'last': last_of('ship', 'OUT_DT')},
        {'name': '소재재고List(컬러)', 'last': last_of('snap_mat_stock_cc', '입고일')},
        {'name': '재고현황(월말)', 'last': (lambda m: f'{m[:4]}-{m[4:]}' if m else None)(max((str(r[0]) for r in (T.get('snap_stock') or {}).get('rows', [])), default=None))},
    ]
    return {'app': 'cgl-status', 'runAt': run_at, 'ok': True, 'auto': {k: auto.get(k) for k in ('actualTo', 'replanned', 'optimal', 'notes', 'newCoils')} if auto else None,
            'feeds': feeds, 'pages': pages}


# ------------------------------------------------------------------ 전체
def groups(T, coils, SR, gpd, g_last, R2=None):
    """마케팅 그룹별 이번 달 생산(월 계획·실적)과 출하(판매생산속보 월차·일정누계·실적).
    날짜까지의 계획 누계는 넣지 않음 — 계획 모델은 마감일만 지키면 부서를 어느 날 만들지 임의라 그룹별 일자 비교는 의미가 없음.
    대신 after = 실적 다음 날부터 이달 말까지 남은 계획(도금 = 최신 재계획 R2, 없으면 확정 계획 / 컬러 = 편성) → 월말 예상 = 실적 + after
    생산 실적: 도금 = MES 코일(더미 제외) 판매그룹, 컬러 = MES 컬러 생산 DEPT. 계획: 도금 = 확정 V1 일별, 컬러 = 통합 계획 편성"""
    cp = T.get('color_prod')
    c_last = max((r[cp['columns'].index('PRD_DT')] for r in cp['rows']), default=None) if cp and cp['rows'] else None
    act = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy') and g_last and str(c['day'])[:7] == g_last[:7] and str(c['day']) <= g_last:
            g = COIL_GROUP.get(c.get('dept'))
            if g:
                act[g] += f(c['t'])
    if cp and c_last:
        I = cp['columns'].index
        if 'DEPT' in cp['columns']:
            for r in cp['rows']:
                g = CPROD_GROUP.get(r[I('DEPT')])
                if g and r[I('PRD_DT')][:7] == c_last[:7] and r[I('PRD_DT')] <= c_last:
                    act[g] += f(r[I('PDT_WGT')]) / 1000
    ship = {SHIP_GROUP[x['name']]: x for x in (SR or {}).get('ship', []) if x['name'] in SHIP_GROUP}
    out = []
    for key, name, pl in GROUPS:
        last = g_last if pl == 'G' else c_last
        if not last:
            continue
        m = last[:7]
        mon = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m)
        if pl == 'G' and R2 and R2.get('rows'):
            after = sum(f(r[4]) for r in R2['rows'] if last < r[0] and r[0][:7] == m and PLAN_GROUP.get(r[3]) == key)
            src = '재계획'
        else:
            after = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m and k[:10] > last)
            src = '확정 계획' if pl == 'G' else '편성'
        sh = ship.get(key)
        if not mon and not act[key] and not sh:
            continue
        out.append({'key': key, 'name': name, 'pl': pl, 'prod': {'asOf': last, 'month': round(mon), 'actual': round(act[key]), 'after': round(after), 'afterSrc': src},
                    'ship': {'asOf': (SR or {}).get('asOf'), 'month': round(sh['month']), 'sched': round(sh['sched']), 'actual': round(sh['actual'])} if sh else None})
    return out


def lines_now(T, coils, SR, R2, g_last):
    """라인 타일: 판매생산속보 월차·일정누계·실적누계(공식) + 최근 14일 일 생산(MES) + 도금 현재 강종·다음 전환(최신 계획)"""
    prod = {x['line']: x for x in (SR or {}).get('prod', []) if x['line'] in ('1CGL', '2CGL') + tuple(CCL)}
    day, fam = defaultdict(float), defaultdict(lambda: defaultdict(float))
    for c in coils or []:
        if not c.get('dummy'):
            day[(str(c['day']), c['line'])] += f(c['t'])
            if str(c['day']) == g_last:
                fam[c['line']][c.get('fam')] += f(c['t'])
    cp = T.get('color_prod')
    c_last = None
    if cp and cp['rows']:
        I = cp['columns'].index
        c_last = max(r[I('PRD_DT')] for r in cp['rows'])
        for r in cp['rows']:
            day[(r[I('PRD_DT')], r[I('LINE')])] += f(r[I('PDT_WGT')]) / 1000
    nxt = {}
    for c in sorted((R2 or {}).get('cal', []), key=lambda c: c['date']):
        ev = str(c.get('event') or '')
        if g_last and c['date'] > g_last and c['line'] not in nxt and ('M/C' in ev or 'S/D' in ev or '정기' in ev):
            nxt[c['line']] = [c['date'], ev.split(' · ')[0]]
    out = []
    for l in ('1CGL', '2CGL') + tuple(CCL):
        last = g_last if l.endswith('CGL') else c_last
        if not last:
            continue
        ds = [(D(last) - dt.timedelta(days=i)).isoformat() for i in range(13, -1, -1)]
        x = prod.get(l) or {}
        fm = fam.get(l)
        out.append({'line': l, 'pl': 'G' if l.endswith('CGL') else 'C', 'asOf': last, 'month': x.get('month'), 'sched': x.get('sched'), 'actual': x.get('actual'),
                    'tph': x.get('tph'), 'days': [[d, round(day[(d, l)])] for d in ds],
                    'fam': max(fm, key=fm.get) if fm else None, 'next': nxt.get(l)})
    return out


WO_LINE_G = {'A': '1CGL', 'B': '2CGL'}
WO_LINE_C = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}


def work_orders(T, coils, R2, g_last):
    """MES 작업지시 vs 최신 계획.
    도금(SSCH.PF_CG_WORK_FIN): 미완료 지시 코일의 강종 = 생산번호 셋째 글자(지난 코일 기록에서 글자→강종을 매일 다시 뽑음),
      톤 = 최근 코일 평균 무게로 추정. 계획의 다음 3일 강종에 없는 강종이 대기 중이면 '불일치'.
    컬러(SSCH.PF_CC_WORK_ORD): 라인별 앞으로 7일 작업 예정 톤(지시 예정 중량, kg)과 확정 비율"""
    out = {}
    wg = _rows(T, 'snap_wo_cg')
    if wg and coils:
        key = defaultdict(Counter)
        wt = defaultdict(list)
        for c in coils:
            p_ = str(c.get('prd') or '')
            if len(p_) >= 3 and c.get('alloy'):
                key[p_[2]][c['alloy']] += 1
            if not c.get('dummy') and c.get('alloy'):
                wt[(c['line'], c['alloy'])].append(f(c['t']))
        k2a = {k: v.most_common(1)[0][0] for k, v in key.items()}
        fam_of = lambda a: 'AL' if a in ('AL', 'AL-STS', 'AL-LG') else a
        cal = {(c['date'], c['line']): c.get('fam') for c in (R2 or {}).get('cal', [])}
        lines = []
        for code, l in WO_LINE_G.items():
            pend = [w for w in wg if w['LINE_CLS'] == code and w['FIN_YN'] != 'Y']
            q = Counter()
            for w in pend:
                q[k2a.get(str(w['PRD_NO'] or '')[2:3], '?')] += 1
            tons = {a: round(n * (sum(wt[(l, a)][-200:]) / len(wt[(l, a)][-200:]) if wt[(l, a)] else 0)) for a, n in q.items()}
            nxt = [(D(g_last) + dt.timedelta(days=i)).isoformat() for i in (1, 2, 3)] if g_last else []
            plan = [[d, cal.get((d, l))] for d in nxt]
            pf = {x[1] for x in plan if x[1]}
            bad = sorted({fam_of(a) for a in q if a != '?' and fam_of(a) not in pf}) if pf else []
            ds = sorted({w['WRK_DRT_DT'] for w in pend})
            lines.append({'line': l, 'coils': len(pend), 'byAlloy': [[a, n, tons.get(a, 0)] for a, n in q.most_common()],
                          'issued': [ds[0], ds[-1]] if ds else None, 'plan': plan, 'mismatch': bad})
        out['plating'] = {'asOf': max((w['WRK_DRT_DT'] for w in wg), default=None), 'lines': lines, 'keyMap': k2a}
    wc = _rows(T, 'snap_wo_cc')
    if wc:
        base = max(str(w['WRK_DRT_DT']) for w in wc)
        d0 = D(f'{base[:4]}-{base[4:6]}-{base[6:]}')
        days = [(d0 + dt.timedelta(days=i)).strftime('%Y%m%d') for i in range(7)]
        lines = []
        for code, l in WO_LINE_C.items():
            rows = [w for w in wc if w['WRK_DRT_LINE'] == code]
            by = [round(sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows if str(w['WRK_SCHE_DT']) == d) / 1000) for d in days]
            conf = sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows if w['WRK_DRT_CONF'] == 'Y'); tot = sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows)
            last = max((str(w['WRK_SCHE_DT']) for w in rows if w['WRK_SCHE_DT']), default=None)
            lines.append({'line': l, 'days': by, 'confRate': round(conf / tot, 2) if tot else None, 'until': f'{last[:4]}-{last[4:6]}-{last[6:]}' if last else None})
        out['color'] = {'days': [f'{d[:4]}-{d[4:6]}-{d[6:]}' for d in days], 'lines': lines}
    return out or None


def build_all(T, coils, R_prev, R2, auto=None, hist=None, today=None, run_at=None, stops=None):
    run_at = run_at or dt.datetime.now(dt.timezone.utc).isoformat(timespec='minutes')
    today = today or (dt.datetime.utcnow() + dt.timedelta(hours=9)).date().isoformat()
    ca = color_actual(T)
    ga = plating_actual(T, coils, stops)
    pr = procure(T, coils, today)
    pb = load_base('portal_base.json') or {}
    data_last = max((str(c['day']) for c in coils), default=None) if coils else (ca or {}).get('asOf')
    hist = accuracy(list(hist or pb.get('accHist', [])), R_prev, coils, data_last or today)
    acc = accuracy_summary(hist)
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    pr_all = procure_summary(pr) if pr else None
    portal = dict(pb.get('static', {}))
    portal.update({'built': dt.datetime.now().isoformat(timespec='minutes'), 'asOf': data_last, 'today': today,
                   'procure': pr_all, 'procureBy': {'G': procure_summary(pr, 'G'), 'C': procure_summary(pr, 'C')} if pr else None,
                   'acc': acc, 'exceptions': exceptions(today, ca, pr_all, R2, acc, (SR or {}).get('stock'), data_last),
                   'colorNow': {'month': ca['month'], 'w1': ca['w1'], 'tpd': [round(x['w1']['tpd']) for x in ca['lines']], 'tpd0': [round(x['w0']['tpd']) for x in ca['lines']]} if ca else None})
    if R2:                                                     # 최신 계획 기준 빠듯함·계획 대비 실적
        t0 = (R2.get('replan') or {}).get('t0') or data_last or today
        tight = [r for r in R2['rows'] if r[0] > t0 and (D(r[5]) - D(r[0])).days <= 2]
        pl = portal.setdefault('plating', {})
        pl.update({'tightN': len(tight), 'tightT': round(sum(f(r[4]) for r in tight)), 'slack': {k: round(v) for k, v in (R2.get('slack') or {}).items()}})
        rp = R2.get('replan') or {}
        pl['now'] = {'t0': rp.get('t0'), 'short': round(f((R2.get('milp') or {}).get('short'))), 'late': round(f(rp.get('late'))),
                     'shortBy': (rp.get('shortBy') or [])[:5], 'lockNotes': rp.get('lockNotes') or [], 'proposal': rp.get('proposal')}
    base_plan = pb.get('basePlanDaily') or {}                  # 확정 계획(V1) 일별 — 계획 대비 실적 누계
    if base_plan and coils:
        ad = coil_daily(coils)
        q0 = pb.get('q0', '2026-10-01')
        act = sum(v for (d, l), v in ad.items() if q0 <= d <= data_last)
        pln = sum(v for k, v in base_plan.items() if q0 <= k.split('|')[0] <= data_last)
        portal['roll'] = {'asOf': data_last, 'actual': round(act), 'plan': round(pln)}
    portal['lines'] = lines_now(T, coils, SR, R2, data_last if coils else None)
    portal['wo'] = work_orders(T, coils, R2, data_last if coils else None)
    for x in ((portal['wo'] or {}).get('plating') or {}).get('lines', []):
        if x['mismatch']:
            portal['exceptions'].insert(0, {'lvl': 'warn', 'area': '도금', 'text': f"{x['line']} 현장 작업지시에 {'·'.join(x['mismatch'])} 대기 — 계획의 다음 3일 강종({'·'.join(sorted({p[1] for p in x['plan'] if p[1]}))})과 다름. 강종 순서·M/C 날짜 확인", 'link': 'status.html', 'who': '생산기획'})
    if R2 and R2.get('rows'):                                  # 월별 도금 계획 = 최신 계획(지난 날은 실적 + 앞으로는 재계획), 라인별
        ms_ = portal.get('months') or sorted({r[0][:7] for r in R2['rows']})
        portal['planMonth'] = {'src': '최신 재계획 ' + str((R2.get('replan') or {}).get('t0') or ''), 'months': ms_,
                               'g1': [round(sum(f(r[4]) for r in R2['rows'] if r[1] == '1CGL' and r[0][:7] == m)) for m in ms_],
                               'g2': [round(sum(f(r[4]) for r in R2['rows'] if r[1] == '2CGL' and r[0][:7] == m)) for m in ms_]}
    portal['sr'] = {'asOf': SR['asOf'], 'ship': SR['ship'], 'stock': [{k: x[k] for k in ('name', 'target', 'current')} for x in SR['stock']]} if SR else None
    if pb.get('groupPlanDaily'):
        portal['groups'] = groups(T, coils, SR, pb['groupPlanDaily'], data_last if coils else None, R2)
        portal['colorPlanFrom'] = pb.get('colorPlanFrom')
    try:
        from . import planstock as PS
        ps = PS.build(T, today)
        if ps:
            ps['built'] = dt.datetime.now().isoformat(timespec='minutes')
            nf = ps['flags'].get('short', 0) + ps['flags'].get('low', 0)
            if nf:
                portal['exceptions'].append({'lvl': 'warn', 'area': '컬러', 'text': f"계획재 {nf}개 사양 이번 달 말 결품·안전재고 아래 예상 (재고 {round(ps['tot']['stock']):,}t, 목표 {round(ps['tot']['target']):,}t)", 'link': 'planstock.html', 'who': '컬러건재'})
            portal['planstock'] = {'stock': round(ps['tot']['stock']), 'target': round(ps['tot']['target']), 'end': round(ps['tot']['end'][0]) if ps['tot']['end'] else None, 'flags': ps['flags']}
    except Exception as e:                                     # 계획재 화면 실패는 다른 화면에 영향 없음
        ps = None
        print('계획재 분석 실패:', e)
    try:
        from . import color_cond as CC
        cc = CC.build(T)
    except Exception as e:
        cc = None
        print('컬러 조건 분석 실패:', e)
    pages = {'color_actual': ca['asOf'] if ca else None, 'plating_actual': ga['asOf'] if ga else None, 'procure': today if pr else None, 'portal': data_last}
    st = status(T, coils, auto or {}, pages, run_at)
    return {'color_actual': ca, 'plating_actual': ga, 'procure': pr, 'portal': portal, 'status': st, 'accHist': hist, 'planstock': ps, 'color_cond': cc}


def publish(cfg, sb, dry, T, coils, R_prev, R2, auto, log, encrypt, stops=None):
    """auto.run 5-5단계: 계산 → 암호화 게시(status.json 은 평문). 실패해도 계획 게시에는 영향 없음"""
    hp = os.path.join(cfg['out_dir'], 'acc_hist.json')
    hist = json.load(open(hp, encoding='utf-8')) if os.path.exists(hp) else None
    O = build_all(T, coils, R_prev, R2, auto, hist, run_at=auto.get('runAt'), stops=stops)
    json.dump(O['accHist'], open(hp, 'w', encoding='utf-8'), ensure_ascii=False)
    pw = cfg.get('analysis_password') or cfg['password']
    pre = 'test.' if cfg['published_path'].startswith('test') else ''
    done = []
    for name, label in (('color_actual', '컬러 실적'), ('plating_actual', '도금 실적'), ('procure', '소재 조달 판단'), ('portal', '포털 요약'), ('planstock', '계획재 분석'), ('color_cond', '컬러 조건 분석')):
        if not O[name]:
            continue
        body = json.dumps(encrypt(O[name], pw, label))
        path = f'{pre}{name}.enc.json'
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(body)
        else:
            sb.upload(cfg['published_bucket'], path, body, cache='60')
        done.append(path)
    stj = json.dumps(O['status'], ensure_ascii=False)
    if dry:
        open(os.path.join(cfg['out_dir'], pre + 'status.json'), 'w', encoding='utf-8').write(stj)
    else:
        sb.upload(cfg['published_bucket'], pre + 'status.json', stj, cache='60')
    log(f"화면 자료 게시: {', '.join(done)}, {pre}status.json · 오늘 볼 것 {len(O['portal'].get('exceptions', []))}건")
    return O
