"""MES 코일 실적 누적 저장(SQLite 파일 1개). 매일 이번 달분을 받아도 제품번호 기준으로 중복 없이 쌓인다."""
import csv
import io
import sqlite3

COLS = ['id', 'line', 'day', 's', 'e', 'work', 'stop', 'run', 't', 'thick', 'width', 'pname', 'dept', 'fam', 'cls', 'dummy', 'grade', 'prd', 'alloy']
SCOLS = ['line', 'prd', 's', 'e', 't', 'cls', 'cd', 'nm', 'dtl']
_TYPES = {'s': 'INTEGER', 'e': 'INTEGER', 'work': 'REAL', 'stop': 'REAL', 'run': 'REAL', 't': 'REAL', 'thick': 'REAL', 'width': 'REAL', 'dummy': 'INTEGER'}


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS coils (' + ', '.join(f"{c} {_TYPES.get(c, 'TEXT')}{' PRIMARY KEY' if c == 'id' else ''}" for c in COLS) + ')')
        have = [r[1] for r in self.db.execute('PRAGMA table_info(coils)')]
        for c in COLS:                                   # 예전 저장 파일에 새 열 추가
            if c not in have:
                self.db.execute(f"ALTER TABLE coils ADD COLUMN {c} {_TYPES.get(c, 'TEXT')}")
        self.db.execute('CREATE TABLE IF NOT EXISTS stops (line TEXT, prd TEXT, s INTEGER, e INTEGER, t REAL, cls TEXT, cd TEXT, nm TEXT, dtl TEXT, PRIMARY KEY (line, s, e))')
        self.db.execute('CREATE TABLE IF NOT EXISTS runs (at TEXT, ok INTEGER, note TEXT)')
        self.db.commit()

    def upsert(self, coils):
        """반환: (새 코일 수, 바뀐 코일 수)"""
        cur = self.db.cursor()
        new = chg = 0
        for c in coils:
            row = [c.get(k, '') if k != 'dummy' else int(bool(c[k])) for k in COLS]
            row = [None if isinstance(v, float) and v != v else v for v in row]     # NaN → NULL
            old = cur.execute('SELECT ' + ','.join(COLS) + ' FROM coils WHERE id=?', (c['id'],)).fetchone()
            if old is None:
                new += 1
            elif list(old) != row:
                chg += 1
            else:
                continue
            cur.execute('INSERT OR REPLACE INTO coils VALUES (' + ','.join('?' * len(COLS)) + ')', row)
        self.db.commit()
        return new, chg

    def upsert_stops(self, stops):
        n = 0
        for x in stops:
            cur = self.db.execute('SELECT 1 FROM stops WHERE line=? AND s=? AND e=?', (x['line'], x['s'], x['e'])).fetchone()
            self.db.execute('INSERT OR REPLACE INTO stops VALUES (' + ','.join('?' * len(SCOLS)) + ')', [x[k] for k in SCOLS])
            n += cur is None
        self.db.commit()
        return n

    def stops(self, min_from=None):
        q = 'SELECT ' + ','.join(SCOLS) + ' FROM stops' + (' WHERE s >= ?' if min_from is not None else '') + ' ORDER BY line, s'
        return [dict(zip(SCOLS, r)) for r in self.db.execute(q, (min_from,) if min_from is not None else ())]

    def coils(self, day_from=None):
        q = 'SELECT ' + ','.join(COLS) + ' FROM coils' + (' WHERE day >= ?' if day_from else '') + ' ORDER BY line, s, e'
        out = []
        for r in self.db.execute(q, (day_from,) if day_from else ()):
            c = dict(zip(COLS, r))
            c['dummy'] = bool(c['dummy'])
            for k in ('thick', 'width'):
                if c[k] is None:
                    c[k] = float('nan')
            out.append(c)
        return out

    def last_day(self):
        r = self.db.execute('SELECT MAX(day) FROM coils').fetchone()
        return r[0] if r else None

    def log_run(self, at, ok, note):
        self.db.execute('INSERT INTO runs VALUES (?,?,?)', (at, int(ok), note))
        self.db.commit()

    def to_csv(self, day_from=None):
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(COLS)
        for c in self.coils(day_from):
            w.writerow(['' if (isinstance(c[k], float) and c[k] != c[k]) else (int(c[k]) if k == 'dummy' else c[k]) for k in COLS])
        return buf.getvalue()
