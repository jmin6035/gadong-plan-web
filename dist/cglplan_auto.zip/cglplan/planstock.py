"""계획재(R15 TF 운영안 187 사양) 분석·예측 — 화면 planstock.html 자료(planstock.enc.json)

기준: pages_base/planstock_base.json (tools/r15_base.py, R15 '운영안'·'일자별상세내역')
매일: MES 컬러 생산(color_prod)·출하(ship)·월말 재고(snap_stock)

사양 연결(R15 '제품재고' 정의 재현): 컬러건재판매그룹, '두께 폭 상도색상' — 재고는 표기값 일치, 생산은 실측 두께 ±0.03mm 최근접.
현재 재고 = 최근 월말 재고(MES) + 그 뒤 생산 − 그 뒤 출하(출하 코일번호를 월말 재고·생산 코일과 이어 사양 판정).
월말 예상 = 현재 재고 + 남은 생산 계획(R15 월 생산 − 이번 달 실적, 0 미만은 0) − 남은 판매 예측(R15 월 예측 − 이번 달 출하, 0 미만은 0).
판매 진도는 직선이 아니라 지난 3개월 계획재 사양 출하의 월중 누적 비율(월말 몰림)로 본다.
"""
import calendar
import datetime as dt
from collections import Counter, defaultdict

from . import pages as PG

TOL_T, TOL_W = 0.03, 1.0
DEPT = '컬러건재'


def f(x):
    return PG.f(x)


class _M:
    """R15 정의: 사양 = '두께 폭 상도색상'(품명 무관), 컬러건재판매그룹 재고. 재고는 표기 두께·폭 일치,
    생산 실적은 실측 두께라 폭·색상 일치 + 두께 ±0.03mm 안에서 가장 가까운 사양"""
    def __init__(self, specs):
        self.idx = defaultdict(list)
        for i, s in enumerate(specs):
            self.idx[s['color']].append((i, s))

    def __call__(self, thk, wdt, color, tolt=TOL_T):
        best = None
        for i, s in self.idx.get(str(color or ''), []):
            d = abs(s['thk'] - thk)
            if abs(s['wdt'] - wdt) <= TOL_W and d <= tolt + 1e-9 and (best is None or d < best[0]):
                best = (d, i)
        return best[1] if best else None


def _ym(d):
    return str(d)[:7]


def _days(ym):
    y, m = map(int, ym.split('-'))
    return calendar.monthrange(y, m)[1]


def build(T, today=None, base=None):
    base = base or PG.load_base('planstock_base.json')
    if not base or not T.get('color_prod') or not T.get('snap_stock'):
        return None
    S = base['specs']
    n = len(S)
    m = _M(S)
    # ---- 코일 → 사양: 월말 재고(전 기간) + 생산 실적
    coil = {}
    stock_m = defaultdict(Counter)                                       # 월(YYYYMM) → 사양 → t
    for r in PG._rows(T, 'snap_stock'):
        if r['공장구분'] != 'C' or r['구분명'] != 'P' or not str(r.get('담당부서(HR)') or '').startswith(DEPT):
            continue
        i = m(f(r['제품두께']), f(r['제품폭']), r['표면상도코드'], 0.005)
        if i is None:
            continue
        coil[str(r['소재제품번호'])] = i
        stock_m[str(r['_기준월'])][i] += f(r['중량']) / 1000
    prod = defaultdict(Counter)                                          # 일자 → 사양 → t
    for r in PG._rows(T, 'color_prod'):
        if not str(r.get('DEPT') or '').startswith(DEPT):
            continue
        i = m(f(r['REAL_MSR_THK']), f(r['PDT_WDT']), r['SUR_FINISH_CD'])
        if i is None:
            continue
        coil[str(r['PDT_NO'])] = i
        prod[str(r['PRD_DT'])[:10]][i] += f(r['PDT_WGT']) / 1000
    ship = defaultdict(Counter)                                          # 일자 → 사양 → t (컬러 공장 출하 전체: 판매·이송)
    for r in PG._rows(T, 'ship'):
        if r['PLT_CLS'] != 'C':
            continue
        i = coil.get(str(r['PDT_NO']))
        if i is not None:
            ship[str(r['OUT_DT'])[:10]][i] += f(r['WGT']) / 1000
    last = max(max(prod, default=''), max(ship, default=''))
    if not last:
        return None
    today = today or last
    m0 = max(stock_m)                                                    # 최근 월말 재고 (예: 202609 = 9월말)
    d0 = dt.date(int(m0[:4]), int(m0[4:]), 1) + dt.timedelta(days=_days(f'{m0[:4]}-{m0[4:]}'))   # 그다음 날 (10/1)
    cur_ym = _ym(last)
    # ---- 월중 출하 누적 비율(지난 3개월, 계획재 사양): 일자 → 그 날까지 누적 비중
    hist = Counter()
    hm = sorted({_ym(d) for d in ship if _ym(d) < cur_ym})[-3:]
    for d, c in ship.items():
        if _ym(d) in hm:
            hist[int(d[8:10])] += sum(c.values())
    tot = sum(hist.values()) or 1.0
    cum, acc = [], 0.0
    for day in range(1, 32):
        acc += hist[day]
        cum.append(acc / tot)
    nd = _days(cur_ym)
    dlast = int(last[8:10])
    pace = cum[dlast - 1] if dlast < nd else 1.0                        # 이번 달 이 날까지 보통 나가는 비중
    # ---- 사양별 집계
    ms = base['months']
    mi = ms.index(cur_ym) if cur_ym in ms else None
    since = d0.isoformat()
    p_since = Counter(); s_since = Counter(); p_mon = Counter(); s_mon = Counter()
    for d, c in prod.items():
        for i, t in c.items():
            if d >= since:
                p_since[i] += t
            if _ym(d) == cur_ym:
                p_mon[i] += t
    for d, c in ship.items():
        for i, t in c.items():
            if d >= since:
                s_since[i] += t
            if _ym(d) == cur_ym:
                s_mon[i] += t
    st0 = stock_m[m0]
    rows = []
    for i, s in enumerate(S):
        cur = st0[i] + p_since[i] - s_since[i]
        r = {'i': i, 'stock0Mes': round(st0[i], 1), 'prodM': round(p_mon[i], 1), 'shipM': round(s_mon[i], 1), 'stock': round(cur, 1)}
        if mi is not None:
            plan_due = sum(t for d, t in s['sched'] if d <= last)        # 오늘까지 만들었어야 할 양(펼친 일정)
            r['planDue'] = round(plan_due, 1)
            r['planM'] = s['prod'][mi]
            r['fcM'] = s['fc'][mi]
            e, ends = cur, []
            for k in range(mi, len(ms)):
                if k == mi:
                    e += max(0.0, s['prod'][k] - p_mon[i]) - max(0.0, s['fc'][k] - s_mon[i])
                else:
                    e += s['prod'][k] - s['fc'][k]
                ends.append(round(e, 1))
            r['end'] = ends                                              # 이번 달 ~ 3월 월말 예상
            daily = (s['fc'][mi] or s['sale']) / 30.0
            r['cover'] = round(cur / daily, 1) if daily > 0 else None
            flags = []
            if ends[0] < -1:
                flags.append('short')                                    # 이번 달 말 결품 예상
            elif ends[0] < s['safe'] - 0.5:
                flags.append('low')                                      # 안전재고 아래
            if any(x < -1 for x in ends[1:3]):
                flags.append('shortNext')
            if s['target'] > 0 and ends[0] > 2 * s['target'] and ends[0] - s['target'] >= 10:
                flags.append('over')                                     # 목표의 2배 초과
            if plan_due - p_mon[i] >= max(5.0, 0.3 * plan_due):
                flags.append('behind')                                   # 일정 대비 30%·5t 이상 덜 만듦
            if s['fc'][mi] >= 5 and dlast >= 10:
                exp = s['fc'][mi] * pace
                if s_mon[i] > 1.5 * exp + 5:
                    flags.append('fcHigh')                               # 예측보다 빨리 나감
            r['flags'] = flags
        rows.append(r)
    # ---- 합계·일별 추이(계획재 전체)
    def tsum(key, k=None):
        return round(sum((r[key][k] if k is not None else r[key]) for r in rows if key in r), 1)
    days_seq = []
    d = d0
    while d.isoformat() <= last:
        days_seq.append(d.isoformat())
        d += dt.timedelta(days=1)
    stock_line, s_acc = [], sum(st0.values())
    for d in days_seq:
        s_acc += sum(prod[d].values()) - sum(ship[d].values())
        stock_line.append(round(s_acc, 1))
    # 앞으로(이번 달 말까지) 예상: 펼친 일정 생산 − 예측 판매(월중 누적 비율 배분)
    fut = []
    if mi is not None:
        sched_day = Counter()
        for s in S:
            for dd, t in s['sched']:
                if _ym(dd) == cur_ym:
                    sched_day[int(dd[8:10])] += t
        left_p = sum(max(0.0, s['prod'][mi] - p_mon[i]) for i, s in enumerate(S))
        sch_left = sum(v for k, v in sched_day.items() if k > dlast) or 1.0
        left_s = sum(max(0.0, s['fc'][mi] - s_mon[i]) for i, s in enumerate(S))
        rem = (1.0 - pace) or 1.0
        e = s_acc
        for day in range(dlast + 1, nd + 1):
            e += left_p * sched_day[day] / sch_left - left_s * (cum[day - 1] - cum[day - 2]) / rem
            fut.append([f'{cur_ym}-{day:02d}', round(e, 1)])
    by = defaultdict(lambda: Counter())
    for r in rows:
        s = S[r['i']]
        for key in (s['mat'], s['use'] or '기타'):
            pass
        by[('mat', s['mat'])]['stock'] += r['stock']; by[('mat', s['mat'])]['target'] += s['target']
        by[('mat', s['mat'])]['n'] += 1
        if mi is not None:
            by[('mat', s['mat'])]['end'] += r['end'][0]; by[('mat', s['mat'])]['fcM'] += s['fc'][mi]
            by[('mat', s['mat'])]['shipM'] += r['shipM']; by[('mat', s['mat'])]['prodM'] += r['prodM']
            by[('mat', s['mat'])]['planM'] += s['prod'][mi]
    fl = Counter(x for r in rows for x in r.get('flags', []))
    out = {
        'src': base['src'], 'asOf': last, 'today': today, 'stockMonth': m0, 'month': cur_ym, 'months': ms, 'pace': round(pace, 3),
        'paceFrom': hm, 'n': n,
        'specs': [{k: s[k] for k in ('product', 'kind', 'owner', 'use', 'spec', 'mat', 'eoq', 'sale', 'safe', 'target', 'stock0', 'fc', 'prod', 'test')} for s in S],
        'rows': rows,
        'tot': {'stock0R15': round(sum(s['stock0'] for s in S), 1), 'stock0Mes': round(sum(st0.values()), 1), 'stock': tsum('stock'),
                'prodM': tsum('prodM'), 'shipM': tsum('shipM'), 'planDue': tsum('planDue'), 'planM': tsum('planM'), 'fcM': tsum('fcM'),
                'target': round(sum(s['target'] for s in S), 1), 'safe': round(sum(s['safe'] for s in S), 1),
                'end': [round(sum(r['end'][k] for r in rows), 1) for k in range(len(rows[0].get('end', [])))],
                'fc': [round(sum(s['fc'][k] for s in S), 1) for k in range(len(ms))],
                'prod': [round(sum(s['prod'][k] for s in S), 1) for k in range(len(ms))]},
        'flags': dict(fl),
        'byMat': [{'mat': k[1], **{a: round(v, 1) for a, v in c.items()}} for k, c in sorted(by.items(), key=lambda kv: -kv[1]['stock'])],
        'daily': {'days': days_seq, 'stock': stock_line, 'prod': [round(sum(prod[d].values()), 1) for d in days_seq],
                  'ship': [round(sum(ship[d].values()), 1) for d in days_seq], 'future': fut},
        'shipHist': {ym: round(sum(sum(c.values()) for d, c in ship.items() if _ym(d) == ym), 1) for ym in sorted({_ym(d) for d in ship})[-4:]},
        'prodHist': {ym: round(sum(sum(c.values()) for d, c in prod.items() if _ym(d) == ym), 1) for ym in sorted({_ym(d) for d in prod})[-4:]},
    }
    return out
