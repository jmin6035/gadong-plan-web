"""사내 서버 초안(FastAPI). 실행: gadong-plan/ 에서
    pip install fastapi uvicorn python-multipart
    python -m uvicorn cglplan.server:app --host 0.0.0.0 --port 8000
- /                        대시보드(web/index.html), /plan.html 계획 화면 — 웹 정적 파일을 그대로 제공
- /published/latest.plan.enc.json  최신 결과(평문). 대시보드가 이 주소를 읽으므로 사내망에서는 암호 없이 바로 열림
- POST /api/plan           판매계획 엑셀 업로드 → 계산(백그라운드) → 최신 결과로 저장
- POST /api/replan         실적 엑셀 업로드(또는 JSON 사건) → 최신 결과 기준 재계획
- POST /api/mes/analyze    MES 실적 쿼리 엑셀 → 속도·손실·M/C 분석(최신 결과의 파라미터와 비교)
- POST /api/mes/actuals    MES 연동 자리: 실적 행 JSON → 재계획(아래 규격)
- GET  /api/jobs/{id}, /api/results, /api/results/{name}
인증은 사내 SSO/리버스 프록시에서 붙인다(이 초안에는 없음). 데이터는 CGL_DATA_DIR(기본 ./server_data)에 저장."""
import datetime as _dt
import io
import json
import os
import threading
import traceback
import uuid

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import openpyxl

from . import mes as MES, model, parse, publish, replan as RP, util as U

_HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('CGL_DATA_DIR', os.path.join(os.getcwd(), 'server_data'))
WEB = os.environ.get('CGL_WEB_DIR', os.path.normpath(os.path.join(_HERE, '..', '..', 'web')))
os.makedirs(os.path.join(DATA, 'history'), exist_ok=True)
LATEST = os.path.join(DATA, 'latest.json')

app = FastAPI(title='CGL 가동계획 서버', version='0.1')
JOBS, _lock = {}, threading.Lock()


def _save(envelope, kind):
    ts = _dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    path = os.path.join(DATA, 'history', f'{ts}_{kind}.json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(envelope, f, ensure_ascii=False)
    tmp = LATEST + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(envelope, f, ensure_ascii=False)
    os.replace(tmp, LATEST)          # 대시보드가 읽는 도중 깨진 파일을 보지 않도록 교체
    return os.path.basename(path)


def _latest():
    if not os.path.exists(LATEST):
        raise HTTPException(404, '아직 계산된 계획이 없습니다')
    with open(LATEST, encoding='utf-8') as f:
        return json.load(f)


def _run_job(kind, fn):
    jid = uuid.uuid4().hex[:12]
    job = {'id': jid, 'kind': kind, 'status': 'running', 'log': [], 'started': _dt.datetime.now().isoformat()}
    JOBS[jid] = job

    def work():
        with _lock:                  # 계산은 한 번에 하나씩
            try:
                env = fn(lambda m: job['log'].append(m))
                job['result'] = _save(env, kind)
                job['status'] = 'done'
            except Exception as e:
                job['status'] = 'error'
                job['error'] = str(e)
                job['trace'] = traceback.format_exc()[-2000:]
    threading.Thread(target=work, daemon=True).start()
    return {'job': jid}


@app.post('/api/plan')
async def api_plan(files: list[UploadFile] = File(...), params: str = Form(None)):
    blobs = [await f.read() for f in files]
    P = U.default_params()
    if params:
        P.update(json.loads(params))
    wbs = [openpyxl.load_workbook(io.BytesIO(b), data_only=True) for b in blobs]
    parsed = parse.parse_inputs(wbs, P)
    errs = [c for c in parsed['checks'] if c['level'] == 'error']
    if errs:
        raise HTTPException(400, {'checks': parsed['checks']})

    def fn(log):
        R = model.run_plan(parsed['items'], P, log)
        return publish.pack(R, {'asOf': parsed['asOf'], 'checks': parsed['checks']})
    return _run_job('plan', fn) | {'checks': parsed['checks']}


def _replan_opts(freeze, tradeoff, stab):
    return {'freezeDays': freeze, 'lateW': 1 / tradeoff, 'stabW': 1 / stab, 'stabW2': 5000 / stab}


@app.post('/api/replan')
async def api_replan(actual: UploadFile = File(None), t0: str = Form(None), events: str = Form(None),
                     freeze: int = Form(2), tradeoff: float = Form(100), stab: float = Form(10)):
    base = _latest()
    R, meta = base['result'], base.get('meta') or {}
    if actual is not None:
        wb = openpyxl.load_workbook(io.BytesIO(await actual.read()), data_only=True)
        tb = MES.tables(MES.sheets_from_workbooks([wb]))
        act = MES.actual_from_tables(tb, R, t0) if MES.is_mes_query(tb) else RP.parse_actual_workbook(wb, R, t0)
        if any(c['level'] == 'error' for c in act.get('checks', [])):
            raise HTTPException(400, {'checks': act['checks']})
    elif t0:
        act = RP.simulate_actuals(R, t0, json.loads(events) if events else [])
    else:
        raise HTTPException(400, 'actual(실적 엑셀) 또는 t0(+events)가 필요합니다')
    return _run_job('replan', lambda log: publish.pack(RP.replan(R, act, _replan_opts(freeze, tradeoff, stab), log), meta))


@app.post('/api/mes/analyze')
async def api_mes_analyze(files: list[UploadFile] = File(...)):
    P = _latest()['result']['P'] if os.path.exists(LATEST) else U.default_params()
    wbs = [openpyxl.load_workbook(io.BytesIO(await f.read()), read_only=True, data_only=True) for f in files]
    cl = MES.clean(MES.tables(MES.sheets_from_workbooks(wbs)))
    if any(c['level'] == 'error' for c in cl['checks']):
        raise HTTPException(400, {'checks': cl['checks']})
    an = MES.analyze(cl['coils'], P)
    return JSONResponse(json.loads(json.dumps(MES.summary(an, cl) | {'daily': an['daily'], 'checks': cl['checks']}, default=lambda x: None).replace('NaN', 'null')))


@app.post('/api/mes/actuals')
async def api_mes_actuals(body: dict):
    """MES 연동 규격(초안):
    {"t0": "2026-10-20",
     "rows": [{"date": "2026-10-20", "line": "2CGL", "alloy": "AL", "dept": "도금수출", "due": "2026-10-25", "tons": 812.4}, ...],
     "state": {"1CGL": "AZ", "2CGL": "AL"},            (선택: 기준일 마지막 강종)
     "downtime": [{"line": "2CGL", "from": "2026-10-22", "to": "2026-10-22", "minutes": 720}],   (선택: 예정 정지)
     "options": {"freeze": 2, "tradeoff": 100, "stab": 10}}
    due(마감일)는 주문번호→부서·납기 매핑으로 MES/ERP 쪽에서 채운다. 비우면 같은 부서·강종의 가장 이른 미완료 마감에 배정."""
    base = _latest()
    R, meta = base['result'], base.get('meta') or {}
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '실적'
    ws.append(['날짜', '라인', '세부강종', '부서', '마감일', '생산량(t)'])
    for r in body.get('rows', []):
        ws.append([r['date'], r['line'], r['alloy'], r['dept'], r.get('due') or None, r['tons']])
    w2 = wb.create_sheet('설비정지')
    w2.append(['라인', '시작일', '종료일', '분/일'])
    for x in body.get('downtime', []):
        w2.append([x['line'], x['from'], x.get('to') or x['from'], x.get('minutes')])
    w3 = wb.create_sheet('현재상태')
    w3.append(['라인', '강종'])
    for l, f in (body.get('state') or {}).items():
        w3.append([l, f])
    act = RP.parse_actual_workbook(wb, R, body.get('t0'))
    if any(c['level'] == 'error' for c in act.get('checks', [])):
        raise HTTPException(400, {'checks': act['checks']})
    o = body.get('options') or {}
    return _run_job('mes', lambda log: publish.pack(RP.replan(R, act, _replan_opts(o.get('freeze', 2), o.get('tradeoff', 100), o.get('stab', 10)), log), meta)) | {'checks': act['checks']}


@app.get('/api/jobs/{jid}')
def api_job(jid: str):
    j = JOBS.get(jid)
    if not j:
        raise HTTPException(404, '없는 작업')
    return {k: v for k, v in j.items() if k != 'trace'}


@app.get('/api/results')
def api_results():
    return sorted(os.listdir(os.path.join(DATA, 'history')), reverse=True)


@app.get('/api/results/{name}')
def api_result(name: str):
    p = os.path.join(DATA, 'history', os.path.basename(name))
    if not os.path.exists(p):
        raise HTTPException(404)
    return FileResponse(p, media_type='application/json')


@app.get('/published/latest.plan.enc.json')
def published_latest():
    """대시보드 기본 게시 위치 → 사내망에서는 평문 최신 결과를 준다(대시보드가 암호 없이 연다)"""
    return JSONResponse(_latest(), headers={'Cache-Control': 'no-store'})


if os.path.isdir(WEB):
    app.mount('/', StaticFiles(directory=WEB, html=True), name='web')
