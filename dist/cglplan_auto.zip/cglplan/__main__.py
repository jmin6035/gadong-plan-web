"""명령행 사용법 (gadong-plan/ 폴더에서):
  python -m cglplan plan   --input data/ctx_가동_판매자가재.xlsx [--input 배선일정.xlsx] [--params 조건.json] --out result.json
  python -m cglplan replan --base result.json --actual 실적입력.xlsx [--freeze 2] [--tradeoff 100] [--stab 10] --out replan.json
  python -m cglplan replan --base result.json --t0 2026-10-20 --events 사건.json --out replan.json   (시뮬레이션)
  python -m cglplan replan --base result.json --actual MES실적쿼리.xlsx --out replan.json   (MES 쿼리 엑셀도 자동 인식)
  python -m cglplan analyze --input MES실적쿼리.xlsx [--input 작업휴지.xlsx] [--params 조건.json] --out mes_summary.json   (속도·손실·M/C 재산출, 파라미터 후보)
  python -m cglplan auto --config auto_config.json [--dry] [--force]   (사내 PC 자동 실행: MES 엑셀 → 누적 → 재계획 → Supabase 게시)
  python -m cglplan supatest --config auto_config.json                 (Supabase 연결·키 확인)
  python -m cglplan publish --result result.json --config auto_config.json   (수동 계산 결과를 Supabase에 게시, 암호는 설정의 password)
  python -m cglplan publish --result result.json --password "..." [--label "..."] --out ../web/published/latest.plan.enc.json
결과 JSON은 웹 대시보드(index.html)와 계획 화면(plan.html)이 그대로 읽는 형식이다."""
import argparse
import json
import sys
import time

from . import parse, model, replan as RP, publish as PB, util as U, mes as MES


def _log():
    t0 = time.time()
    return lambda m: print(f'[{time.time() - t0:5.0f}s] {m}', flush=True)


def _load_result(path):
    o = json.load(open(path, encoding='utf-8'))
    return (o['result'], o.get('meta') or {}) if o.get('app') == 'cgl-plan' else (o, {})


def cmd_plan(a):
    P = U.default_params()
    if a.params:
        P.update(json.load(open(a.params, encoding='utf-8')))
    r = parse.parse_inputs(parse.load_workbooks(a.input), P)
    for c in r['checks']:
        print(f"  [{ {'error': '오류', 'warn': '경고', 'info': '정보'}[c['level']] }] {c['msg']}")
    if any(c['level'] == 'error' for c in r['checks']):
        sys.exit('입력 오류 — 계산 중단')
    R = model.run_plan(r['items'], P, _log(), threads=a.threads)
    json.dump(PB.pack(R, {'asOf': r['asOf'], 'checks': r['checks']}), open(a.out, 'w', encoding='utf-8'), ensure_ascii=False)
    print('저장:', a.out)


def cmd_replan(a):
    R, meta = _load_result(a.base)
    if a.actual:
        tb = MES.tables(MES.sheets_from_workbooks([a.actual]))
        act = MES.actual_from_tables(tb, R, a.t0) if MES.is_mes_query(tb) else RP.parse_actual_workbook(a.actual, R, a.t0)
        for c in act.get('checks', []):
            print(f"  [{c['level']}] {c['msg']}")
        if any(c['level'] == 'error' for c in act.get('checks', [])):
            sys.exit('실적 입력 오류 — 중단')
    else:
        if not a.t0:
            sys.exit('--actual 또는 --t0(+ --events) 필요')
        act = RP.simulate_actuals(R, a.t0, json.load(open(a.events, encoding='utf-8')) if a.events else [])
    R2 = RP.replan(R, act, {'freezeDays': a.freeze, 'lateW': 1 / a.tradeoff, 'stabW': 1 / a.stab, 'stabW2': 5000 / a.stab}, _log(), a.threads)
    json.dump(PB.pack(R2, meta), open(a.out, 'w', encoding='utf-8'), ensure_ascii=False)
    print('저장:', a.out)


def cmd_analyze(a):
    P = U.default_params()
    if a.params:
        P.update(json.load(open(a.params, encoding='utf-8')))
    cl, an = MES.from_files(a.input, P)
    for c in cl['checks']:
        print(f"  [{c['level']}] {c['msg']}")
    if an is None:
        sys.exit('실적 해석 오류 — 중단')
    for l, x in an['lines'].items():
        print(f"{l} {x['from']}~{x['to']} 코일 {x['coils']} 제품 {U.fmt(x['tons'])}t 가동률 {x['util'] * 100:.1f}% M/C {x['mcN']}건")
    for c in an['cands']:
        k = c.get('scale', 1)
        print(f"  {'반영권장' if c['apply'] else ('검토' if c['flag'] else '유지'):4} {c['label']}: 현재 {U.fmt((c['cur'] or 0) * k, 1)} → 실적 {U.fmt((c['act'] or 0) * k, 1)} {c['unit']} ({c['basis']})")
    out = MES.summary(an, cl)
    out['daily'] = an['daily']
    json.dump(out, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False)
    print('저장:', a.out)


def cmd_publish(a):
    o = json.load(open(a.result, encoding='utf-8'))
    if o.get('app') != 'cgl-plan':
        o = PB.pack(o)
    if a.config:
        from . import auto
        from .supa import Supa
        cfg = auto.load_config(a.config)
        env = PB.encrypt(o, a.password or cfg['password'], a.label or cfg['label'] or '')
        sbc = cfg['supabase']
        Supa(sbc['url'], sbc['key'], sbc.get('ssl_verify', True)).upload(cfg['published_bucket'], cfg['published_path'], json.dumps(env))
        print(f"Supabase 게시 완료: {cfg['published_bucket']}/{cfg['published_path']}")
        return
    if not (a.password and a.out):
        sys.exit('--password 와 --out 이 필요합니다(또는 --config 로 Supabase 게시)')
    env = PB.encrypt(o, a.password, a.label or '')
    json.dump(env, open(a.out, 'w', encoding='utf-8'))
    print('게시 파일:', a.out)


def cmd_auto(a):
    from . import auto
    sys.exit(auto.run(auto.load_config(a.config), dry=a.dry, force=a.force))


def cmd_supatest(a):
    from . import auto
    sys.exit(auto.supatest(auto.load_config(a.config)))


def main(argv=None):
    ap = argparse.ArgumentParser(prog='cglplan', description='도금 CGL 가동계획 엔진')
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('plan', help='분기 계획 계산')
    p.add_argument('--input', action='append', required=True, help='가동_판매자가재 엑셀(필수), 배선일정분석 엑셀(선택)')
    p.add_argument('--params', help='조건 JSON(계획 화면의 "조건 저장" 파일)')
    p.add_argument('--out', required=True)
    p.add_argument('--threads', type=int)
    p.set_defaults(fn=cmd_plan)
    r = sub.add_parser('replan', help='실적 반영 재계획')
    r.add_argument('--base', required=True)
    r.add_argument('--actual', help='실적 엑셀(실적·설비정지·현재상태 시트)')
    r.add_argument('--t0', help='실적 기준일(YYYY-MM-DD)')
    r.add_argument('--events', help='시뮬레이션 사건 JSON [{type:down|reject, ...}]')
    r.add_argument('--freeze', type=int, default=2)
    r.add_argument('--tradeoff', type=float, default=100, help='M/C 1회 = 지연 N톤·일')
    r.add_argument('--stab', type=float, default=10, help='강종이 바뀐 라인·일 N일 = M/C 1회')
    r.add_argument('--out', required=True)
    r.add_argument('--threads', type=int)
    r.set_defaults(fn=cmd_replan)
    m = sub.add_parser('analyze', help='MES 실적 분석(속도·손실·M/C, 파라미터 후보)')
    m.add_argument('--input', action='append', required=True, help='MES 실적 쿼리 엑셀(또는 생산실적·작업휴지·재고 화면 엑셀들)')
    m.add_argument('--params', help='비교할 조건 JSON(없으면 기본값)')
    m.add_argument('--out', required=True)
    m.set_defaults(fn=cmd_analyze)
    b = sub.add_parser('publish', help='결과를 암호화해 게시 파일로')
    b.add_argument('--result', required=True)
    b.add_argument('--password')
    b.add_argument('--label')
    b.add_argument('--out')
    b.add_argument('--config', help='auto_config.json — 주면 Supabase에 바로 게시')
    b.set_defaults(fn=cmd_publish)
    au = sub.add_parser('auto', help='사내 PC 자동 실행(MES → 재계획 → Supabase 게시)')
    au.add_argument('--config', required=True)
    au.add_argument('--dry', action='store_true', help='업로드 없이 out_dir 에만 저장')
    au.add_argument('--force', action='store_true', help='새 실적이 없어도 재계획')
    au.set_defaults(fn=cmd_auto)
    stt = sub.add_parser('supatest', help='Supabase 연결·키 확인')
    stt.add_argument('--config', required=True)
    stt.set_defaults(fn=cmd_supatest)
    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == '__main__':
    main()
