"""입력 엑셀 해석: 판매계획(부서·권역·용도) + 자가재생산계획(섹션) + 배선일정(권역별 선적창) → 목적지 단위 수요 items.
웹 엔진 engine/parse.js 와 같은 규칙(행 번호 대신 라벨·'상세' 키, 합계행 대사로 양식 변경 경고)."""
import re
import openpyxl
from openpyxl.cell.cell import MergedCell
from . import util as U

WEND = {'1~5일': 5, '6~10일': 10, '11~15일': 15, '16~20일': 20, '21~25일': 25, '26~30일': 30, '1~20일': 20, '1~30일': 99}
_ERR = ('#REF!', '#VALUE!', '#DIV/0!', '#N/A', '#NAME?', '#NUM!', '#NULL!')


def _s(v):
    if v is None or isinstance(v, (dict, list)) or hasattr(v, 'year'):
        return ''
    if isinstance(v, str) and v in _ERR:
        return ''
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def _n(v):
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else 0.0


def _month_of(v):
    m = re.search(r'(\d{1,2})\s*월', _s(v))
    return int(m.group(1)) if m else None


def sheet_grid(ws, max_col=60):
    """1-기반 2차원 배열. 병합 셀의 종속 셀은 None."""
    g = [None]
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=min(ws.max_column or max_col, max_col)):
        g.append([None] + [None if isinstance(c, MergedCell) else c.value for c in row])
    return g


def find_sheet(workbooks, name):
    for wb in workbooks:
        for ws in wb.worksheets:
            if re.sub(r'\s', '', ws.title) == name:
                return ws
    return None


def due_of(y, m, w):
    if not w:
        return U.month_end(y, m)
    e = WEND.get(w)
    if e is None:
        raise ValueError(f'알 수 없는 선적창: {w}')
    return U.month_end(y, m) if e == 99 else U.ymd(y, m, min(e, U.days_in_month(y, m)))


# ---------------- 배선일정 ----------------
def sail_rows_from_grid(g):
    hdr = [_s(v) for v in g[1]]

    def col(name, dflt):
        return hdr.index(name) if name in hdr and hdr.index(name) > 0 else dflt
    c = [col('부서', 1), col('품명', 3), col('권역구분', 5), col('목적지명', 6), col('월평균판매량(참고)', 7), col('배선일정(출항일)', 8)]
    out = []
    for r in range(2, len(g)):
        row = g[r]
        if row and len(row) > c[0] and _s(row[c[0]]):
            out.append([row[i] if i < len(row) else None for i in c])
    return out


def parse_sail(rows, P, checks, src):
    SAIL, n = {}, 0
    for i, (dept, name, reg_full, port, w, win) in enumerate(rows):
        fam = P['sailFamily'].get(_s(name))
        if not fam:
            checks.append({'level': 'warn', 'msg': f"배선일정 {i + 2}행: 품명 '{_s(name)}'을 강종으로 해석할 수 없어 제외"})
            continue
        rf = _s(reg_full)
        reg = rf[rf.index('_') + 1:] if '_' in rf else rf
        win = _s(win)
        if win not in WEND:
            checks.append({'level': 'warn', 'msg': f"배선일정 {i + 2}행: 선적창 '{win}' 해석 불가 — 제외"})
            continue
        SAIL.setdefault(f'{_s(dept)}|{fam}|{reg}', {}).setdefault(win, []).append([_s(port), _n(w)])
        n += 1
    checks.append({'level': 'info', 'msg': f'배선일정 {src}: {n}행 (권역 키 {len(SAIL)}개)'})
    return SAIL


def sail_regions(SAIL, P, dept, fam, label):
    def has(reg):
        for p in P['sailPrefixes']:
            if f'{dept}|{fam}|{p}{reg}' in SAIL:
                return p + reg
        return None
    stripped = re.sub(r'\(.*?\)', '', label).strip()
    d = has(stripped)
    if d:
        return [d]
    m = re.search(r'\((.*?)\)', label)
    if not m:
        return []
    out = []
    for c in m.group(1).split(','):
        c = c.strip()
        c = P['sailAlias'].get(c, c)
        f = has(c)
        if f and f not in out:
            out.append(f)
    return out


def split_by_sail(SAIL, dept, fam, regs, tons):
    wins = {}
    for sr in regs:
        for w, ports in SAIL.get(f'{dept}|{fam}|{sr}', {}).items():
            wins.setdefault(w, []).extend(ports)
    if not wins:
        return [('1~30일', '(배선일정 없음)', tons)]
    tot = sum(p[1] for ps in wins.values() for p in ps)
    out = []
    for w, ps in wins.items():
        wt = sum(p[1] for p in ps)
        top = [p[0] for p in sorted(ps, key=lambda p: -p[1])[:2]]
        out.append((w, ', '.join(top) + (' 외' if len(ps) > 2 else ''), tons * wt / tot if tot else tons / len(wins)))
    return out


def _add_item(items, cls, alloy, mi, y, m, dest, port, window, tons):
    if not tons > 0.01:
        return
    items.append({'cls': cls, 'alloy': alloy, 'mi': mi, 'month': m, 'year': y, 'dest': dest, 'port': port,
                  'window': window, 'due': due_of(y, m, window), 'tons': tons})


# ---------------- 판매계획 ----------------
def parse_sales(g, P, H, SAIL, items, checks, spec):
    sec_starts = []
    for r in range(1, len(g)):
        for c in range(1, 5):
            s = _s(g[r][c]) if c < len(g[r]) else ''
            if re.match(r'^\d+\.\s*\S', s):
                sec = next((x for x in spec['sections'] if x['match'] in s), None)
                if sec and not any(x[0]['id'] == sec['id'] for x in sec_starts):
                    sec_starts.append((sec, r))
                break
    for sec in spec['sections']:
        if not any(x[0]['id'] == sec['id'] for x in sec_starts):
            checks.append({'level': 'error', 'msg': f"판매계획: '{sec['match']}' 구역 제목 행을 찾지 못함"})
    sec_starts.sort(key=lambda x: x[1])
    nM = len(H['ym'])
    for si, (sec, r0) in enumerate(sec_starts):
        r1 = sec_starts[si + 1][1] - 1 if si + 1 < len(sec_starts) else len(g) - 1
        hr, key_col = -1, -1
        for r in range(r0, r1 + 1):
            for c in range(1, len(g[r])):
                if _s(g[r][c]) == '상세':
                    hr, key_col = r, c
                    break
            if hr >= 0:
                break
        if hr < 0:
            checks.append({'level': 'error', 'msg': f"판매계획 '{sec['match']}': '상세' 머리행 없음"})
            continue
        mcol = {}
        for c in range(key_col + 1, len(g[hr])):
            m = _month_of(g[hr][c])
            if m and m not in mcol:
                mcol[m] = c
        cols = [mcol.get(m) for _, m in H['ym']]
        if any(c is None for c in cols):
            checks.append({'level': 'error', 'msg': f"판매계획 '{sec['match']}': 계획 월({'·'.join(map(str, P['months']))}월) 열을 찾지 못함"})
            continue
        rows = {}
        for r in range(hr + 1, r1 + 1):
            row = g[r]
            label = ''
            for c in range(2, key_col):
                s = _s(row[c]) if c < len(row) else ''
                if s:
                    label = s
                    break
            key = _s(row[key_col]) if key_col < len(row) else ''
            errs = [c for c in cols if c < len(row) and isinstance(row[c], str) and row[c] in _ERR]
            if errs and label:
                checks.append({'level': 'warn', 'msg': f'판매계획 {r}행({label}): 값이 오류(#REF! 등) — 0으로 처리'})
            rows[r] = {'r': r, 'label': label, 'key': '' if key == '0' else key,
                       'vals': [_n(row[c]) if c < len(row) else 0.0 for c in cols], 'used': False}

        def is_stop(x):
            return (not x) or (not x['label'] and not x['key']) or re.search(r'::(내수|수출)::', x['key']) is not None

        for grp in [x for x in spec['groups'] if x['sec'] == sec['id']]:
            sub = next((x for x in rows.values() if x['key'] == grp['sub']), None)
            if not sub:
                checks.append({'level': 'error', 'msg': f"판매계획: 합계행 '{grp['sub']}' 없음 (양식 변경?)"})
                continue
            sub['used'] = True

            def add_tons(dest, sail_label, vals, grp=grp):
                for mi, v in enumerate(vals):
                    if not v > 0:
                        continue
                    y, m = H['ym'][mi]
                    if grp.get('sail'):
                        regs = sail_regions(SAIL, P, grp['sail'], grp['alloy'], sail_label)
                        for w, port, t in split_by_sail(SAIL, grp['sail'], grp['alloy'], regs, v):
                            _add_item(items, grp['cls'], grp['alloy'], mi, y, m, dest, port, w, t)
                    else:
                        _add_item(items, grp['cls'], grp['alloy'], mi, y, m, dest, '', None, v)
            if grp.get('self'):
                add_tons(grp['self'], grp.get('selfSail') or sub['label'], sub['vals'])
                continue
            win = []
            for r in range(sub['r'] - 1, hr, -1):
                if is_stop(rows.get(r)):
                    break
                win.append(rows[r])
            got = [0.0] * nM
            for ch in grp['children']:
                lab, dest = (ch[0], ch[1]) if isinstance(ch, list) else (ch, ch)
                row = next((x for x in win if x['label'] == lab and not x['used']), None)
                if not row:
                    continue
                row['used'] = True
                for i, v in enumerate(row['vals']):
                    got[i] += v
                add_tons(dest, lab, row['vals'])
            for lab in grp.get('info', []):
                for x in win:
                    if x['label'] == lab:
                        x['used'] = True
            for i, v in enumerate(sub['vals']):
                if abs(v - got[i]) > 0.5:
                    checks.append({'level': 'warn', 'msg': f"판매계획 대사 불일치: {grp['cls']} {grp['alloy']} {H['ym'][i][1]}월 — 합계행 {U.fmt(v)}t vs 반영 행 합 {U.fmt(got[i])}t (새 행 추가·라벨 변경 가능성)"})
        for x in rows.values():
            if x['used'] or not any(abs(v) > 0.01 for v in x['vals']) or x['label'] in sec['totals']:
                continue
            checks.append({'level': 'warn', 'msg': f"판매계획 {x['r']}행 '{x['label'] or x['key']}' ({'/'.join(U.fmt(v) for v in x['vals'])}t)이 계획에 반영되지 않음 — 해석 규칙에 없는 행"})


# ---------------- 자가재생산계획 ----------------
def parse_self(g, P, H, items, checks):
    hr = cname = csec = -1
    for r in range(1, min(len(g), 15)):
        for c in range(1, len(g[r])):
            if _s(g[r][c]) == '품명':
                hr, cname = r, c
        if hr >= 0:
            break
    if hr < 0:
        checks.append({'level': 'error', 'msg': "자가재생산계획: '품명' 머리행 없음"})
        return
    for c in range(1, len(g[hr])):
        if re.search(r'그룹|섹션', _s(g[hr][c])):
            csec = c
            break
    if csec < 0:
        csec = cname - 1
    mcol = {}
    for c in range(cname + 1, len(g[hr])):
        m = _month_of(g[hr][c])
        if m and m not in mcol:
            mcol[m] = c
    cols = [mcol.get(m) for _, m in H['ym']]
    if any(c is None for c in cols):
        checks.append({'level': 'error', 'msg': f"자가재생산계획: 계획 월({'·'.join(map(str, P['months']))}월) 열 없음"})
        return
    sec, n = '', 0
    for r in range(hr + 1, len(g)):
        row = g[r]
        s, name = _s(row[csec]), _s(row[cname])
        if re.search(r'라인생산', s):
            break
        if s:
            sec = s
        if not name:
            continue
        vals = [_n(row[c]) if c < len(row) else 0.0 for c in cols]
        alloy = 'AL-LG' if 'LG' in name else 'AL' if 'ALCOSTA' in name else 'AZ' if 'ALZASTA' in name else 'MAC' if 'PosMAC' in name else None
        if not alloy:
            if any(v > 0 for v in vals):
                checks.append({'level': 'warn', 'msg': f"자가재생산계획 {r}행 품명 '{name}' 해석 불가 — 제외"})
            continue
        pm = re.search(r'\(.*?\)', name)
        paren = pm.group(0) if pm else ''
        dest = re.sub(r'섹션$', '', re.sub(r'\s+', '', sec)) + paren
        for mi, v in enumerate(vals):
            y, m = H['ym'][mi]
            _add_item(items, '자가재', alloy, mi, y, m, dest, '', None, v)
            if v > 0:
                n += 1
    checks.append({'level': 'info', 'msg': f'자가재생산계획 {n}건 읽음'})


def load_workbooks(paths):
    return [openpyxl.load_workbook(p, data_only=True) for p in paths]


def parse_inputs(workbooks, P):
    """workbooks: openpyxl Workbook 목록(순서 무관). 반환 {items, checks, asOf}"""
    H, checks, items = U.horizon(P), [], []
    ws_sail = find_sheet(workbooks, '정리_배선일정')
    ws_sales = find_sheet(workbooks, '판매계획')
    ws_self = find_sheet(workbooks, '자가재생산계획')
    if not ws_sales:
        checks.append({'level': 'error', 'msg': "'판매계획' 시트가 있는 파일이 없음"})
    if not ws_self:
        checks.append({'level': 'error', 'msg': "'자가재생산계획' 시트가 있는 파일이 없음"})
    if any(c['level'] == 'error' for c in checks):
        return {'items': items, 'checks': checks, 'asOf': ''}
    if ws_sail:
        SAIL = parse_sail(sail_rows_from_grid(sheet_grid(ws_sail, 12)), P, checks, '올린 파일')
    else:
        SAIL = parse_sail(U.DEFAULTS['DEFAULT_SAIL_ROWS'], P, checks, '기본값(2026-09 배선일정분석 — 선적 일정이 바뀌면 배선일정 파일도 올리세요)')
    gs = sheet_grid(ws_sales, 40)
    as_of = ''
    for r in range(1, min(5, len(gs))):
        for v in gs[r]:
            s = _s(v)
            if re.search(r"\(\s*'?\d{2}\.\d{1,2}\.\d{1,2}", s):
                as_of = s
    parse_sales(gs, P, H, SAIL, items, checks, U.DEFAULTS['SALES_SPEC'])
    parse_self(sheet_grid(ws_self, 20), P, H, items, checks)
    for it in items:
        if not any(it['alloy'] in P['allowed'][l] for l in P['lines']):
            checks.append({'level': 'error', 'msg': f"{it['cls']} {it['alloy']}: 생산 가능한 라인이 없음(라인제약 파라미터 확인)"})
    checks.append({'level': 'info', 'msg': f"수요 항목 {len(items)}건, 합계 {U.fmt(sum(i['tons'] for i in items), 1)}t"})
    return {'items': items, 'checks': checks, 'asOf': as_of}
