"""롤링 재계획 + 실적 입력(엑셀) 해석. 웹 엔진 engine/replan.js·actual.js 와 같은 규칙.
사내 MES 연동 시: MES 실적 → actual dict {t0, rows, state, extraDown, notes} 로 만들어 replan() 호출."""
import re
import openpyxl
from . import util as U
from . import model as M
from .parse import find_sheet

# timeLimit 1e7초 = 사실상 무제한(최적 증명까지), phase2Mode 'exact' — 웹 엔진과 동일
REPLAN_DEFAULTS = {'lockMC': True, 'freezeDays': 2, 'allowLate': True, 'maxLate': 14, 'lateW': 0.01, 'shortW': 1000, 'stabW': 0.1, 'stabW2': 500, 'timeLimit': 1e7, 'phase2Mode': 'exact'}
DEPTS = ['도금수출', '자동차수출', '도금국내', '자동차내수', '자가재']


def simulate_actuals(R, t0, disruptions=()):
    """시험용 가짜 실적: 기존 계획대로 t0까지 생산했다고 보고 교란(설비정지·불량) 적용"""
    P = R['P']
    rows = [list(r) for r in R['rows'] if r[0] <= t0]
    extra, notes = {}, []
    for x in disruptions:
        if x['type'] == 'down':
            for d in U.date_range(x['from'], x['to']):
                if d <= t0:
                    cap = next((c['cap'] for c in R['cal'] if c['line'] == x['line'] and c['date'] == d), 1440)
                    frac = min(1, x['minutes'] / max(1, cap)) if x.get('minutes') else 1
                    for r in rows:
                        if r[1] == x['line'] and r[0] == d:
                            r[4] = U.js_round(r[4] * (1 - frac), 2)
                else:
                    extra[f"{x['line']}|{d}"] = extra.get(f"{x['line']}|{d}", 0) + (x.get('minutes') or 1440)
            notes.append(f"{x['line']} {U.md(x['from'])}~{U.md(x['to'])} 설비정지" + (f" {U.fmt(x['minutes'])}분/일" if x.get('minutes') else '(종일)'))
        elif x['type'] == 'reject':
            day = [r for r in rows if r[1] == x['line'] and r[0] == x['date']]
            tot = sum(r[4] for r in day)
            for r in day:
                r[4] = U.js_round(r[4] * max(0, 1 - x['tons'] / tot), 2)
            notes.append(f"{x['line']} {U.md(x['date'])} 불량 {U.fmt(x['tons'])}t (재생산 필요)")
    rows = [r for r in rows if r[4] > 0.05]
    state = {}
    for l in P['lines']:
        c = next((c for c in R['cal'] if c['line'] == l and c['date'] == t0), None)
        state[l] = c['fam'] if c else P['initFamily'][l]
    return {'t0': t0, 'rows': rows, 'state': state, 'extraDown': extra, 'notes': notes}


def mc_lock(P, H, R, act, notes):
    """M/C 고정 조건(웹 GP.mcLock 과 동일): 기준 계획에서 t0 다음 날부터 강종이 바뀌는 날 = 확정 M/C.
    현재 강종이 기준 계획과 같은 라인만 다음 날부터 고정(다르면 기준 계획이 현장과 어긋난 것 → 고정 안 함·알림).
    확정 M/C 날에 추가 정지가 겹쳐 전환이 안 되면 그 라인도 고정 안 함"""
    base = {f"{c['line']}|{c['date']}": c['fam'] for c in R['cal']}
    ds, XD, lock = U.date_range(act['t0'], H['D1']), act.get('extraDown') or {}, {}
    for l in P['lines']:
        days = {}
        for i in range(1, len(ds)):
            a, b = base.get(f'{l}|{ds[i - 1]}'), base.get(f'{l}|{ds[i]}')
            if a and b and a != b:
                days[ds[i]] = b
        sw = sorted(days)
        clash = next((d for d in sw if XD.get(f'{l}|{d}', 0) > 1440 - P['equipDown'][l] - max(P['switchDummy'][l], P['restartFamchg'][l])), None)
        if clash:
            notes.append(f'{l} 확정 M/C {U.md(clash)}에 추가 정지가 겹쳐 이 라인은 M/C 고정 안 함 — 일정 재검토')
            continue
        if act['state'][l] != base.get(f"{l}|{act['t0']}"):            # 현장이 기준 계획과 다른 강종 → 기준 계획의 M/C 일정 자체가 안 맞음
            notes.append(f"{l} 현재 강종 {act['state'][l]} ≠ 기준 계획 {base.get(f'{l}|' + act['t0'])} — 이 라인 M/C 고정 안 함(기준 계획 재수립 필요)")
            continue
        lock[l] = {'from': ds[1], 'days': days}
    return lock


def fix_mc(P, H, act, MO, fixes, notes):
    """회사가 정한 M/C 날짜 지정(변경 등록): fixes = [{'line', 'date', 'fam'}] — 그 날 그 강종으로 바뀜을 강제.
    M/C 고정(lock) 중인 라인은 같은 강종으로 바뀌는 기존 고정일(±10일)을 지정일로 옮김(나머지 고정일은 그대로).
    고정 안 된 라인은 지정일만 강제(그날 강종 = fam, 전날 ≠ fam), 다른 전환은 자유"""
    lock = MO.get('lock') or {}
    force = {}
    for x in fixes:
        l, d, fm = x['line'], x['date'], x['fam']
        if not (act['t0'] < d <= H['D1']):                  # 지난 날짜는 실적이 대신함(조용히 건너뜀)
            continue
        bs = MO['baseState']                           # 기준 강종(동결·안정성 기준)도 지정일로 옮김 — 안 옮기면 동결 기간 안의 지정과 모순
        sw = [od for od in U.date_range(U.add_days(d, -10), U.add_days(d, 10)) if od > act['t0'] and bs.get(f'{l}|{od}') == fm and bs.get(f'{l}|{U.add_days(od, -1)}') not in (fm, None)]
        if sw:
            od = min(sw, key=lambda z: abs(U.diff_days(z, d)))
            prev = bs[f'{l}|{U.add_days(od, -1)}']
            for z in (U.date_range(od, U.add_days(d, -1)) if od < d else U.date_range(d, U.add_days(od, -1))):
                bs[f'{l}|{z}'] = prev if od < d else fm
        if l in lock:
            k = lock[l]
            old = [od for od, of in k['days'].items() if of == fm and abs(U.diff_days(od, d)) <= 10 and od != d]
            for od in old:
                k['days'].pop(od)
            k['days'][d] = fm
            notes.append(f"{l} M/C 지정 {U.md(d)}({fm})" + (f" — 기존 고정일 {', '.join(U.md(o) for o in old)}에서 옮김" if old else ''))
        else:
            force[f'{l}|{d}'] = fm
            notes.append(f"{l} M/C 지정 {U.md(d)}({fm}) — 이 라인은 M/C 고정이 아니라 지정일만 강제")
    if force:
        MO['force'] = force


def _switches(P, st, ds):
    o = []
    for l in P['lines']:
        for i in range(1, len(ds)):
            a, b = st.get(f'{l}|{ds[i - 1]}'), st.get(f'{l}|{ds[i]}')
            if a and b and a != b:
                o.append(f'{ds[i]}|{l}|{a}→{b}')
    return o


SELF_LATE_K = 0.01                                       # 자가재 반순 납기 지연 가중(직판재 1) — 직판재 지연을 자가재 때문에 늘리지 않음


def split_self(rem, act, req, t0, D1, notes):
    """자가재 월말 납기 버킷을 컬러 필요일 기준 반순 납기로 앞당겨 나눔(합계 그대로).
    req = {강종: [[날짜, 10/1부터 누적 필요 생산 t], …]} (tools/plan_changes.py: 컬러 일별 계획 − 8일, 9월말 자가재 재고 차감).
    이미 만든 자가재(실적)를 빼고, 남은 필요분을 가장 이른 월말 버킷부터 떼어 그 반순 끝을 납기로 둠. 늦어도 원래 월말까지는 결품 아님(maxLate),
    지연 가중은 직판재의 SELF_LATE_K 배. 반환: (새 버킷 목록, {(부서, 강종, 새 납기): 원래 납기})"""
    made = {}
    for d, l, a, c, t, du in act['rows']:
        if c == '자가재':
            made[a] = made.get(a, 0) + t
    nid = max(b['id'] for b in rem) + 1
    out, back, moved = [], {}, {}
    orig_dues = {(b['cls'], b['alloy'], b['due']) for b in rem}
    for b in rem:
        if b['cls'] != '자가재' or b['alloy'] not in req:
            out.append(b)
    for a, ser in req.items():
        bs = sorted([dict(b) for b in rem if b['cls'] == '자가재' and b['alloy'] == a and b['orig'] > 1e-6], key=lambda b: b['due'])
        poured = 0.0
        for e, cum in ser:
            if e <= t0 or e > D1:
                continue
            need = max(0.0, cum - made.get(a, 0)) - poured
            for b in bs:
                if need <= 1e-6:
                    break
                if b['due'] <= e or b['orig'] <= 1e-6:
                    continue
                take = min(need, b['orig'])
                due = e if ('자가재', a, e) not in orig_dues else U.add_days(e, -1)
                out.append({'cls': '자가재', 'alloy': a, 'due': due, 'orig': take, 'id': nid, 'lateK': SELF_LATE_K, 'maxLate': U.diff_days(b['due'], due)})
                back[('자가재', a, due)] = b['due']
                moved[a] = moved.get(a, 0) + take
                nid += 1
                b['orig'] -= take
                need -= take
                poured += take
        out += [b for b in bs if b['orig'] > 1e-6]
    if moved:
        notes.append('자가재 납기 컬러 필요일 기준(반순): ' + ', '.join(f'{a} {U.fmt(t)}t 앞당김' for a, t in moved.items()))
    return out, back


def replan(R, act, opts=None, log=None, threads=None):
    """R: 기준 계획 결과, act: 실적. 반환: 같은 형식 결과(과거=실적 + 미래=재계획) + replan 요약"""
    P, H = R['P'], U.horizon(R['P'])
    O = dict(REPLAN_DEFAULTS, **(opts or {}))
    if act['t0'] < H['D0'] or act['t0'] >= H['D1']:
        raise ValueError(f"실적 기준일 {act['t0']}이 계획 기간 밖")
    done = {}
    for d, l, a, c, t, du in act['rows']:
        done[(c, a, du)] = done.get((c, a, du), 0) + t
    over, rem = [], []
    for b in R['buckets']:
        left = b['orig'] - done.get((b['cls'], b['alloy'], b['due']), 0)
        if left < -0.5:
            over.append(f"{b['cls']} {b['alloy']} {U.md(b['due'])} +{U.fmt(-left)}t")
        rem.append(dict(b, orig=max(0.0, left)))
    base = {f"{c['line']}|{c['date']}": c['fam'] for c in R['cal']}
    fu = U.add_days(act['t0'], O['freezeDays']) if O['freezeDays'] > 0 else None
    for l, cur in (act.get('state') or {}).items():                  # 기준 계획 강종이 실제와 어긋난 라인은 동결 기간을 지금 강종으로(이미 나간 지시 = 지금 강종)
        if fu and base.get(f"{l}|{act['t0']}") != cur:
            d = U.add_days(act['t0'], 1)
            while d <= fu:
                if f'{l}|{d}' in base:
                    base[f'{l}|{d}'] = cur
                d = U.add_days(d, 1)
    MO = {'t0': act['t0'], 'init': act['state'], 'freezeUntil': U.add_days(act['t0'], O['freezeDays']) if O['freezeDays'] > 0 else None,
          'baseState': base, 'allowLate': O['allowLate'], 'maxLate': O['maxLate'], 'lateW': O['lateW'], 'shortW': O['shortW'],
          'stabW': O['stabW'], 'stabW2': O['stabW2'], 'extraDown': act.get('extraDown') or {}}
    lock_notes = []
    if O['lockMC']:
        MO['lock'] = mc_lock(P, H, R, act, lock_notes)
    if O.get('fixMC'):
        fix_mc(P, H, act, MO, O['fixMC'], lock_notes)
    self_back = {}
    if O.get('selfReq'):
        rem, self_back = split_self(rem, act, O['selfReq'], act['t0'], H['D1'], lock_notes)
    if log:
        log(f"실적 {U.fmt(sum(r[4] for r in act['rows']))}t 반영(~{U.md(act['t0'])}), 남은 수요 {U.fmt(sum(b['orig'] for b in rem))}t, 강종 동결 ~{U.md(MO['freezeUntil']) if MO['freezeUntil'] else '없음'}")
    PS = dict(P, timeLimit1=O['timeLimit'], timeLimit2=O['timeLimit'], phase2Mode=O['phase2Mode'])
    proposal = None
    try:
        milp = M.run_milp(rem, PS, log, MO, threads)
    except Exception as e:
        if not MO.get('lock'):
            raise
        lock_notes.append(f'M/C 고정으로는 풀리지 않아 고정을 풀고 계산({str(e)[:80]}) — M/C 일정 변경 검토 필요')
        if log:
            log(lock_notes[-1])
        MO.pop('lock')
        milp = M.run_milp(rem, PS, log, MO, threads)
    if MO.get('lock') and (milp['late'] > 0.5 or milp['short'] > 0.5):
        # 고정안에 지연·결품 → M/C 를 옮기면 얼마나 줄어드는지 계산(게시하지 않음, 사람이 결정)
        if log:
            log(f"M/C 고정안: 지연 {U.fmt(milp['late'])}톤·일, 결품 {U.fmt(milp['short'])}t → 고정을 푼 경우 계산(제안용)")
        free = M.run_milp(rem, dict(PS, timeLimit1=120, timeLimit2=120, phase2Mode='fast'), log, dict(MO, lock=None), threads)   # 제안용 — 2분 제한(게시를 막지 않게)
        ds = U.date_range(act['t0'], H['D1'])
        A, B = _switches(P, milp['state'], ds), _switches(P, free['state'], ds)
        proposal = {'lockedLate': milp['late'], 'lockedShort': milp['short'], 'lockedK': milp['K'], 'freeLate': free['late'], 'freeShort': free['short'], 'freeK': free['K'],
                    'drop': [x for x in A if x not in B], 'add': [x for x in B if x not in A]}
        if log:
            log(f"이동 제안: M/C {milp['K']}→{free['K']}회, 지연 {U.fmt(milp['late'])}→{U.fmt(free['late'])}톤·일, 결품 {U.fmt(milp['short'])}→{U.fmt(free['short'])}t (빼기 {', '.join(proposal['drop']) or '-'} / 넣기 {', '.join(proposal['add']) or '-'})")
    lev = M.run_level(rem, PS, milp['state'], log, MO, threads)
    if self_back:                                            # 반순으로 나눈 자가재 → 원래 월말 납기로 되돌려 표기(목적지 배정·화면은 원래 품목 기준)
        self_late = sum(r[4] * max(0, U.diff_days(r[0], r[5])) for r in lev['rows'] if (r[3], r[2], r[5]) in self_back)
        lock_notes.append(f'자가재 반순 납기 대비 늦은 생산 {U.fmt(self_late)}톤·일(직판재 우선)')
        lev['rows'] = [r[:5] + [self_back.get((r[3], r[2], r[5]), r[5])] for r in lev['rows']]
    rows = sorted(act['rows'] + lev['rows'], key=lambda r: '\u0001'.join(map(str, r)))
    act_day, plan_day = {}, {}
    for r in act['rows']:
        act_day[(r[1], r[0])] = act_day.get((r[1], r[0]), 0) + r[4]
    # 계획 대비 실적은 기준 결과에서 '계획'이었던 날만: 기준이 재계획이면 그 기준일(b0)까지는 이미 실적이라 비교하지 않음
    b0 = (R.get('replan') or {}).get('t0')
    inwin = lambda d: d <= act['t0'] and (b0 is None or d > b0)
    for r in R['rows']:
        if inwin(r[0]):
            plan_day[(r[1], r[0])] = plan_day.get((r[1], r[0]), 0) + r[4]
    # 지난 날짜(~t0)는 실적 기준: 강종 = 그날 실적의 주 강종, 전환 표시는 실적 강종이 바뀐 날만(예전 계획의 'M/C 예정'은 지움)
    fam_t = {}
    for r in act['rows']:
        k = (r[1], r[0], P['alloyFamily'].get(r[2]))
        fam_t[k] = fam_t.get(k, 0) + r[4]
    fam_act = {}
    for (l, d, fm), t in fam_t.items():
        if t > fam_act.get((l, d), (None, 0))[1]:
            fam_act[(l, d)] = (fm, t)
    past, prev = [], {}
    for c in sorted(R['cal'], key=lambda c: c['date']):
        if c['date'] > act['t0']:
            continue
        l, d = c['line'], c['date']
        parts = [x for x in (c.get('event') or '').split(' · ') if x and not x.startswith(('M/C', 'S/D 재가동', '실적 미달'))]
        fa = (fam_act.get((l, d)) or (None,))[0]
        if fa:
            if prev.get(l) and prev[l] != fa:
                parts.insert(0, f'M/C({prev[l]}→{fa})')
            prev[l] = fa
        elif (c.get('event') or '').startswith(('M/C', 'S/D 재가동')) and l not in prev:
            parts.insert(0, c['event'].split(' · ')[0])               # 실적이 없는 날(기간 앞)은 원래 표시 유지
        gap = plan_day.get((l, d), 0) - act_day.get((l, d), 0) if inwin(d) else 0
        if gap > 1:
            parts.append(f'실적 미달 {U.fmt(gap)}t')
        past.append(dict(c, fam=fa or c.get('fam'), event=' · '.join(parts)))
    cal = sorted(past + lev['cal'], key=lambda c: c['date'] + c['line'])
    dest, bad = M.split_dest(rows, R['items'], P)

    def ev(cal_):
        return [f"{c['date']}|{c['line']}|{c['event'].split(' · ')[0]}" for c in cal_ if c['date'] > act['t0'] and re.search(r'M/C|재가동', c.get('event') or '')]
    before, after = ev(R['cal']), ev(cal)
    sb = lev['shortBy'] or milp['shortBy']
    short_by = []
    for bid, t in sb:
        b = next(x for x in rem if x['id'] == bid)
        short_by.append(f"{b['cls']} {b['alloy']} {U.md(b['due'])} {U.fmt(t)}t")
    rp = {'t0': act['t0'], 'freezeUntil': MO['freezeUntil'], 'notes': act.get('notes') or [], 'actualT': sum(r[4] for r in act['rows']),
          'planToDateT': sum(r[4] for r in R['rows'] if inwin(r[0])), 'actualWinT': sum(r[4] for r in act['rows'] if inwin(r[0])), 'vsFrom': b0,
          'removed': [x for x in before if x not in after], 'added': [x for x in after if x not in before],
          'over': over, 'shortBy': short_by, 'late': milp['late'], 'baseMC': (R.get('milp') or {}).get('K'), 'options': O, 'lockMC': bool(MO.get('lock')), 'lockNotes': lock_notes, 'proposal': proposal,
          'optimal': bool(milp.get('optimal1') and milp.get('optimal2') and milp.get('phase2Exact'))}
    # 계획 대비 실적(대시보드): 라인×일, 부서 누계
    H = U.horizon(P)
    rp['vsPlan'] = [[d, l, U.js_round(plan_day.get((l, d), 0), 1), U.js_round(act_day.get((l, d), 0), 1)] for d in U.date_range(H['D0'], act['t0']) if inwin(d) for l in P['lines']]
    rp['byDept'] = [[c, U.js_round(sum(r[4] for r in R['rows'] if inwin(r[0]) and r[3] == c), 1), U.js_round(sum(r[4] for r in act['rows'] if inwin(r[0]) and r[3] == c), 1)] for c in DEPTS]
    if log:
        log(f"M/C 고정 {'켬' if MO.get('lock') else '끔'}" + (' — ' + ' / '.join(lock_notes) if lock_notes else ''))
        log(f"재계획{'(최적 증명)' if rp['optimal'] else '(최적 미증명 — 시간 제한)'}: M/C(남은 기간) {milp['K']}회, 지연 {U.fmt(milp['late'])}톤·일, 결품 {U.fmt(milp['short'])}t, 전환 변경 −{len(rp['removed'])}/+{len(rp['added'])}")
    return dict(R, rows=rows, cal=cal, dest=dest, destBad=bad, slack=lev['slack'], milp=dict(milp, base=R.get('milp')), replan=rp)


# ---------------- 실적 엑셀(웹 양식과 동일) ----------------
def _str(v):
    if v is None:
        return ''
    if hasattr(v, 'year'):
        return U.ymd(v.year, v.month, v.day)
    return str(v).strip()


def _date(v):
    s = _str(v)
    if re.match(r'^\d{4}-\d{2}-\d{2}', s):
        return s[:10]
    m = re.match(r'^(\d{4})[./](\d{1,2})[./](\d{1,2})', s)
    return U.ymd(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else ''


def parse_actual_workbook(path_or_wb, R, t0_given=None):
    """시트 '실적'(날짜|라인|세부강종|부서|마감일|생산량) · '설비정지'(라인|시작일|종료일|분/일) · '현재상태'(라인|강종)"""
    wb = openpyxl.load_workbook(path_or_wb, data_only=True) if isinstance(path_or_wb, str) else path_or_wb
    P, checks, rows, extra, notes = R['P'], [], [], {}, []
    ws = find_sheet([wb], '실적')
    if ws is None:
        return {'checks': [{'level': 'error', 'msg': "'실적' 시트 없음"}]}
    raw = []
    for i, row in enumerate(ws.iter_rows(min_row=2, max_col=6, values_only=True), start=2):
        d, l, a, c, du = _date(row[0]), _str(row[1]), _str(row[2]), _str(row[3]), _date(row[4])
        try:
            t = float(str(row[5]).replace(',', '')) if row[5] is not None else 0
        except ValueError:
            t = 0
        if not d and not l:
            continue
        if not d or l not in P['lines'] or a not in P['alloyFamily'] or c not in DEPTS or not t > 0:
            checks.append({'level': 'warn', 'msg': f'실적 {i}행 해석 불가 — 제외 ({d}, {l}, {a}, {c}, {t})'})
            continue
        raw.append({'d': d, 'l': l, 'a': a, 'c': c, 'du': du, 't': t})
    t0 = t0_given or max((x['d'] for x in raw), default='')
    if not t0:
        return {'checks': checks + [{'level': 'error', 'msg': '실적 행이 없음'}]}
    left = {(b['cls'], b['alloy'], b['due']): b['orig'] for b in R['buckets']}
    for x in [x for x in raw if x['du']]:
        k = (x['c'], x['a'], x['du'])
        if k not in left:
            checks.append({'level': 'warn', 'msg': f"실적 {x['d']} {x['l']} {x['c']} {x['a']}: 마감일 {x['du']} 묶음이 계획에 없음 — 그대로 반영"})
        left[k] = left.get(k, 0) - x['t']
    for x in sorted([x for x in raw if not x['du']], key=lambda x: x['d']):
        t = x['t']
        for b in sorted([b for b in R['buckets'] if b['cls'] == x['c'] and b['alloy'] == x['a']], key=lambda b: b['due']):
            k = (b['cls'], b['alloy'], b['due'])
            take = min(t, max(0, left[k]))
            if take > 0:
                raw.append(dict(x, du=b['due'], t=take))
                left[k] -= take
                t -= take
            if t <= 1e-6:
                break
        if t > 1e-6:
            checks.append({'level': 'warn', 'msg': f"실적 {x['d']} {x['l']} {x['c']} {x['a']} {U.fmt(t)}t: 배정할 미완료 수요 없음(초과 생산)"})
    rows = [[x['d'], x['l'], x['a'], x['c'], U.js_round(x['t'], 2), x['du']] for x in raw if x['du'] and x['d'] <= t0]
    w2 = find_sheet([wb], '설비정지')
    if w2 is not None:
        for i, row in enumerate(w2.iter_rows(min_row=2, max_col=4, values_only=True), start=2):
            l, a = _str(row[0]), _date(row[1])
            b = _date(row[2]) or a
            mnt = float(row[3]) if isinstance(row[3], (int, float)) else 0
            if not l and not a:
                continue
            if l not in P['lines'] or not a:
                checks.append({'level': 'warn', 'msg': f'설비정지 {i}행 해석 불가 — 제외'})
                continue
            for d in U.date_range(a, b):
                if d > t0:
                    extra[f'{l}|{d}'] = extra.get(f'{l}|{d}', 0) + (mnt or 1440)
            notes.append(f"{l} {U.md(a)}~{U.md(b)} 설비정지 예정" + (f' {U.fmt(mnt)}분/일' if mnt else '(종일)'))
    state = {}
    w3 = find_sheet([wb], '현재상태')
    if w3 is not None:
        for row in w3.iter_rows(min_row=2, max_col=2, values_only=True):
            l, f = _str(row[0]), _str(row[1])
            if l in P['lines'] and f in P['lineFamilies'][l]:
                state[l] = f
    for l in P['lines']:
        if l not in state:
            last = [r for r in rows if r[1] == l and r[0] == t0]
            c = next((c for c in R['cal'] if c['line'] == l and c['date'] == t0), None)
            state[l] = P['alloyFamily'][last[0][2]] if last else (c['fam'] if c else P['initFamily'][l])
    plan_t = sum(r[4] for r in R['rows'] if r[0] <= t0)
    act_t = sum(r[4] for r in rows)
    notes.insert(0, f'실적 ~{U.md(t0)}: {U.fmt(act_t)}t (계획 {U.fmt(plan_t)}t, 차이 {U.fmt(act_t - plan_t)}t)')
    checks.append({'level': 'info', 'msg': f"실적 {len(rows)}행, 기준일 {t0}, 현재 강종 " + '·'.join(f'{l} {state[l]}' for l in P['lines'])})
    return {'t0': t0, 'rows': rows, 'state': state, 'extraDown': extra, 'notes': notes, 'checks': checks}
