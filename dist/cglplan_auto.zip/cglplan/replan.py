"""롤링 재계획 + 실적 입력(엑셀) 해석. 웹 엔진 engine/replan.js·actual.js 와 같은 규칙.
사내 MES 연동 시: MES 실적 → actual dict {t0, rows, state, extraDown, notes} 로 만들어 replan() 호출."""
import re
import openpyxl
from . import util as U
from . import model as M
from .parse import find_sheet

# timeLimit 1e7초 = 사실상 무제한(최적 증명까지), phase2Mode 'exact' — 웹 엔진과 동일
REPLAN_DEFAULTS = {'freezeDays': 2, 'allowLate': True, 'maxLate': 14, 'lateW': 0.01, 'shortW': 1000, 'stabW': 0.1, 'stabW2': 500, 'timeLimit': 1e7, 'phase2Mode': 'exact'}
DEPTS = ['도금수출', '자동차수출', '도금국내', '자동차내수', '자가재']


def simulate_actuals(R, t0, disruptions=()):
    """시험용 가짜 실적: 기존 계획대로 t0까지 생산했다고 보고 교란(설비정지·불량) 적용"""
    P = R['P']
    rows = [list(r) for r in R['rows'] if r[0] <= t0]
    extra, notes = {}, []
    for x in disruptions:
        if x['type'] == 'down':
            for d in U.date_range(x['from'], x['to']):
                if d <= t0:
                    cap = next((c['cap'] for c in R['cal'] if c['line'] == x['line'] and c['date'] == d), 1440)
                    frac = min(1, x['minutes'] / max(1, cap)) if x.get('minutes') else 1
                    for r in rows:
                        if r[1] == x['line'] and r[0] == d:
                            r[4] = U.js_round(r[4] * (1 - frac), 2)
                else:
                    extra[f"{x['line']}|{d}"] = extra.get(f"{x['line']}|{d}", 0) + (x.get('minutes') or 1440)
            notes.append(f"{x['line']} {U.md(x['from'])}~{U.md(x['to'])} 설비정지" + (f" {U.fmt(x['minutes'])}분/일" if x.get('minutes') else '(종일)'))
        elif x['type'] == 'reject':
            day = [r for r in rows if r[1] == x['line'] and r[0] == x['date']]
            tot = sum(r[4] for r in day)
            for r in day:
                r[4] = U.js_round(r[4] * max(0, 1 - x['tons'] / tot), 2)
            notes.append(f"{x['line']} {U.md(x['date'])} 불량 {U.fmt(x['tons'])}t (재생산 필요)")
    rows = [r for r in rows if r[4] > 0.05]
    state = {}
    for l in P['lines']:
        c = next((c for c in R['cal'] if c['line'] == l and c['date'] == t0), None)
        state[l] = c['fam'] if c else P['initFamily'][l]
    return {'t0': t0, 'rows': rows, 'state': state, 'extraDown': extra, 'notes': notes}


def replan(R, act, opts=None, log=None, threads=None):
    """R: 기준 계획 결과, act: 실적. 반환: 같은 형식 결과(과거=실적 + 미래=재계획) + replan 요약"""
    P, H = R['P'], U.horizon(R['P'])
    O = dict(REPLAN_DEFAULTS, **(opts or {}))
    if act['t0'] < H['D0'] or act['t0'] >= H['D1']:
        raise ValueError(f"실적 기준일 {act['t0']}이 계획 기간 밖")
    done = {}
    for d, l, a, c, t, du in act['rows']:
        done[(c, a, du)] = done.get((c, a, du), 0) + t
    over, rem = [], []
    for b in R['buckets']:
        left = b['orig'] - done.get((b['cls'], b['alloy'], b['due']), 0)
        if left < -0.5:
            over.append(f"{b['cls']} {b['alloy']} {U.md(b['due'])} +{U.fmt(-left)}t")
        rem.append(dict(b, orig=max(0.0, left)))
    base = {f"{c['line']}|{c['date']}": c['fam'] for c in R['cal']}
    MO = {'t0': act['t0'], 'init': act['state'], 'freezeUntil': U.add_days(act['t0'], O['freezeDays']) if O['freezeDays'] > 0 else None,
          'baseState': base, 'allowLate': O['allowLate'], 'maxLate': O['maxLate'], 'lateW': O['lateW'], 'shortW': O['shortW'],
          'stabW': O['stabW'], 'stabW2': O['stabW2'], 'extraDown': act.get('extraDown') or {}}
    if log:
        log(f"실적 {U.fmt(sum(r[4] for r in act['rows']))}t 반영(~{U.md(act['t0'])}), 남은 수요 {U.fmt(sum(b['orig'] for b in rem))}t, 강종 동결 ~{U.md(MO['freezeUntil']) if MO['freezeUntil'] else '없음'}")
    PS = dict(P, timeLimit1=O['timeLimit'], timeLimit2=O['timeLimit'], phase2Mode=O['phase2Mode'])
    milp = M.run_milp(rem, PS, log, MO, threads)
    lev = M.run_level(rem, PS, milp['state'], log, MO, threads)
    rows = sorted(act['rows'] + lev['rows'], key=lambda r: '\u0001'.join(map(str, r)))
    act_day, plan_day = {}, {}
    for r in act['rows']:
        act_day[(r[1], r[0])] = act_day.get((r[1], r[0]), 0) + r[4]
    for r in R['rows']:
        if r[0] <= act['t0']:
            plan_day[(r[1], r[0])] = plan_day.get((r[1], r[0]), 0) + r[4]
    past = []
    for c in R['cal']:
        if c['date'] > act['t0']:
            continue
        gap = plan_day.get((c['line'], c['date']), 0) - act_day.get((c['line'], c['date']), 0)
        past.append(dict(c, event=(c['event'] + ' · ' if c['event'] else '') + f'실적 미달 {U.fmt(gap)}t') if gap > 1 else c)
    cal = sorted(past + lev['cal'], key=lambda c: c['date'] + c['line'])
    dest, bad = M.split_dest(rows, R['items'], P)

    def ev(cal_):
        return [f"{c['date']}|{c['line']}|{c['event'].split(' · ')[0]}" for c in cal_ if c['date'] > act['t0'] and re.search(r'M/C|재가동', c.get('event') or '')]
    before, after = ev(R['cal']), ev(cal)
    sb = lev['shortBy'] or milp['shortBy']
    short_by = []
    for bid, t in sb:
        b = next(x for x in rem if x['id'] == bid)
        short_by.append(f"{b['cls']} {b['alloy']} {U.md(b['due'])} {U.fmt(t)}t")
    rp = {'t0': act['t0'], 'freezeUntil': MO['freezeUntil'], 'notes': act.get('notes') or [], 'actualT': sum(r[4] for r in act['rows']),
          'planToDateT': sum(r[4] for r in R['rows'] if r[0] <= act['t0']),
          'removed': [x for x in before if x not in after], 'added': [x for x in after if x not in before],
          'over': over, 'shortBy': short_by, 'late': milp['late'], 'baseMC': (R.get('milp') or {}).get('K'), 'options': O,
          'optimal': bool(milp.get('optimal1') and milp.get('optimal2') and milp.get('phase2Exact'))}
    # 계획 대비 실적(대시보드): 라인×일, 부서 누계
    H = U.horizon(P)
    rp['vsPlan'] = [[d, l, U.js_round(plan_day.get((l, d), 0), 1), U.js_round(act_day.get((l, d), 0), 1)] for d in U.date_range(H['D0'], act['t0']) for l in P['lines']]
    rp['byDept'] = [[c, U.js_round(sum(r[4] for r in R['rows'] if r[0] <= act['t0'] and r[3] == c), 1), U.js_round(sum(r[4] for r in act['rows'] if r[3] == c), 1)] for c in DEPTS]
    if log:
        log(f"재계획{'(최적 증명)' if rp['optimal'] else '(최적 미증명 — 시간 제한)'}: M/C(남은 기간) {milp['K']}회, 지연 {U.fmt(milp['late'])}톤·일, 결품 {U.fmt(milp['short'])}t, 전환 변경 −{len(rp['removed'])}/+{len(rp['added'])}")
    return dict(R, rows=rows, cal=cal, dest=dest, destBad=bad, slack=lev['slack'], milp=dict(milp, base=R.get('milp')), replan=rp)


# ---------------- 실적 엑셀(웹 양식과 동일) ----------------
def _str(v):
    if v is None:
        return ''
    if hasattr(v, 'year'):
        return U.ymd(v.year, v.month, v.day)
    return str(v).strip()


def _date(v):
    s = _str(v)
    if re.match(r'^\d{4}-\d{2}-\d{2}', s):
        return s[:10]
    m = re.match(r'^(\d{4})[./](\d{1,2})[./](\d{1,2})', s)
    return U.ymd(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else ''


def parse_actual_workbook(path_or_wb, R, t0_given=None):
    """시트 '실적'(날짜|라인|세부강종|부서|마감일|생산량) · '설비정지'(라인|시작일|종료일|분/일) · '현재상태'(라인|강종)"""
    wb = openpyxl.load_workbook(path_or_wb, data_only=True) if isinstance(path_or_wb, str) else path_or_wb
    P, checks, rows, extra, notes = R['P'], [], [], {}, []
    ws = find_sheet([wb], '실적')
    if ws is None:
        return {'checks': [{'level': 'error', 'msg': "'실적' 시트 없음"}]}
    raw = []
    for i, row in enumerate(ws.iter_rows(min_row=2, max_col=6, values_only=True), start=2):
        d, l, a, c, du = _date(row[0]), _str(row[1]), _str(row[2]), _str(row[3]), _date(row[4])
        try:
            t = float(str(row[5]).replace(',', '')) if row[5] is not None else 0
        except ValueError:
            t = 0
        if not d and not l:
            continue
        if not d or l not in P['lines'] or a not in P['alloyFamily'] or c not in DEPTS or not t > 0:
            checks.append({'level': 'warn', 'msg': f'실적 {i}행 해석 불가 — 제외 ({d}, {l}, {a}, {c}, {t})'})
            continue
        raw.append({'d': d, 'l': l, 'a': a, 'c': c, 'du': du, 't': t})
    t0 = t0_given or max((x['d'] for x in raw), default='')
    if not t0:
        return {'checks': checks + [{'level': 'error', 'msg': '실적 행이 없음'}]}
    left = {(b['cls'], b['alloy'], b['due']): b['orig'] for b in R['buckets']}
    for x in [x for x in raw if x['du']]:
        k = (x['c'], x['a'], x['du'])
        if k not in left:
            checks.append({'level': 'warn', 'msg': f"실적 {x['d']} {x['l']} {x['c']} {x['a']}: 마감일 {x['du']} 묶음이 계획에 없음 — 그대로 반영"})
        left[k] = left.get(k, 0) - x['t']
    for x in sorted([x for x in raw if not x['du']], key=lambda x: x['d']):
        t = x['t']
        for b in sorted([b for b in R['buckets'] if b['cls'] == x['c'] and b['alloy'] == x['a']], key=lambda b: b['due']):
            k = (b['cls'], b['alloy'], b['due'])
            take = min(t, max(0, left[k]))
            if take > 0:
                raw.append(dict(x, du=b['due'], t=take))
                left[k] -= take
                t -= take
            if t <= 1e-6:
                break
        if t > 1e-6:
            checks.append({'level': 'warn', 'msg': f"실적 {x['d']} {x['l']} {x['c']} {x['a']} {U.fmt(t)}t: 배정할 미완료 수요 없음(초과 생산)"})
    rows = [[x['d'], x['l'], x['a'], x['c'], U.js_round(x['t'], 2), x['du']] for x in raw if x['du'] and x['d'] <= t0]
    w2 = find_sheet([wb], '설비정지')
    if w2 is not None:
        for i, row in enumerate(w2.iter_rows(min_row=2, max_col=4, values_only=True), start=2):
            l, a = _str(row[0]), _date(row[1])
            b = _date(row[2]) or a
            mnt = float(row[3]) if isinstance(row[3], (int, float)) else 0
            if not l and not a:
                continue
            if l not in P['lines'] or not a:
                checks.append({'level': 'warn', 'msg': f'설비정지 {i}행 해석 불가 — 제외'})
                continue
            for d in U.date_range(a, b):
                if d > t0:
                    extra[f'{l}|{d}'] = extra.get(f'{l}|{d}', 0) + (mnt or 1440)
            notes.append(f"{l} {U.md(a)}~{U.md(b)} 설비정지 예정" + (f' {U.fmt(mnt)}분/일' if mnt else '(종일)'))
    state = {}
    w3 = find_sheet([wb], '현재상태')
    if w3 is not None:
        for row in w3.iter_rows(min_row=2, max_col=2, values_only=True):
            l, f = _str(row[0]), _str(row[1])
            if l in P['lines'] and f in P['lineFamilies'][l]:
                state[l] = f
    for l in P['lines']:
        if l not in state:
            last = [r for r in rows if r[1] == l and r[0] == t0]
            c = next((c for c in R['cal'] if c['line'] == l and c['date'] == t0), None)
            state[l] = P['alloyFamily'][last[0][2]] if last else (c['fam'] if c else P['initFamily'][l])
    plan_t = sum(r[4] for r in R['rows'] if r[0] <= t0)
    act_t = sum(r[4] for r in rows)
    notes.insert(0, f'실적 ~{U.md(t0)}: {U.fmt(act_t)}t (계획 {U.fmt(plan_t)}t, 차이 {U.fmt(act_t - plan_t)}t)')
    checks.append({'level': 'info', 'msg': f"실적 {len(rows)}행, 기준일 {t0}, 현재 강종 " + '·'.join(f'{l} {state[l]}' for l in P['lines'])})
    return {'t0': t0, 'rows': rows, 'state': state, 'extraDown': extra, 'notes': notes, 'checks': checks}
