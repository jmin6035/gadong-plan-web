# cglplan — 도금 CGL 가동계획 엔진(Python, 서버용)

웹(`web/engine/*.js`)과 **같은 모델**을 Python으로 옮긴 것. 같은 입력이면 두 엔진 결과가 날짜·라인·부서 단위까지 같다(2026-09-29 확인, `tests/test_engine.py`).
사내 서버에서 MES 데이터를 받아 자동으로 계획·재계획할 때 쓰는 부분이다. 결과 JSON은 웹 대시보드가 그대로 읽는다.

## 설치
```bash
pip install openpyxl highspy            # 필수
pip install cryptography                # 게시 파일 암호화(publish) 쓸 때
pip install fastapi uvicorn python-multipart   # 사내 서버(server.py) 쓸 때
```

## 명령행 (gadong-plan/ 폴더에서)
```bash
python -m cglplan plan   --input data/ctx_가동_판매자가재.xlsx --out result.json          # 분기 계획(약 2분)
python -m cglplan replan --base result.json --actual 실적입력.xlsx --out replan.json       # 실적 반영 재계획(약 1분)
python -m cglplan publish --result result.json --password "..." --out ../web/published/latest.plan.enc.json
```
- 배선일정 파일은 선택(`--input` 두 번). 없으면 `defaults.json`의 기본 배선일정 사용
- 조건 변경: 웹 계획 화면의 "조건 저장" JSON을 `--params`로
- 재계획 기준: `--freeze 2`(강종 동결 일수) `--tradeoff 100`(M/C 1회 = 지연 N톤·일) `--stab 10`(강종이 바뀐 라인·일 N일 = M/C 1회)

## 사내 서버 초안 (`server.py`)
```bash
python -m uvicorn cglplan.server:app --host 0.0.0.0 --port 8000
```
- `/` 대시보드, `/plan.html` 계획 화면(웹 파일 그대로), `/published/latest.plan.enc.json` 최신 결과(평문 → 사내망에서는 암호 없이 열림)
- `POST /api/plan`(엑셀 업로드), `POST /api/replan`(실적 엑셀), `POST /api/mes/actuals`(MES 실적 JSON — 규격은 함수 설명), `GET /api/jobs/{id}`, `GET /api/results`
- 인증은 사내 SSO/리버스 프록시에서. 데이터 폴더 `CGL_DATA_DIR`(기본 ./server_data)에 최신본·이력 저장

## 파일
| 파일 | 역할 | 웹 대응 |
|---|---|---|
| `defaults.json` | 기본 파라미터·판매계획 해석 규칙·기본 배선일정 — **웹에서 생성**(`node web/tools/export_defaults.js`) | params.js, sail_default.js |
| `util.py` | 날짜·속도·기간 | util.js |
| `parse.py` | 입력 엑셀 해석(라벨 기반, 합계행 대사) | parse.js |
| `model.py` | 버킷·MILP 2단계(빠른/정밀)·평준화 LP·목적지 배정 | model.js |
| `replan.py` | 롤링 재계획·실적 엑셀 해석 | replan.js, actual.js |
| `publish.py` | 결과 봉투·게시 암호화(AES-GCM, 웹과 호환) | crypto.js |
| `server.py` | 사내 서버 API 초안 | — |

## 파라미터를 바꿀 때
웹 `web/engine/params.js`를 고치고 `node web/tools/export_defaults.js` → `python tests/test_engine.py`. 두 엔진이 항상 같은 값을 쓰게 하기 위함.
