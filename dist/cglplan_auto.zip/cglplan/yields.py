"""소재량 산출 기준 실수율(사용자 제공 2026-10-07) — 소재량 = 제품량 ÷ (실수율 ÷ 100)
도금: 라인 × 강종 × 구분(일반 내수·수출 / 자가 / AL-STS)   컬러: 라인 × 품명군 (4CCL AL 은 두께 0.6mm 이상 = 후물)
표의 '1.0'(기준 미정) 칸은 100% 로 봄. 2Line MAC 은 일반 내수 99.49 · 수출 100.89, 자가 101.96 으로 읽음(확인 필요).
나중에 소재 발주 기준정보 화면에서 고칠 값.
"""
PLATING = {
    '1CGL': {'_line': 101.72,
             ('AL', '내수'): 98.42, ('AL', '수출'): 101.53, ('AL', '자가'): 101.56,
             ('AZ', '내수'): 99.80, ('AZ', '수출'): 102.26, ('AZ', '자가'): 102.62},
    '2CGL': {'_line': 100.11,
             ('AL', '내수'): 95.78, ('AL', '수출'): 99.95, ('AL', '자가'): 102.05,
             ('AL-STS', '내수'): 100.28, ('AL-STS', '수출'): 100.28,
             ('MAC', '내수'): 99.49, ('MAC', '수출'): 100.89, ('MAC', '자가'): 101.96},
}
CLS_KIND = {'도금국내': '내수', '자동차내수': '내수', '도금수출': '수출', '자동차수출': '수출', '자가재': '자가'}


def plating(line, alloy, cls):
    """도금 실수율(%) — AL-LG(LG향 자가재)는 AL 자가, 표에 없는 조합은 라인 평균"""
    a = 'AL' if alloy == 'AL-LG' else alloy
    k = CLS_KIND.get(cls, '내수')
    if a == 'AL-STS':
        k = '수출' if k == '수출' else '내수'
    T = PLATING.get(line) or {}
    return T.get((a, k)) or T.get('_line') or 100.0


# 컬러: (라인, 규칙) — 위에서부터 첫 번째로 맞는 규칙
_PRINT = ('PPG', 'PPH', 'PPK')
COLOR = {
    '1CCL': [('PVS', 103.0), ('PGS', 99.7), ('PBG', 99.7), ('PSS', 100.0), ('PSP', 100.3), ('PDF2', 100.0), ('PDF3', 100.0), ('PDF', 97.1),
             ('PCS2', 101.4), ('PES', 99.8), ('-AL', 100.0)],
    '2CCL': [('-STS', 100.0), ('PSP', 100.5), ('PDF2', 100.0), ('PDF3', 100.0), ('PDF', 100.1), ('PES2', 100.5), ('PCS4', 100.0), ('PCS', 100.1),
             ('PRINT', 101.5), ('-AL', 100.0), ('POR2', 99.4), ('PUR1', 99.4), ('*', 100.3)],
    '3CCL': [('PCS4', 100.8), ('PGS', 100.8), ('PSS', 100.0), ('PSP', 100.0), ('PDF', 101.3), ('PLS', 101.5), ('PLY', 101.5), ('-STS', 100.0),
             ('POR2', 99.9), ('POR', 100.0), ('PCS', 101.0), ('-AL', 103.1)],
    '4CCL': [('PRINT-AL', 94.6), ('-AL', 'AL'), ('-STS', 99.8), ('POR3', 99.8), ('PGS', 100.3), ('PDF', 99.0), ('PRINT', 100.1), ('PCS', 98.4),
             ('POR2', 96.4), ('PES', 101.3)],
}
AL_THICK, AL_GEN = 95.0, 103.2          # 4CCL AL: 두께 0.6 이상 후물 95.0, 미만 일반 103.2


def color(line, product, thick_share=None):
    """컬러 실수율(%). thick_share = 4CCL AL 품명의 후물(≥0.6mm) 비중(실적) — 없으면 0.5"""
    p = str(product).upper()
    is_print = p.startswith(_PRINT)
    for key, y in COLOR.get(line, []):
        hit = (key == '*' or (key == 'PRINT' and is_print) or (key == 'PRINT-AL' and is_print and p.endswith('-AL'))
               or (key.startswith('-') and p.endswith(key)) or (key not in ('PRINT', 'PRINT-AL', '*') and not key.startswith('-') and p.startswith(key)))
        if hit:
            if y == 'AL':
                s = 0.5 if thick_share is None else thick_share
                return s * AL_THICK + (1 - s) * AL_GEN
            return y
    return 100.0
