"""TF 계획재 운영안(R15) → 컬러 계획재 배치. 사양·물량·라인·순서·교체시간은 R15 그대로, 날짜만 다시 펼침.

R15 '일자별상세내역': 배치(배치ID)마다 생산량·순수생산시간·교체시간(색상교체·Roll교체·Dummy·단판TEST)이 있고,
순서는 휴지 최소화 기준(프린트·PVS2 별도 묶음, 폭 내림차순, 색상→소재→두께). 1,440분을 넘으면 조각으로 나뉨.
R15 는 다른 주문이 없다고 보고 라인 전체를 계획재에 써서 월초에 몰림(R15 스스로 적은 한계) →
여기서는 R15 순서를 그대로 두고 배치 시작 시각을 그 달 남은 기간에 물량 비례로 고르게 펼친다(사이 빈 시간에 다른 주문).
"""
import os
from collections import OrderedDict, defaultdict

LINE = {'1라인': '1CCL', '2라인': '2CCL', '3라인': '3CCL', '4라인': '4CCL'}
DEFAULT_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'color', 'TF_계획재_운영안_R15.xlsx')


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def load(path=DEFAULT_PATH):
    """{ym: {line: [배치, … R15 순서]}}  배치 = {id, product, spec, mat, t, min, day0(R15 첫 날), n(조각 수)}"""
    if not os.path.exists(path):
        return None
    import openpyxl
    ws = openpyxl.load_workbook(path, read_only=True, data_only=True)['일자별상세내역']
    it = ws.iter_rows(values_only=True)
    h = [str(x).strip() if x is not None else '' for x in next(it)]
    I = {k: h.index(k) for k in ('월', '일', '라인', '품명', '사양', '소재발주구분', '생산량(톤)', '순수생산시간(분)', '휴지시간합계(분)', '배치ID')}
    out = defaultdict(lambda: defaultdict(OrderedDict))
    for r in it:
        if r[I['월']] is None or r[I['배치ID']] is None:
            continue
        y, m = str(r[I['월']]).split('.')[:2]
        ym = f'{int(y)}-{int(m):02d}'
        line = LINE.get(str(r[I['라인']]).strip(), str(r[I['라인']]).strip())
        bid = r[I['배치ID']]
        b = out[ym][line].get(bid)
        if b is None:
            b = out[ym][line][bid] = {'id': bid, 'product': str(r[I['품명']]).strip(), 'spec': str(r[I['사양']]).strip(),
                                      'mat': str(r[I['소재발주구분']] or '').strip(), 't': 0.0, 'min': 0.0, 'day0': int(r[I['일']]), 'n': 0}
        b['t'] += _f(r[I['생산량(톤)']])
        b['min'] += _f(r[I['순수생산시간(분)']]) + _f(r[I['휴지시간합계(분)']])
        b['n'] += 1
    return {ym: {l: list(v.values()) for l, v in L.items()} for ym, L in out.items()}


def spec_key(spec):
    p = str(spec).split()
    return (round(_f(p[0]), 3), int(_f(p[1])), p[2] if len(p) > 2 else '')


def done_by_spec(lines, color_prod, ym, start_day):
    """이번 달 1 ~ start_day−1 일 MES 컬러 실적 중 R15 계획재 사양에 해당하는 톤 → {사양: t}
    정의는 계획재 화면(cglplan/planstock)과 같음: 컬러건재판매그룹, 폭 ±1mm·상도 색상 같음, 실측 두께 ±0.03mm 안 가장 가까운 사양"""
    keys = defaultdict(list)
    for bs in lines.values():
        for b in bs:
            k = spec_key(b['spec'])
            keys[k[2]].append((k[0], k[1], b['spec']))
    C = color_prod['columns']
    out = defaultdict(float)
    for r in color_prod['rows']:
        x = dict(zip(C, r))
        d = str(x['PRD_DT'])
        if not d.startswith(ym + '-') or int(d[8:10]) >= start_day or not str(x.get('DEPT') or '').startswith('컬러건재'):
            continue
        t, w = _f(x['REAL_MSR_THK']), _f(x['PDT_WDT'])
        best = None
        for kt, kw, sp in keys.get(str(x['SUR_FINISH_CD']), []):
            dd = abs(kt - t)
            if abs(kw - w) <= 1 and dd <= 0.03 + 1e-9 and (best is None or dd < best[0]):
                best = (dd, sp)
        if best:
            out[best[1]] += _f(x['PDT_WGT']) / 1000
    return out


def remaining(lines, done):
    """R15 순서를 유지한 채 사양별로 이미 만든 톤을 앞 배치부터 지움(시간은 톤 비례로 줄임)"""
    left = dict(done)
    out = {}
    for line, bs in lines.items():
        keep = []
        for b in bs:
            q = min(b['t'], left.get(b['spec'], 0.0))
            if q > 0:
                left[b['spec']] -= q
            t = b['t'] - q
            if t >= 0.5:
                keep.append(dict(b, t=t, min=b['min'] * t / b['t'] if b['t'] else b['min']))
        out[line] = keep
    return out


def place(lines, ndays, start_day=1, blocked=None, over=None):
    """한 달 배치를 일자에 배정. lines = {line: [배치…]} (R15 순서). blocked = {(일, 라인): 막힌 분}(S/D·수리 등, 그 날 앞쪽을 막음)
    시작 시각 = max(앞 배치 끝, 그 달 쓸 수 있는 시간 × 앞 배치들 누적 물량 비중) → 순서·교체시간은 R15 그대로, 월 전체에 고르게.
    시간축은 '쓸 수 있는 시간'(하루 1,440분 − 막힌 분)으로 펼쳐서 막힌 시간에는 배치가 들어가지 않음.
    반환: 행 [{day, line, t, min, batch}] (날을 넘는 배치는 시간 비례로 나눔), 점유 {(day, line): 분}(막힌 분 제외)
    over: 리스트를 주면 그 달 쓸 수 있는 시간을 넘는 부분을 마지막 날에 몰지 않고 여기에 [{line, t, min, batch}] 로 담음(미편성)"""
    blocked = blocked or {}
    rows, occ = [], defaultdict(float)
    for line, bs in lines.items():
        days = list(range(start_day, ndays + 1))
        cap = [max(0.0, 1440.0 - blocked.get((d, line), 0)) for d in days]
        span = sum(cap)
        acc = [0.0]
        for c in cap:
            acc.append(acc[-1] + c)
        tot = sum(b['t'] for b in bs) or 1.0
        cur, cum = 0.0, 0.0
        for b in bs:
            st = max(cur, span * cum / tot)
            en = st + b['min']
            a = st
            while a < en - 1e-9:
                if over is not None and a >= span - 1e-9:      # 그 달 남은 시간이 없음 → 미편성
                    over.append({'line': line, 't': b['t'] * (en - a) / b['min'] if b['min'] else b['t'], 'min': en - a, 'batch': b})
                    break
                i = next((k for k in range(len(days)) if acc[k + 1] > a + 1e-9), len(days) - 1)
                e = min(en, acc[i + 1]) if acc[i + 1] > a + 1e-9 else en       # 마지막 날을 넘으면 그 날에 몰아 둠(over 를 주면 위에서 미편성)
                frac = (e - a) / b['min'] if b['min'] else 1.0
                rows.append({'day': days[i], 'line': line, 't': b['t'] * frac, 'min': e - a, 'batch': b})
                occ[(days[i], line)] += e - a
                a = e
            cur, cum = en, cum + b['t']
    return rows, occ
