"""수요 버킷 → MILP 2단계(① M/C 최소 ② M/C·재가동 판단 고정 후 선생산 최소) → 평준화 LP → 목적지 배정.
웹 엔진 engine/model.js 와 같은 LP 파일을 만들어 highspy(HiGHS)로 푼다 — 같은 모델, 같은 규칙."""
import os
import re
import tempfile
import time

import highspy

from . import util as U

INF = float('inf')


def num_str(c):
    """JS String(+c.toPrecision(12)) 과 같은 값(해석되는 double 동일)."""
    v = float('%.12g' % c)
    return str(int(v)) if v.is_integer() and abs(v) < 1e15 else repr(v)


class LP:
    def __init__(self):
        self.cons, self.bounds, self.bins, self.n = [], {}, [], 0

    def v(self, prefix, lb=0.0, ub=INF, bin=False):
        name = f'{prefix}{self.n}'
        self.n += 1
        if bin:
            self.bins.append(name)
        elif lb != 0 or ub != INF:
            self.bounds[name] = (lb, ub)
        return name

    def fix(self, name, lb, ub):
        self.bounds[name] = (lb, ub)

    def con(self, terms, sense, rhs):
        self.cons.append((terms, sense, rhs))

    @staticmethod
    def expr(terms):
        parts, line = [], ''
        for c, v in terms:
            if c == 0:
                continue
            t = (' - ' if c < 0 else ' + ') + num_str(abs(c)) + ' ' + v
            if len(line) + len(t) > 200:
                parts.append(line)
                line = ''
            line += t
        parts.append(line)
        s = '\n'.join(parts).strip()
        return s[2:] if s.startswith('+ ') else s

    def text(self, obj, extra=(), extra_bounds=None):
        out = ['Minimize', ' obj: ' + LP.expr(obj), 'Subject To']
        for k, (t, s, r) in enumerate(list(self.cons) + list(extra)):
            out.append(f' c{k}: {LP.expr(t)} {s} {num_str(r)}')
        out.append('Bounds')
        b = dict(self.bounds)
        b.update(extra_bounds or {})
        for n, (lb, ub) in b.items():
            out.append(f" {num_str(lb)} <= {n} <= {'+inf' if ub == INF else num_str(ub)}")
        if self.bins:
            out.append('Binary')
            for i in range(0, len(self.bins), 20):
                out.append(' ' + ' '.join(self.bins[i:i + 20]))
        out.append('End')
        return '\n'.join(out)


class Result:
    def __init__(self, status, obj, values, sec):
        self.status, self.obj, self.values, self.sec = status, obj, values, sec
        self.optimal = status == 'Optimal'
        self.windowed = False

    def val(self, n):
        return self.values.get(n, 0.0)


def solve(text, opts, log, label, threads=None):
    """LP 텍스트를 HiGHS로 풀기. opts: time_limit, mip_rel_gap"""
    fd, path = tempfile.mkstemp(suffix='.lp')
    with os.fdopen(fd, 'w', encoding='ascii') as f:
        f.write(text)
    try:
        h = highspy.Highs()
        h.setOptionValue('output_flag', False)
        if threads:
            h.setOptionValue('threads', int(threads))
        for k, v in opts.items():
            h.setOptionValue(k, float(v) if k in ('time_limit', 'mip_rel_gap') else v)
        h.readModel(path)
        t0 = time.time()
        h.run()
        sec = time.time() - t0
        status = h.modelStatusToString(h.getModelStatus())
        info = h.getInfo()
        has_sol = info.primal_solution_status == 2
        obj = info.objective_function_value if has_sol else INF
        names = h.getLp().col_names_
        values = dict(zip(names, h.getSolution().col_value)) if has_sol else {}
    finally:
        os.remove(path)
    if log:
        log(f'{label}: {status}, 목적함수 {U.js_round(obj, 4) if obj != INF else obj}, {sec:.0f}초')
    if status != 'Optimal' and not has_sol:
        raise RuntimeError(f'{label} 실패: {status} (해 없음 — 수요가 캐파를 넘거나 제약이 모순)')
    return Result(status, obj, values, sec)


# ---------------- 수요 버킷 ----------------
def build_buckets(items, P):
    agg, sept = {}, []
    for it in items:
        if P['firstWindowPrevMonth'] and it['mi'] == 0 and it['window'] == '1~5일':
            sept.append(it)
            continue
        k = (it['cls'], it['alloy'], it['due'])
        agg[k] = agg.get(k, 0.0) + it['tons']
    buckets = [{'cls': c, 'alloy': a, 'due': d, 'orig': t} for (c, a, d), t in agg.items()]
    buckets.sort(key=lambda b: (b['due'], b['cls'], b['alloy']))
    for i, b in enumerate(buckets):
        b['id'] = i
    return buckets, sept


# ---------------- MILP ----------------
def plan_days(P, H, O):
    return U.date_range(O['t0'], H['D1']) if O and O.get('t0') else H['days']


def _x_allowed(P, b, l, d, O):
    if U.is_blackout(P, l, d):
        return False
    if d > b['due']:
        return bool(O and O.get('allowLate')) and U.diff_days(d, b['due']) <= (O.get('maxLate') or 14)
    return b['cls'] in P['releaseExempt'] or U.diff_days(b['due'], d) <= P['releaseDays']


def run_milp(buckets, P, log=None, O=None, threads=None):
    O = O or {}
    H = U.horizon(P)
    days = plan_days(P, H, O)
    D0 = days[0]
    L, LF, FAM = P['lines'], P['lineFamilies'], P['alloyFamily']
    prod_days = days[1:] if O.get('t0') else days
    FS, ND, EQ, RSF, RSS = P['switchDummy'], P['nonfamDummy'], P['equipDown'], P['restartFamchg'], P['restartSame']
    RST, XD = U.restart_days(P, H), O.get('extraDown') or {}
    blk = lambda l, d: U.is_blackout(P, l, d)
    lp = LP()
    x, short = [], {}
    for b in buckets:
        if not b['orig'] > 1e-6:
            continue
        n = 0
        for l in L:
            if b['alloy'] not in P['allowed'][l]:
                continue
            for d in prod_days:
                if _x_allowed(P, b, l, d, O):
                    x.append((b, l, d, lp.v('x')))
                    n += 1
        if O.get('allowLate'):
            short[b['id']] = lp.v('q')
        elif not n:
            raise RuntimeError(f"{b['cls']} {b['alloy']} 마감 {b['due']} {U.fmt(b['orig'])}t: 생산 가능한 날이 없음")
    z, s, sr = {}, {}, {}
    for l in L:
        for f in LF[l]:
            for d in days:
                z[(l, f, d)] = lp.v('z', bin=True)
    # s·r 이진: 목적함수가 정수가 되어 최적성 증명이 빨라짐
    for l in L:
        for d in days[1:]:
            s[(l, d)] = lp.v('s', bin=True)
    for k, r in RST.items():
        if r['day'] > D0:
            sr[k] = lp.v('r', bin=True)
    by_b = {}
    for e in x:
        by_b.setdefault(e[0]['id'], []).append(e)
    for b in buckets:
        if not b['orig'] > 1e-6:
            continue
        t = [(1, e[3]) for e in by_b.get(b['id'], [])]
        if b['id'] in short:
            t.append((1, short[b['id']]))
        lp.con(t, '=', b['orig'])
    for l in L:
        for d in days:
            lp.con([(1, z[(l, f, d)]) for f in LF[l]], '=', 1)
        for i, d in enumerate(days):
            if i == 0:
                continue
            p, sv = days[i - 1], s[(l, d)]
            if blk(l, d):
                for f in LF[l]:
                    lp.con([(1, z[(l, f, d)]), (-1, z[(l, f, p)])], '=', 0)
                lp.fix(sv, 0, 0)
            elif f'{l}|{d}' in sr:
                for f in LF[l]:
                    lp.con([(1, z[(l, f, d)]), (-1, z[(l, f, p)]), (-1, sr[f'{l}|{d}'])], '<=', 0)
                lp.fix(sv, 0, 0)
            else:
                for f in LF[l]:
                    lp.con([(1, z[(l, f, d)]), (-1, z[(l, f, p)]), (-1, sv)], '<=', 0)
    by_ld = {}
    for e in x:
        by_ld.setdefault((e[1], e[2]), []).append(e)
    rate = lambda e: U.rate_for(P, e[1], e[0]['alloy'], e[0]['cls'])
    for (l, d), lst in by_ld.items():
        t = [(1 / rate(e), e[3]) for e in lst]
        xd = min(XD.get(f'{l}|{d}', 0), 1440 - EQ[l] - ND[l])
        k = f'{l}|{d}'
        if k in sr:
            lp.con(t + [(RSF[l] - RSS[l], sr[k])], '<=', 1440 - EQ[l] - RSS[l] - xd)
        elif d == D0:
            lp.con(t, '<=', 1440 - EQ[l] - ND[l] - xd)
        else:
            lp.con(t + [(FS[l] - ND[l], s[(l, d)])], '<=', 1440 - EQ[l] - ND[l] - xd)
        for f in LF[l]:
            fl = [e for e in lst if FAM[e[0]['alloy']] == f]
            if not fl:
                continue
            r = max(rate(e) for e in fl)
            lp.con([(1, e[3]) for e in fl] + [(-1440 * r, z[(l, f, d)])], '<=', 0)
    if O.get('t0'):
        for l in L:
            lp.fix(z[(l, O['init'][l], O['t0'])], 1, 1)
    else:
        for l in L:
            if P['initFamily'].get(l):
                lp.con([(1, z[(l, P['initFamily'][l], D0)])], '=', 1)
    m = P.get('minCampaign') or 0
    if m > 1:
        for l in L:
            for i in range(1, len(days)):
                d = days[i]
                if blk(l, d):
                    continue
                for k in range(1, m):
                    if i + k >= len(days):
                        break
                    dk = days[i + k]
                    if blk(l, dk):
                        break
                    for f in LF[l]:
                        lp.con([(1, z[(l, f, d)]), (-1, z[(l, f, days[i - 1])]), (-1, z[(l, f, dk)])], '<=', 0)
    base = O.get('baseState') or {}
    fu = O.get('freezeUntil')
    if fu:
        for l in L:
            for d in prod_days:
                if d <= fu and base.get(f'{l}|{d}'):
                    lp.fix(z[(l, base[f'{l}|{d}'], d)], 1, 1)
    STAB = [z[(l, base[f'{l}|{d}'], d)] for l in L for d in prod_days if base.get(f'{l}|{d}') and not (fu and d <= fu)]

    MC = [(1, v) for v in s.values()]
    INV = [(max(0, U.diff_days(e[0]['due'], e[2])), e[3]) for e in x]
    LATE = [(U.diff_days(e[2], e[0]['due']), e[3]) for e in x if e[2] > e[0]['due']]
    SHORT = [(1, v) for v in short.values()]
    SR = [(round(1000 * (RSF[RST[k]['line']] - RSS[RST[k]['line']]) / FS[RST[k]['line']]) / 1000, v) for k, v in sr.items()]
    if log:
        log(f"MILP 모델: 변수 {lp.n} (이진 {len(lp.bins)}), 제약 {len(lp.cons)}" + (f" — 재계획 {U.md(prod_days[0])}~" if O.get('t0') else ''))
    late_w = 1 if O.get('lateW') is None else O['lateW']
    short_w = 1000 if O.get('shortW') is None else O['shortW']
    obj1 = [(1000 * c, v) for c, v in MC + SR + [(late_w * c, v) for c, v in LATE] + [(short_w * c, v) for c, v in SHORT] + [(-(O.get('stabW') or 0), v) for v in STAB]]
    r1 = solve(lp.text(obj1), {'time_limit': P['timeLimit1'], 'mip_rel_gap': 0}, log, '1단계(지연→M/C 최소)' if O.get('t0') else '1단계(M/C 최소)', threads)
    K = round(sum(r1.val(v) for _, v in MC))
    sr_fix = {k: round(r1.val(v)) for k, v in sr.items()}
    late1 = sum(c * r1.val(v) for c, v in LATE)
    short1 = sum(r1.val(v) for _, v in SHORT)
    extra = [(MC, '<=', K + 1e-6)] + [([(1, v)], '<=', sr_fix[k] + 1e-6) for k, v in sr.items()]
    if LATE:
        extra.append((LATE, '<=', late1 * (1 + 1e-6) + 0.5))
    if SHORT:
        extra.append((SHORT, '<=', short1 * (1 + 1e-6) + 0.5))
    # 허용오차(0.5)를 선생산 절감에 쓰지 못하도록 지연·결품에 큰 벌점(톤·일당 1,000 / 톤당 100만) — 웹 엔진과 동일
    obj2 = INV + [(P['restartPenalty'], v) for v in sr.values()] + [(-(O.get('stabW2') or 0), v) for v in STAB] \
        + [(1000 * c, v) for c, v in LATE] + [(1e6, v) for _, v in SHORT]

    def state_of(r):
        return {f'{l}|{d}': next(f for f in LF[l] if r.val(z[(l, f, d)]) > 0.5) for l in L for d in days}
    if (P.get('phase2Mode') or 'fast') == 'fast':
        # 빠른 모드: 현재 해의 전환일 ±W일 창 안에서만 강종 변경 허용, 개선이 없을 때까지 반복(웹 엔진과 동일)
        W = P.get('phase2Window') or 7
        st, best, tot2, r2 = state_of(r1), INF, 0.0, None
        for it in range(12):
            sw = {l: [d for i, d in enumerate(days) if i > 0 and st[f'{l}|{d}'] != st[f'{l}|{days[i - 1]}']] for l in L}
            fix_b = {}
            for l in L:
                for d in days:
                    if any(abs(U.diff_days(d, q)) <= W for q in sw[l]):
                        continue
                    for f in LF[l]:
                        v = 1 if st[f'{l}|{d}'] == f else 0
                        fix_b[z[(l, f, d)]] = (v, v)
            r = solve(lp.text(obj2, extra, fix_b), {'time_limit': P['timeLimit2'], 'mip_rel_gap': 0}, log, f'2단계(선생산 최소) {it + 1}회', threads)
            tot2 += r.sec
            if not r.optimal and r.obj == INF:
                break
            improved = r.obj < best - 1e-6 * max(1, abs(best))
            if improved or r2 is None:
                r2, best, st = r, r.obj, state_of(r)
            if not improved and it > 0:
                break
        r2.windowed, r2.sec = True, tot2
    else:
        r2 = solve(lp.text(obj2, extra), {'time_limit': P['timeLimit2'], 'mip_rel_gap': 0}, log, '2단계(선생산 최소)', threads)
    state = state_of(r2)
    inv = sum(r2.val(e[3]) * max(0, U.diff_days(e[0]['due'], e[2])) for e in x)
    short_by = [[bid, r2.val(v)] for bid, v in short.items() if r2.val(v) > 0.05]
    return {'state': state, 'K': K, 'srFix': sr_fix, 'INV': inv, 'late': sum(c * r2.val(v) for c, v in LATE),
            'short': sum(v for _, v in short_by), 'shortBy': short_by, 'optimal1': r1.optimal, 'optimal2': r2.optimal,
            'phase2Exact': not r2.windowed, 'sec': [r1.sec, r2.sec], 'obj1': r1.obj / 1000}


# ---------------- 캘린더(더미·정지) ----------------
def day_loss(P, H, state, l, d, O=None):
    O = O or {}
    st = lambda dd: state.get(f'{l}|{dd}')
    xd = (O.get('extraDown') or {}).get(f'{l}|{d}', 0)
    xev = f' · 추가정지 {U.fmt(xd)}분' if xd else ''
    if U.is_blackout(P, l, d):
        return {'blackout': 1440, 'equip': 0, 'nonfam': 0, 'mcdummy': 0, 'event': '정기수리(S/D)'}
    p, RST, first = U.add_days(d, -1), U.restart_days(P, H), plan_days(P, H, O)[0]
    if f'{l}|{d}' in RST and d > first:
        pf = st(p)
        chg = pf != st(d)
        return {'blackout': 0, 'equip': P['equipDown'][l] + xd, 'nonfam': 0, 'mcdummy': P['restartFamchg'][l] if chg else P['restartSame'][l],
                'event': (f'S/D 재가동({pf}→{st(d)})' if chg else 'S/D 재가동') + xev}
    if d != first and st(p) and st(p) != st(d):
        return {'blackout': 0, 'equip': P['equipDown'][l] + xd, 'nonfam': 0, 'mcdummy': P['switchDummy'][l], 'event': f'M/C({st(p)}→{st(d)})' + xev}
    return {'blackout': 0, 'equip': P['equipDown'][l] + xd, 'nonfam': P['nonfamDummy'][l], 'mcdummy': 0, 'event': xev[3:] if xev else ''}


# ---------------- 평준화 LP ----------------
def run_level(buckets, P, state, log=None, O=None, threads=None):
    O = O or {}
    H = U.horizon(P)
    days = plan_days(P, H, O)
    L, FAM = P['lines'], P['alloyFamily']
    prod_days = days[1:] if O.get('t0') else days
    cal, cap = [], {}
    for l in L:
        for d in prod_days:
            dl = day_loss(P, H, state, l, d, O)
            c = max(0, 1440 - dl['blackout'] - dl['equip'] - dl['nonfam'] - dl['mcdummy'])
            cap[(l, d)] = c
            cal.append(dict({'date': d, 'line': l, 'fam': state.get(f'{l}|{d}'), 'cap': c}, **dl))
    lp, x, short = LP(), [], {}
    for b in buckets:
        if not b['orig'] > 1e-6:
            continue
        for l in L:
            if b['alloy'] not in P['allowed'][l]:
                continue
            for d in prod_days:
                if FAM[b['alloy']] == state.get(f'{l}|{d}') and _x_allowed(P, b, l, d, O):
                    x.append((b, l, d, lp.v('x')))
        if O.get('allowLate'):
            short[b['id']] = lp.v('q')
    by_b = {}
    for e in x:
        by_b.setdefault(e[0]['id'], []).append(e)
    for b in buckets:
        if not b['orig'] > 1e-6:
            continue
        if b['id'] not in by_b and b['id'] not in short:
            raise RuntimeError(f"평준화: {b['cls']} {b['alloy']} {b['due']} 배정 가능 일 없음")
        t = [(1, e[3]) for e in by_b.get(b['id'], [])]
        if b['id'] in short:
            t.append((1, short[b['id']]))
        lp.con(t, '=', b['orig'])
    used = {}
    for e in x:
        used.setdefault((e[1], e[2]), []).append((1 / U.rate_for(P, e[1], e[0]['alloy'], e[0]['cls']), e[3]))
    Uv = {l: lp.v('U') for l in L}
    for l in L:
        for d in prod_days:
            if U.is_blackout(P, l, d):
                continue
            u = used.get((l, d), [])
            c = cap[(l, d)]
            if u:
                lp.con(u, '<=', c)
            lp.con(u + [(1, Uv[l])], '>=', c)
    INV = [(max(0, U.diff_days(e[0]['due'], e[2])), e[3]) for e in x]
    LATE = [(U.diff_days(e[2], e[0]['due']), e[3]) for e in x if e[2] > e[0]['due']]
    pen = [(1e4 * c, v) for c, v in LATE] + [(1e7, v) for v in short.values()]
    a = solve(lp.text([(1, Uv[l]) for l in L] + pen), {}, log, '평준화 1(최대 여유 최소)', threads)
    extra = [([(1, Uv[l])], '<=', a.val(Uv[l]) + 1.0) for l in L]
    b2 = solve(lp.text(INV + pen, extra), {}, log, '평준화 2(선생산 최소)', threads)
    rows = []
    for b, l, d, v in x:
        val = b2.val(v)
        if val > 0.05:
            rows.append([d, l, b['alloy'], b['cls'], U.js_round(val, 2), b['due']])
    rows.sort(key=lambda r: '\u0001'.join(map(str, r)))
    short_by = [[bid, b2.val(v)] for bid, v in short.items() if b2.val(v) > 0.05]
    return {'rows': rows, 'cal': cal, 'slack': {l: a.val(Uv[l]) for l in L}, 'shortBy': short_by}


# ---------------- 목적지 배정 ----------------
def split_dest(rows, items, P):
    order = U.DEFAULTS['SELF_SECTION_ORDER']
    groups = {}
    for it in items:
        if P['firstWindowPrevMonth'] and it['mi'] == 0 and it['window'] == '1~5일':
            continue
        groups.setdefault((it['cls'], it['alloy'], it['due']), []).append(dict(it, rem=it['tons']))
    for k, lst in groups.items():
        if k[0] == '자가재':
            lst.sort(key=lambda a: order.index(a['dest']) if a['dest'] in order else 99)
        else:
            lst.sort(key=lambda a: -a['tons'])
    prod = {}
    for r in rows:
        prod.setdefault((r[3], r[2], r[5]), []).append(r)
    out = []
    for k, lst in prod.items():
        lst.sort(key=lambda r: r[0] + r[1])
        subs, i = groups[k], 0
        for d, l, a, c, t, du in lst:
            left = t
            while left > 1e-6:
                while i < len(subs) - 1 and subs[i]['rem'] <= 1e-6:
                    i += 1
                s = subs[i]
                take = left if i == len(subs) - 1 else min(left, s['rem'])
                s['rem'] -= take
                left -= take
                out.append([d, l, a, c, s['dest'], s['port'], s['window'] or '', U.js_round(take, 2), du])
    out.sort(key=lambda r: r[0] + r[1] + r[3] + r[2])
    bad = [f"{s['cls']} {s['alloy']} {s['dest']} {U.js_round(s['rem'], 1)}" for lst in groups.values() for s in lst if abs(s['rem']) > 0.5]
    return out, bad


def run_plan(items, P, log=None, threads=None):
    """전체 실행 → 결과 dict(웹 대시보드가 읽는 JSON 형식과 동일)"""
    buckets, sept = build_buckets(items, P)
    if log:
        log(f"수요 버킷 {len(buckets)}개, {U.fmt(sum(b['orig'] for b in buckets), 1)}t (첫 달 1~5일 선적분 {U.fmt(sum(s['tons'] for s in sept), 1)}t는 전월 생산 가정)")
    milp = run_milp(buckets, P, log, threads=threads)
    lev = run_level(buckets, P, milp['state'], log, threads=threads)
    dest, bad = split_dest(lev['rows'], items, P)
    return {'P': P, 'items': items, 'buckets': buckets, 'sept': sept, 'milp': milp, 'rows': lev['rows'], 'cal': lev['cal'],
            'slack': lev['slack'], 'dest': dest, 'destBad': bad}
