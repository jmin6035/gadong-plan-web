"""판매생산속보(snap_salesrpt) 표 해석 — mes_download 가 화면의 <table> 을 행 단위 문자열로 저장한 것을 숫자 표로 바꿈.

칸 표기: 'AL{c2}' = colspan 2, '도금{r15}' = rowspan 15, 칸 구분 ' | '.
rowspan 이 걸린 앞쪽 글자 칸은 '묶음'(예: F/H도금용, 컬러용), 그 뒤 글자 칸은 '항목'으로 본다.
"""
import re

CELL = re.compile(r'^(.*?)((?:\{[cr]\d+\})*)$')
NUM = re.compile(r'^\(?-?[\d,]+(?:\.\d+)?\)?$')


def _cell(s):
    m = CELL.match(s.strip())
    txt, marks = m.group(1).strip(), m.group(2)
    rs = re.search(r'\{r(\d+)\}', marks)
    return txt, int(rs.group(1)) if rs else 1


def _num(t):
    if not NUM.match(t):                           # '-', 빈칸, 글자
        return None
    return float(t.strip('()').replace(',', ''))


def parse(tbl):
    """snap_salesrpt {'columns':[표,제목,행,칸], 'rows':[...]} → {제목: {'asOf', 'rows': [(묶음, 항목, [숫자...])]}}"""
    out, by = {}, {}
    for t, _cap, r, cells in tbl['rows']:
        by.setdefault(t, []).append((r, cells))
    for t, rows in by.items():
        rows.sort()
        title = _cell(rows[0][1].split(' | ')[0])[0]
        m = re.search(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\]', title)
        name = re.sub(r'\s*\[.*$', '', title).strip()
        groups, data = [], []                      # groups: [이름, 남은 행 수]
        for _r, cells in rows[1:]:
            cs = [_cell(c) for c in cells.split(' | ')]
            k = next((i for i, (x, _) in enumerate(cs) if NUM.match(x) or (x == '-' and i > 0)), None)
            if k is None:                          # 머리글 행
                continue
            labels = cs[:k]
            groups = [g for g in groups if g[1] > 0]
            item = []
            for x, rs in labels:
                if rs > 1:
                    groups.append([x, rs])
                else:
                    item.append(x)
            data.append((' '.join(g[0] for g in groups if g[0]), ' '.join(i for i in item if i),
                         [_num(x) for x, _ in cs[k:]]))
            for g in groups:
                g[1] -= 1
        out[name] = {'asOf': m.group(1) if m else None, 'rows': data}
    return out


def find(P, title_prefix, item, group=None, nth=0):
    """표 제목 앞부분·항목 이름(·묶음 일부)으로 숫자 목록 찾기"""
    for name, t in P.items():
        if name.startswith(title_prefix):
            hits = [v for g, i, v in t['rows'] if i == item and (group is None or group in g)]
            if len(hits) > nth:
                return hits[nth]
    return None


def summary(tbl):
    """보고서용 요약: 재고(목표·현재·증감), 이번 달 생산·출하(월차계획·일정누계·누계 실적), 장기재고"""
    P = parse(tbl)
    as_of = next((t['asOf'] for t in P.values() if t['asOf']), None)
    S = {'asOf': as_of, 'stock': [], 'prod': [], 'ship': [], 'longTerm': None}

    def stk(name, title, item, group=None, cur_idx=-2, nth=0, sub=None):
        v = find(P, title, item, group, nth)
        if not v:
            return
        S['stock'].append({'name': name, 'target': v[0], 'current': v[cur_idx], 'diff': v[-1], 'sub': sub or []})

    def sub(title, items, group=None, cur_idx=-2):
        r = []
        for it in items:
            v = find(P, title, it, group)
            if v:
                r.append({'name': it, 'target': v[0], 'current': v[cur_idx], 'diff': v[-1]})
        return r
    # 5.소재: 목표, 사내, A·B, 부두, 삼일3물류, 삼일, 외주가공, 기타, 계, 수입소재, 이송중, 증감 → 현재 = 뒤에서 4번째
    stk('도금 소재(F/H)', '5.소재', '소계', 'F/H', -4, sub=sub('5.소재', ['AL', 'AZ', 'GM'], 'F/H', -4))
    # 6-1.도금제품: 목표 … 합계, 증감 → 현재 = 뒤에서 2번째. 자가재는 목표가 없어 따로
    tot, own = find(P, '6-1.도금제품', '합계'), find(P, '6-1.도금제품', '자가')
    if tot and own:
        S['stock'].append({'name': '도금 제품(판매재)', 'target': tot[0], 'current': tot[-2] - own[-2], 'diff': tot[-2] - own[-2] - tot[0],
                           'sub': sub('6-1.도금제품', ['AL', 'AZ', 'GM'])})
        S['stock'].append({'name': '도금 제품(자가재)', 'target': None, 'current': own[-2], 'diff': None, 'sub': []})
    stk('컬러 소재', '5.소재', '소계', '컬러용', -4, sub=sub('5.소재', ['컬러수출', '컬러건재'], '컬러용', -4))
    stk('컬러 제품', '6-2.컬러제품', '합계', sub=sub('6-2.컬러제품', ['컬러수출', '컬러건재']))
    # 2.생산현황: 월차계획, 일정누계, 실적(일, 누계), 증감(일, 누계), T/H(일, 누계), 작업률, 가동률
    for grp, lines in (('도금', ['1CGL', '2CGL']), ('컬러', ['1CCL', '2CCL', '3CCL', '4CCL'])):
        for ln in lines + ['소계']:
            v = find(P, '2.생산현황', ln, grp)
            if v:
                S['prod'].append({'plant': grp, 'line': grp + ' 계' if ln == '소계' else ln, 'month': v[0], 'sched': v[1], 'actual': v[3], 'tph': v[7]})
    # 3.출하현황: 월차계획, 일정누계, 실적(일, 누계, 계획비) …
    for grp in ['도금판매', '도금수출', '자동차강판', '컬러수출', '컬러건재']:
        v = find(P, '3.출하현황', '소계', grp)
        if v:
            S['ship'].append({'name': grp, 'month': v[0], 'sched': v[1], 'actual': v[3]})
    v = find(P, '3.출하현황', '', '합계')
    if v:
        S['ship'].append({'name': '합계', 'month': v[0], 'sched': v[1], 'actual': v[3]})
    v = find(P, '7.장기재고', '총계')
    if v:                                          # 소재(3·6·12개월↑, 계, 전일비, 전월비), 제품(같음), 합계
        S['longTerm'] = {'material': v[3], 'product': v[9], 'total': v[-1], 'momProduct': v[11], 'momMaterial': v[5]}
        for grp in ('도금', '컬러'):
            g = find(P, '7.장기재고', '소계', grp)
            if g:
                S['longTerm'][grp] = g[-1]
    return S


if __name__ == '__main__':
    import json, sys
    ex = json.load(open(sys.argv[1], encoding='utf-8'))
    print(json.dumps(summary(ex['tables']['snap_salesrpt']), ensure_ascii=False, indent=1))
