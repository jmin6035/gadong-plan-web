"""추가 자료(extradata) 표 정리 — 같은 코일·같은 날이 두 번 들어가지 않게.

자동 실행기는 매일 기간을 겹쳐 다시 조회해 mes/extra/*.json 을 누적한다(auto.push_extra).
예전에는 '행 전체가 같을 때만' 중복으로 봐서, 그 사이 MES 값이 바뀐 코일(등급 판정·스크랩·휴지 시간·계약 재배정 등)은
옛 행과 새 행이 둘 다 남았다. 2026-10-16 자료에서 컬러 생산 10월 330코일·1,004t, 출하 5코일이 이렇게 두 번 들어가
컬러 10월 누계가 판매생산속보보다 8% 많았다(중복 제거 후 차이 38t, 0.3%).
→ 표마다 행을 구분하는 열(키)을 정해, 키가 같으면 새 자료 한 행만 남긴다. 키를 모르는 표는 예전처럼 행 전체로 비교."""

import json

# 표 이름 → 행을 구분하는 열. 값이 바뀌어도 같은 대상이면 같은 키
KEYS = {
    'color_prod': ('PDT_NO',),                          # 컬러 제품번호(코일 1개)
    'color_brk': ('LINE_CLS', 'PAU_STA_TM'),           # 라인·휴지 시작 시각
    'ship': ('PDT_NO', 'OUT_DT', 'OUT_RSN_CD'),         # 제품·출고일·출고 사유
    'stock_trend': ('WRK_DT', 'KIND'),
    'stock_rpt7': ('WRK_DT', 'CLS', 'CLS_1'),
    'stock_rpt8': ('WRK_DT', 'CLS'),
    'stock_rpt9': ('WRK_DT', 'CLS'),
}


def _key_fn(name, columns):
    ks = KEYS.get(name)
    if ks and all(k in columns for k in ks):
        idx = [columns.index(k) for k in ks]
        return lambda r: tuple(r[i] for i in idx)
    return lambda r: json.dumps(r, ensure_ascii=False)


def dedup(name, table):
    """앞쪽 행(새 자료)을 남기고 같은 키 행 제거. 반환: (새 표, 지운 행 수)"""
    cols, rows = table.get('columns') or [], table.get('rows') or []
    key, seen, out = _key_fn(name, cols), set(), []
    for r in rows:
        k = key(r)
        if k not in seen:
            seen.add(k)
            out.append(r)
    return {**table, 'rows': out}, len(rows) - len(out)


def merge(name, new, old):
    """누적: 새 자료 우선. 열 구성이 다르면 새 자료로 교체"""
    if not old or old.get('columns') != new.get('columns'):
        return dedup(name, new)[0]
    return dedup(name, {'columns': new['columns'], 'rows': new['rows'] + old['rows']})[0]


def clean(tables):
    """extradata['tables'] 를 제자리 정리. 반환: {표: 지운 행 수} (지운 것만)"""
    gone = {}
    for name in KEYS:
        t = tables.get(name)
        if t and t.get('rows'):
            tables[name], n = dedup(name, t)
            if n:
                gone[name] = n
    return gone


def load_extra(path):
    """extradata.json 을 읽어 정리까지 한 번에"""
    ex = json.load(open(path, encoding='utf-8'))
    if isinstance(ex, dict) and isinstance(ex.get('tables'), dict):
        clean(ex['tables'])
    return ex
