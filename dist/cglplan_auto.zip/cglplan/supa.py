"""Supabase Storage 올리기·내려받기(표준 라이브러리만 사용). 사내 PC 자동 실행기가 쓴다.
- 공개 버킷 'published': 암호화된 계획 결과 → 대시보드가 공개 주소로 읽음
- 비공개 버킷 'mes': 누적 MES 실적(주간 분석용)
키는 설정 파일(auto_config.json)에만 둔다. 새 형식 secret 키(sb_secret_...)와 예전 service_role 키(eyJ...) 모두 지원."""
import json
import ssl
import urllib.error
import urllib.parse
import urllib.request


class Supa:
    def __init__(self, url, key, ssl_verify=True, timeout=60):
        self.url, self.key, self.timeout = url.rstrip('/'), key, timeout
        self.ctx = None if ssl_verify else ssl._create_unverified_context()   # 사내 보안 프록시가 인증서를 바꿔치는 경우용

    def _headers(self, extra=None):
        h = {'apikey': self.key}
        if self.key.startswith('eyJ'):          # 예전 JWT 키는 Authorization 도 필요
            h['Authorization'] = f'Bearer {self.key}'
        h.update(extra or {})
        return h

    def _req(self, method, path, data=None, headers=None):
        req = urllib.request.Request(self.url + path, data=data, method=method, headers=self._headers(headers))
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=self.ctx) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    @staticmethod
    def _q(path):
        return urllib.parse.quote(path)

    def upload(self, bucket, path, data, content_type='application/json', cache='30'):
        """덮어쓰기 업로드. cache = CDN 캐시 초(대시보드가 늦게 보지 않도록 짧게)"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        code, body = self._req('POST', f'/storage/v1/object/{bucket}/{self._q(path)}', data,
                               {'Content-Type': content_type, 'x-upsert': 'true', 'cache-control': f'max-age={cache}'})
        if code >= 300:
            raise RuntimeError(f'Supabase 업로드 실패 {bucket}/{path}: HTTP {code} {body[:300].decode("utf-8", "replace")}')
        return True

    def download(self, bucket, path, public=False):
        """없으면 None"""
        p = f'/storage/v1/object/{"public/" if public else ""}{bucket}/{self._q(path)}'
        code, body = self._req('GET', p)
        if code == 404 or (code == 400 and b'not_found' in body.lower().replace(b' ', b'_')):
            return None
        if code >= 300:
            raise RuntimeError(f'Supabase 내려받기 실패 {bucket}/{path}: HTTP {code} {body[:300].decode("utf-8", "replace")}')
        return body

    def check(self):
        """연결·키 확인: 버킷 목록"""
        code, body = self._req('GET', '/storage/v1/bucket')
        if code >= 300:
            raise RuntimeError(f'Supabase 연결/키 확인 실패: HTTP {code} {body[:300].decode("utf-8", "replace")}')
        return [b.get('name') for b in json.loads(body)]
