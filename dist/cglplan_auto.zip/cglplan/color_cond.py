"""컬러 조건 분석 — 화면 color_analysis.html 자료(color_cond.enc.json). 도금 조건 분석(analysis.html)과 같은 구성:
라인별 요약 → 계획 조건 후보(현재 · 실적 · 차이 · 근거 · 판정) → 주별 속도 추이 → 주별 제품 생산량 | 주별 휴지 → 휴지 사유.

계획 조건: pages_base/color_cond_base.json — 통합 계획 컬러 일정이 쓰는 품명·라인(·부서)별 t/hr
           (cglplan/color_full.plan_thr = 「컬러 품목별 단위생산량(2508_2607)」 엑셀, 없는 품명만 7/1~9/30 실적)를 고정 저장.
실적: color_prod·color_brk 최근 13주(월~일, 마지막 완결 주까지). 후보 판정은 최근 4주.
'구성 감안 속도 차이' = 최근 4주에 실제로 만든 품목을 계획 t/hr 로 나눈 시간 ÷ 실제 걸린 시간 − 1 (품목 구성 차이를 뺀 속도 차이).
"""
import datetime as dt
from collections import Counter, defaultdict

from . import color_full as CF
from . import pages as PG

LINES = ['1CCL', '2CCL', '3CCL', '4CCL']
BRK_LINE = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}
APPLY_D, APPLY_T, MIN_T = 0.05, 150, 20          # 반영 권장: 차이 5% 이상 · 4주 150t 이상 · 앞 12주도 같은 방향


def base_table(T, d0='2026-07-01', d1='2026-09-30'):
    thr = CF.plan_thr(T['color_prod'], d0, d1)                   # 2026-10-21: 계획 조건 = 단위생산량 엑셀(없는 품명만 MES 7~9월)
    return {'from': d0, 'to': d1, 'thr': [[list(k), round(v[0], 4), round(v[1], 1)] for k, v in thr.items()]}


def _thr_of(base):
    return {tuple(k): (a, b) for k, a, b in base['thr']}


def _week(d):
    x = dt.date.fromisoformat(d)
    return (x - dt.timedelta(days=x.weekday())).isoformat()


def build(T, base=None):
    base = base or PG.load_base('color_cond_base.json')
    rows = PG._rows(T, 'color_prod')
    if not rows or not base:
        return None
    thr_plan = _thr_of(base)
    last = max(str(r['PRD_DT'])[:10] for r in rows)
    w_end = dt.date.fromisoformat(last) - dt.timedelta(days=(dt.date.fromisoformat(last).weekday() + 1) % 7)   # 마지막 완결 주의 일요일
    p0 = (w_end - dt.timedelta(days=13 * 7 - 1)).isoformat()
    a0, a1 = (w_end - dt.timedelta(days=27)).isoformat(), w_end.isoformat()
    b0, b1 = p0, (w_end - dt.timedelta(days=28)).isoformat()
    first = min(str(r['PRD_DT'])[:10] for r in rows)                # 자료 시작일 — 기간 이름(13주·4주·12주)을 실제 자료 범위로
    p0, a0, b0 = max(p0, first), max(a0, first), max(b0, first)
    nwk = lambda x, y: max(0, round(((dt.date.fromisoformat(y) - dt.date.fromisoformat(x)).days + 1) / 7))
    n13, n4, n12 = nwk(p0, a1), nwk(a0, a1), (nwk(b0, b1) if b0 <= b1 else 0)
    thr4 = CF.thr_table(T['color_prod'], a0, a1)
    thr12 = CF.thr_table(T['color_prod'], b0, b1) if n12 else {}
    cd = CF.CL._codes()
    G_OF = {v: k for k, v in CF.DEPT_OF_GROUP.items()}
    L = {l: Counter() for l in LINES}
    days = defaultdict(set)
    wk = defaultdict(lambda: [0.0, 0.0, 0])                       # (주, 라인, 품명) → 톤, 시간, 코일
    wl = defaultdict(lambda: [0.0, 0.0, set()])                   # (주, 라인) → 휴지 h, 작업+휴지 h, 가동일
    mk = defaultdict(lambda: [0.0, 0.0, 0])                       # (월, 라인, 품명) → 톤, 시간, 코일 — 마지막 날까지(이번 달 = 누계)
    ml = defaultdict(lambda: [0.0, 0.0, set()])                   # (월, 라인) → 휴지 h, 작업+휴지 h, 가동일
    for r in rows:
        d = str(r['PRD_DT'])[:10]
        l = r['LINE']
        if l in L and d >= first:
            pm = CF.base_name((cd.get(r['PDT_NM']) or {}).get('name', r['PDT_NM']))[0]
            tm, wm, qm = PG.f(r['PDT_WGT']) / 1000, PG.f(r['WRK_TIME']), PG.f(r['PAU_TIME'])
            z = mk[(d[:7], l, pm)]; z[0] += tm; z[1] += (wm + qm) / 60; z[2] += 1
            z = ml[(d[:7], l)]; z[0] += qm / 60; z[1] += (wm + qm) / 60
            if tm > 0:
                z[2].add(d)
        if not (p0 <= d <= a1) or l not in L:
            continue
        p = CF.base_name((cd.get(r['PDT_NM']) or {}).get('name', r['PDT_NM']))[0]
        t = PG.f(r['PDT_WGT']) / 1000
        wmin, pmin = PG.f(r['WRK_TIME']), PG.f(r['PAU_TIME'])
        x = wk[(_week(d), l, p)]
        x[0] += t; x[1] += (wmin + pmin) / 60; x[2] += 1
        y = wl[(_week(d), l)]
        y[0] += pmin / 60; y[1] += (wmin + pmin) / 60
        if t > 0:
            y[2].add(d)
        L[l]['t13'] += t; L[l]['coils'] += 1; L[l]['wrk'] += wmin; L[l]['pau'] += pmin
        if t > 0:
            days[l].add(d)
        if d >= a0:
            g_ = G_OF.get(str(r.get('DEPT') or ''))
            if g_ in ('건재수출', '가전수출', '가전내수'):              # 수출그룹은 용도로 건재(CC*)·가전 구분 — 단위생산량 엑셀 부서(컬러수출 건재·가전)에 맞춤
                g_ = '건재수출' if str(r.get('ORD_USG_CD') or '').startswith('CC') else '가전수출'
            tph, _ = CF.tph_for(p, l, thr_plan, g_)
            L[l]['t4'] += t; L[l]['h4'] += (wmin + pmin) / 60; L[l]['ph4'] += t / tph if tph else 0
    # 휴지 사유(13주): 라인 · 구분(메모 낱말) · 사유(코드 이름, 없으면 가장 흔한 메모)
    rs = defaultdict(lambda: [0.0, 0, Counter()])
    stop_cat = Counter()
    for r in PG._rows(T, 'color_brk'):
        d = str(r.get('WRK_DT') or '')
        d = f'{d[:4]}-{d[4:6]}-{d[6:8]}' if len(d) == 8 else d[:10]
        l = BRK_LINE.get(r.get('LINE_CLS'))
        if not l or not (p0 <= d <= a1):
            continue
        cat = PG.stop_cat(r.get('SPL_REM'))
        code = str(r.get('PAU_RSN_CD_1') or '-')
        x = rs[(l, cat, code)]
        x[0] += PG.f(r['PAU_TIME']); x[1] += 1
        x[2][str(r.get('PAU_RSN_NM_1') or '') or str(r.get('SPL_REM') or '')[:38]] += 1
        stop_cat[(l, cat)] += PG.f(r['PAU_TIME'])
    lines = {}
    for l in LINES:
        x = L[l]
        od = len(days[l]) or 1
        t12 = sum(v[1] for k, v in thr12.items() if len(k) == 2 and k[1] == l)
        h12 = sum(v[1] / v[0] for k, v in thr12.items() if len(k) == 2 and k[1] == l and v[0])
        tp = sum(v[1] for k, v in thr_plan.items() if len(k) == 2 and k[1] == l)
        hp = sum(v[1] / v[0] for k, v in thr_plan.items() if len(k) == 2 and k[1] == l and v[0])
        h13 = (x['wrk'] + x['pau']) / 60
        cats = sorted(((c, m) for (ll, c), m in stop_cat.items() if ll == l), key=lambda z: -z[1])
        lines[l] = {'tons': round(x['t13']), 'coils': int(x['coils']), 'days': (dt.date.fromisoformat(a1) - dt.date.fromisoformat(p0)).days + 1, 'opDays': len(days[l]),
                    'util': round(x['wrk'] / (x['wrk'] + x['pau']), 3) if x['wrk'] + x['pau'] else None,
                    'tph13': round(x['t13'] / h13, 2) if h13 else None, 'tph4': round(x['t4'] / x['h4'], 2) if x['h4'] else None,
                    'tph12': round(t12 / h12, 2) if h12 else None, 'tphPlan': round(tp / hp, 2) if hp else None,
                    'idx4': round(x['ph4'] / x['h4'], 3) if x['h4'] else None, 'stopPerDay': round(x['pau'] / od / 60, 1),
                    'stops': [[c, round(m / od / 60, 1)] for c, m in cats[:4]]}
    cands = []
    for l in LINES:                                               # 라인 전체(구성 감안)
        x = lines[l]
        if x['idx4'] is None:
            continue
        d = x['idx4'] - 1
        cands.append({'label': f'{l} 속도(품목 구성 감안)', 'unit': '계획 대비', 'cur': 1.0, 'act': x['idx4'], 'diff': d,
                      'basis': f"최근 {n4}주 {round(L[l]['t4']):,}t · 계획 속도대로면 {L[l]['ph4']:.0f}h, 실제 {L[l]['h4']:.0f}h",
                      'apply': abs(d) >= APPLY_D and n4 >= 4, 'flag': abs(d) >= 0.03, 'kind': 'line', 'line': l})   # 자료 4주 미만이면 '검토'까지만(표본이 짧음)
    for k, (v4, t4) in sorted(thr4.items(), key=lambda kv: (kv[0][1] if len(kv[0]) == 2 else '', -kv[1][1])):
        if len(k) != 2 or t4 < MIN_T:
            continue
        p, l = k
        vp = thr_plan.get(k)
        tph_p = vp[0] if vp else CF.tph_for(p, l, thr_plan)[0]
        v12 = thr12.get(k)
        d = v4 / tph_p - 1 if tph_p else None
        same = v12 is not None and d is not None and (v12[0] / tph_p - 1) * d > 0 and abs(v12[0] / tph_p - 1) >= 0.03
        cands.append({'label': f'{l} {p} 속도', 'unit': 't/hr', 'cur': round(tph_p, 2), 'act': round(v4, 2), 'diff': round(d, 3) if d is not None else None,
                      'basis': f"{n4}주 {t4:,.0f}t · 앞 {n12}주 {v12[0]:.2f}" + (f" · 계획 근거 {vp[1]:,.0f}t" if vp else ' · 계획 근거 없음(다른 라인 평균)') if v12 else f"{n4}주 {t4:,.0f}t · 이전 자료 없음",
                      'apply': d is not None and abs(d) >= APPLY_D and t4 >= APPLY_T and same, 'flag': d is not None and abs(d) >= APPLY_D,
                      'hLoss': round(t4 / v4 - t4 / tph_p, 1) if v4 and tph_p else None, 'kind': 'prod', 'line': l, 't4': round(t4, 1), 'prod': p, 'v12': round(v12[0], 2) if v12 else None})
    keep = {(l, p) for (w, l, p), v in wk.items()}
    tot13 = Counter()
    for (w, l, p), v in wk.items():
        tot13[(l, p)] += v[0]
    keys = sorted([k for k in keep if tot13[k] >= 100], key=lambda k: (k[0], -tot13[k]))
    weeks = sorted({w for (w, l, p) in wk})
    weekly = [[w, l, p, round(v[0], 1), round(v[1], 2), v[2]] for (w, l, p), v in wk.items() if (l, p) in set(keys)]
    cur = {f'{l}|{p}': round((thr_plan.get((p, l)) or (CF.tph_for(p, l, thr_plan)[0],))[0], 2) for l, p in keys}
    wstop = [[w, l, round(v[0], 1), len(v[2])] for (w, l), v in wl.items()]
    reasons = sorted([{'line': l, 'kind': c, 'code': code, 'reason': x[2].most_common(1)[0][0] if x[2] else '', 'minutes': round(x[0]), 'n': x[1]}
                      for (l, c, code), x in rs.items()], key=lambda z: (z['line'], -z['minutes']))
    reasons = [z for l in LINES for z in [y for y in reasons if y['line'] == l][:8]]          # 라인별 많은 순 8개
    months = sorted({m for (m, l, p) in mk})
    months = [m for m in months if not (m == first[:7] and first[8:] != '01')] or months   # 1일 이후 시작한 첫 달(잘린 달)은 뺌
    monthly = [[m, l, p, round(v[0], 1), round(v[1], 2), v[2]] for (m, l, p), v in mk.items() if m in months and (l, p) in set(keys)]
    mstop = [[m, l, round(v[0], 1), len(v[2])] for (m, l), v in ml.items() if m in months]
    return {'asOf': last, 'period': {'from': p0, 'to': a1}, 'w4': [a0, a1], 'w12': [b0, b1] if n12 else None, 'n13': n13, 'n4': n4, 'n12': n12,
            'months': months, 'monthly': monthly, 'mstop': mstop, 'planFrom': base['from'], 'planTo': base['to'],
            'lines': lines, 'cands': cands, 'weeks': weeks, 'weekly': weekly, 'cur': cur, 'wstop': wstop, 'reasons': reasons,
            'hasNames': any(r.get('PAU_RSN_NM_1') for r in PG._rows(T, 'color_brk')[:50]),
            'built': dt.datetime.now().isoformat(timespec='minutes')}
