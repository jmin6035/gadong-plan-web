"""컬러 조건 분석 — 화면 color_analysis.html 자료(color_cond.enc.json). 도금 조건 분석(analysis.html)과 같은 역할:
계획이 쓰는 조건(라인·품명별 휴지 포함 t/hr)을 최근 MES 실적으로 다시 재서 비교하고, 계획 조건을 바꿔야 할지 알려 준다.

계획 기준: pages_base/color_cond_base.json — 통합 계획이 쓴 t/hr 표(cglplan/color_full.thr_table, 7/1~9/30 실적)를 고정 저장.
최근 실적: color_prod 최근 4주(월~일, 완결 주)와 그 앞 12주.
'계획 조건대로라면 걸렸을 시간' = 최근 4주에 실제로 만든 품목(품명·라인·부서)을 계획 t/hr 로 나눈 시간.
  실제 걸린 시간(작업 + 정지)과 비교 → 품목 구성 차이를 빼고 본 속도 차이(계획보다 빠름/느림).
"""
import datetime as dt
from collections import Counter, defaultdict

from . import color_full as CF
from . import pages as PG

LINES = ['1CCL', '2CCL', '3CCL', '4CCL']


def base_table(T, d0='2026-07-01', d1='2026-09-30'):
    thr = CF.thr_table(T['color_prod'], d0, d1)
    return {'from': d0, 'to': d1, 'thr': [[list(k), round(v[0], 4), round(v[1], 1)] for k, v in thr.items()]}


def _thr_of(base):
    return {tuple(k): (a, b) for k, a, b in base['thr']}


def build(T, base=None):
    base = base or PG.load_base('color_cond_base.json')
    rows = PG._rows(T, 'color_prod')
    if not rows or not base:
        return None
    thr_plan = _thr_of(base)
    last = max(str(r['PRD_DT'])[:10] for r in rows)
    dl = dt.date.fromisoformat(last)
    w_end = dl - dt.timedelta(days=(dl.weekday() + 1) % 7)       # 마지막 완결 주의 일요일
    a0, a1 = (w_end - dt.timedelta(days=27)).isoformat(), w_end.isoformat()
    b0, b1 = (w_end - dt.timedelta(days=27 + 84)).isoformat(), (w_end - dt.timedelta(days=28)).isoformat()
    thr4 = CF.thr_table(T['color_prod'], a0, a1)
    thr12 = CF.thr_table(T['color_prod'], b0, b1)
    cd = CF.CL._codes()
    G_OF = {v: k for k, v in CF.DEPT_OF_GROUP.items()}            # 부서 → 대표 그룹(tph_for 의 부서 키 찾기용)
    L = {l: Counter() for l in LINES}
    plan_h_by = Counter()
    days = defaultdict(set)
    for r in rows:
        d = str(r['PRD_DT'])[:10]
        if not (a0 <= d <= a1) or r['LINE'] not in L:
            continue
        p = CF.base_name((cd.get(r['PDT_NM']) or {}).get('name', r['PDT_NM']))[0]
        t = PG.f(r['PDT_WGT']) / 1000
        h = (PG.f(r['WRK_TIME']) + PG.f(r['PAU_TIME'])) / 60
        dept = str(r.get('DEPT') or '')
        tph, src = CF.tph_for(p, r['LINE'], thr_plan, G_OF.get(dept))
        L[r['LINE']]['t'] += t
        L[r['LINE']]['h'] += h
        L[r['LINE']]['ph'] += t / tph if tph else 0
        plan_h_by[(p, r['LINE'])] += t / tph if tph else 0
        if t > 0:
            days[r['LINE']].add(d)
    lines = []
    for l in LINES:
        x = L[l]
        t12 = sum(v[1] for k, v in thr12.items() if len(k) == 2 and k[1] == l)
        h12 = sum(v[1] / v[0] for k, v in thr12.items() if len(k) == 2 and k[1] == l and v[0])
        tp = sum(v[1] for k, v in thr_plan.items() if len(k) == 2 and k[1] == l)
        hp = sum(v[1] / v[0] for k, v in thr_plan.items() if len(k) == 2 and k[1] == l and v[0])
        lines.append({'line': l, 't4': round(x['t']), 'h4': round(x['h'], 1), 'tph4': round(x['t'] / x['h'], 2) if x['h'] else None,
                      'tph12': round(t12 / h12, 2) if h12 else None, 'tphPlan': round(tp / hp, 2) if hp else None,
                      'planH': round(x['ph'], 1), 'idx': round(x['ph'] / x['h'], 3) if x['h'] else None,      # 1 보다 크면 계획보다 빠름
                      'days4': len(days[l]), 'tpd4': round(x['t'] / 28, 1)})
    prods = []
    for k, (v4, t4) in thr4.items():
        if len(k) != 2 or t4 < 20:
            continue
        p, l = k
        vp = thr_plan.get(k)
        v12 = thr12.get(k)
        tph_p, src = CF.tph_for(p, l, thr_plan)
        prods.append({'p': p, 'l': l, 't4': round(t4, 1), 'tph4': round(v4, 2), 'tph12': round(v12[0], 2) if v12 else None,
                      'tphPlan': round(vp[0], 2) if vp else round(tph_p, 2), 'planSrc': '품명·라인 실적' if vp and vp[1] >= 10 else src,
                      'tPlan': round(vp[1], 1) if vp else 0, 'diff': round(v4 / (vp[0] if vp else tph_p) - 1, 3) if (vp or tph_p) else None,
                      'hLoss': round(t4 / v4 - t4 / (vp[0] if vp else tph_p), 1) if v4 and (vp or tph_p) else None})
    prods.sort(key=lambda x: -abs(x['hLoss'] or 0))
    tot_t = sum(x['t4'] for x in lines)
    tot_h = sum(x['h4'] for x in lines)
    tot_ph = sum(x['planH'] for x in lines)
    return {'asOf': last, 'w4': [a0, a1], 'w12': [b0, b1], 'planFrom': base['from'], 'planTo': base['to'],
            'lines': lines, 'prods': prods,
            'tot': {'t4': round(tot_t), 'h4': round(tot_h, 1), 'planH': round(tot_ph, 1), 'idx': round(tot_ph / tot_h, 3) if tot_h else None},
            'built': dt.datetime.now().isoformat(timespec='minutes')}
