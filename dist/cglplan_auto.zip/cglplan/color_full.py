"""컬러 1~4CCL 전체 일별 가동계획 (계획재 + 주문재 + 건재수출 + 가전수출 + 가전내수 + 수요개발).

TF「컬러·도금 일별가동계획」 구조를 따르되 다음을 우리 자료로 바꿈
  · 월 물량 기준: MES 월차계획(판매생산속보, 라인별 톤) — 라인 월 톤 한도
  · 기초재고: MES 재고현황 월말 재고(그룹·품명 풀), 이번 달 실적은 생산필요량에서 뺌
  · T/hr: MES 컬러 실적(최근 3개월, 휴지 포함 = 톤 ÷ (작업+휴지 시간)), 품명·라인별
  · 가능 라인: 필수재 규칙 + 최근 실적 라인(20t 이상). 2CCL 은 최후 순위·이미 가동하는 날에 몰아서
  · 계획재: cglplan.color(EOQ·추천반순, 사양 단위·교체시간 포함)
수요(판매계획) 입력: TF 파일의 '컬러_판매계획' 시트(③ 주문재 ④ 수출 ⑤ 가전내수 ⑥ 수요개발) — 새 버전을 넣으면 다시 계산
수출 목적지·선적창: 같은 TF 파일의 그룹 시트(컬러건재수출·컬러가전수출)에 있는 목적지·배선 비중을 그대로 사용
"""
import calendar
import datetime as dt
import re
from collections import Counter, defaultdict

from . import color as CL

GROUPS = ['계획재', '주문재', '건재수출', '가전수출', '가전내수', '수요개발']
TARGET_DAYS = {'주문재': 20, '건재수출': 15, '가전수출': 15, '가전내수': 30, '수요개발': 30}
LOT_T = {'주문재': 60, '건재수출': 100, '가전수출': 100, '가전내수': 80, '수요개발': 60}
LOT_MAX = {'주문재': 6, '건재수출': 6, '가전수출': 6, '가전내수': 6, '수요개발': 3}
PRIORITY = {'수출벌크': 1, '가전내수': 2, '수출': 3, '수요개발': 3, '주문재': 4}
MONTH_COL = re.compile(r'(\d{2})\.(\d{1,2})월\s*판매계획')


def _f(x, d=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


def base_name(p):
    """판매계획 품명 → (기본 품명, MAC 여부): 'PGS(MAC.)'→('PGS',True), 'PCS(가전)'→('PCS',False), 'PDF-AL(후물)_유니언스'→('PDF-AL',False)"""
    s = str(p or '').strip()
    mac = '(MAC' in s.upper()
    s = re.sub(r'\(MAC\.?\)', '', s, flags=re.I)
    s = re.sub(r'\((가전|후물|프)\)', '', s)
    s = s.split('_')[0].strip()
    return s, mac


# ---------------------------------------------------------------- 판매계획
def load_sales(path):
    """TF '컬러_판매계획' → 행 목록 {group, product, mac, region, customer, sales{YYYY-MM: t}, targetDays}"""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = list(wb['컬러_판매계획'].iter_rows(values_only=True))
    out, sec, cols, tdcol = [], None, {}, None
    for r in rows:
        a = str(r[0] or '').strip()
        if a.startswith('③'):
            sec = '주문재'
        elif a.startswith('④'):
            sec = '수출'
        elif a.startswith('⑤'):
            sec = '가전내수'
        elif a.startswith('⑥'):
            sec = '수요개발'
        elif a.startswith(('①', '②')):
            sec = None
        if sec and a in ('부서', '그룹'):                        # 머리글 행
            cols, tdcol = {}, None
            for j, h in enumerate(r):
                m = MONTH_COL.search(str(h or '').replace('\n', ' '))
                if m:
                    cols[j] = f'20{m.group(1)}-{int(m.group(2)):02d}'
                if '목표재고' in str(h or '') and '일수' in str(h or ''):
                    tdcol = j
            continue
        if not sec or not cols or a in ('', '합계') or a.startswith(('③', '④', '⑤', '⑥', '※')):
            continue
        if sec == '주문재' and r[1] != '주문재':
            continue
        grp = {'주문재': '주문재', '가전내수': '가전내수', '수요개발': '수요개발'}.get(sec) or \
            ('건재수출' if '건재' in a else '가전수출')
        prod, mac = base_name(r[2])
        sales = {ym: _f(r[j]) for j, ym in cols.items()}
        if not any(sales.values()):
            continue
        out.append({'group': grp, 'productRaw': r[2], 'product': prod, 'mac': mac,
                    'region': str(r[3] or '').strip() if sec == '수출' else '', 'customer': str(r[3] or '').strip() if sec != '수출' and sec != '주문재' else '',
                    'note': str(r[4] or ''), 'sales': sales,
                    'targetDays': _f(r[tdcol], None) if tdcol is not None else None})
    return out


def load_export_dest(path):
    """TF 그룹 시트(컬러건재수출·컬러가전수출) → (그룹, 기본품명, 지역, 판매월) → [(목적지, 배선, 완료일 또는 None=월중 균등, 비중)]"""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    agg = defaultdict(Counter)
    for sh, grp in (('컬러건재수출', '건재수출'), ('컬러가전수출', '가전수출')):
        rows = list(wb[sh].iter_rows(values_only=True))
        h = [str(x or '').replace('\n', '') for x in rows[0]]
        ix = {k: h.index(k) for k in ('품명', '지역', '목적지명', '배선일정', '생산량(톤)', '생산기준(배선일정)', '판매월')}
        for r in rows[1:]:
            if not r[ix['품명']]:
                continue
            sm = str(r[ix['판매월']] or '')
            m = re.match(r'(\d{2})\.(\d{1,2})', sm)
            if not m:
                continue
            ym = f'20{m.group(1)}-{int(m.group(2)):02d}'
            basis = str(r[ix['생산기준(배선일정)']] or '')
            due = None
            mm = re.search(r'(\d{1,2})일까지', basis) or re.search(r'완료기한\s*(\d{1,2})일', basis)
            if mm:
                due = int(mm.group(1))
            if '전월 말 선생산' in basis:                       # 판매월 1~5일 벌크 선적 → 전월 말에 생산
                due = -1
            bulk = '벌크' in basis
            region = str(r[ix['지역']] or '').split('→')[0].strip()
            agg[(grp, base_name(r[ix['품명']])[0], region, ym)][(str(r[ix['목적지명']] or '미정'), str(r[ix['배선일정']] or ''), due, bulk)] += _f(r[ix['생산량(톤)']])
    out = {}
    for k, c in agg.items():
        tot = sum(c.values()) or 1
        out[k] = [(d, s, due, bulk, v / tot) for (d, s, due, bulk), v in c.items() if v > 0]
    return out


# ---------------------------------------------------------------- 재고 풀
def stock_pools(snap_stock, specs, month=None):
    """재고현황 컬러 제품 → (그룹, 기본품명, MAC) → 톤. 계획재 사양과 일치하는 건재 재고는 계획재로(여기서 제외)"""
    T = [dict(zip(snap_stock['columns'], r)) for r in snap_stock['rows']]
    month = month or max(r['_기준월'] for r in T)
    m = CL.Matcher(specs)
    pools = Counter()
    for r in T:
        if r['_기준월'] != month or r['공장구분'] != 'C' or r['구분명'] != 'P':
            continue
        dept, cust = str(r['담당부서(HR)'] or ''), str(r['고객사'] or '')
        prod = m.nm(r['품명코드'])
        mac = str(r['도금량'] or '').startswith('M')
        t = _f(r['중량']) / 1000
        if dept.startswith('컬러건재판매'):
            if m(r['품명코드'], _f(r['제품두께']), _f(r['제품폭']), r['표면상도코드'], tolt=0.02):
                continue
            g = '주문재'
        elif dept.startswith('컬러수출'):
            g = ('건재수출' if '수출1' in dept else '가전수출') if cust.startswith('J') else '가전내수'
        elif dept.startswith('수요개발'):
            g = '수요개발'
        else:
            continue
        pools[(g, base_name(prod)[0], mac)] += t
    return pools, month


def _pool_key(row):
    mac = row['mac'] if row['group'] == '주문재' else None      # 수출·가전은 MAC 구분 없이 품명 풀
    return (row['group'], row['product'], mac)


def needs(sales, pools, ym, ndays_next, next_ym, plan_spec_demand=None):
    """판매계획 행별 이번 달 생산필요량 = MAX(0, 판매 + 목표기말 − 기초재고(풀을 판매 비중으로 배분))
    주문재 판매 = 품명 판매계획 − 같은 품명 계획재 수요(EOQ 월평균) — TF 와 같은 정의"""
    plan_spec_demand = plan_spec_demand or {}
    pool_sales = Counter()
    for r in sales:
        s = r['sales'].get(ym, 0)
        if r['group'] == '주문재':
            s = max(0.0, s - plan_spec_demand.get((r['product'], r['mac']), 0))
        r['salesM'] = s
        r['salesNext'] = r['sales'].get(next_ym, 0) if r['group'] != '주문재' else max(0.0, r['sales'].get(next_ym, 0) - plan_spec_demand.get((r['product'], r['mac']), 0))
    for r in sales:
        k = _pool_key(r)
        pool_sales[k] += r['salesM'] + r['salesNext'] * 0.01
    for r in sales:
        k = _pool_key(r)
        tot = sum(v for (g, p, mc), v in pools.items() if (g, p) == k[:2] and (k[2] is None or mc == k[2]))
        share = (r['salesM'] + r['salesNext'] * 0.01) / pool_sales[k] if pool_sales[k] else 0
        r['stock0'] = tot * share
        td = r['targetDays'] if r['targetDays'] else TARGET_DAYS[r['group']]
        r['targetEnd'] = r['salesNext'] * td / ndays_next
        r['need'] = max(0.0, r['salesM'] + r['targetEnd'] - r['stock0'])
    return sales


# ---------------------------------------------------------------- 속도·라인
def thr_table(color_prod, d0, d1):
    """(기본품명, 라인) → 휴지 포함 t/hr, 톤. 품명은 제품코드 → 판매 품명"""
    cd = CL._codes()
    t, h = Counter(), Counter()
    for r in color_prod['rows']:
        x = dict(zip(color_prod['columns'], r))
        if not (d0 <= x['PRD_DT'] <= d1):
            continue
        p = base_name((cd.get(x['PDT_NM']) or {}).get('name', x['PDT_NM']))[0]
        k = (p, x['LINE'])
        t[k] += _f(x['PDT_WGT']) / 1000
        h[k] += (_f(x['WRK_TIME']) + _f(x['PAU_TIME'])) / 60
    return {k: (t[k] / h[k], t[k]) for k in t if h[k] > 0}


RULE_LINES = [  # 필수재 규칙(TF 필수재 시트 + 사용자: print 는 2·4라인, POR2 는 빠른 라인)
    (lambda p, g: p.startswith('PVS'), ['1CCL']),
    (lambda p, g: p.startswith(('PPG', 'PPK', 'PPH')), ['4CCL', '2CCL']),
    (lambda p, g: p.endswith('-AL') or p in ('PVDF', 'PUR2', 'PDFM'), ['4CCL']),
    (lambda p, g: p.endswith('-STS') or p.startswith(('PLY', 'ETC4')), ['3CCL']),
]


def lines_for(prod, group, thr):
    for f, ls in RULE_LINES:
        if f(prod, group):
            hist = [l for l in ls if (prod, l) in thr]
            return ls if not hist else sorted(ls, key=lambda l: (l == '2CCL', -(thr.get((prod, l), (0,))[0])))
    hist = [l for l in CL.LINES if thr.get((prod, l), (0, 0))[1] >= 20]
    if not hist:                                               # 실적 없는 품명: 3라인(가전 전용) 제외 일반 라인
        hist = ['1CCL', '4CCL', '2CCL'] if not group.startswith('가전') else ['3CCL', '4CCL', '1CCL', '2CCL']
    if '3CCL' in hist and not group.startswith('가전') and len(hist) > 1 and thr.get((prod, '3CCL'), (0, 0))[1] < 200:
        hist.remove('3CCL')                                    # 3라인은 가전 전용 운영(실적 적은 건재 품명은 제외)
    return sorted(hist, key=lambda l: (l == '2CCL', -(thr.get((prod, l)) or (0,))[0]))


def tph_for(prod, line, thr):
    v = thr.get((prod, line))
    if v and v[1] >= 10:
        return v[0], '품명·라인 실적'
    vs = [(a, b) for (p, l), (a, b) in thr.items() if p == prod and b >= 10]
    if vs:
        return sum(a * b for a, b in vs) / sum(b for a, b in vs), '품명 실적(타라인 평균)'
    vs = [(a, b) for (p, l), (a, b) in thr.items() if l == line]
    return (sum(a * b for a, b in vs) / sum(b for a, b in vs), '라인 평균') if vs else (10.0, '가정')


# ---------------------------------------------------------------- 로트 만들기
def make_lots(sales, dest, ym, ndays, start_day, next_ym=None):
    lots = []
    span0 = start_day
    for r in sales:                                            # 다음 달 1~5일 벌크 선적분 → 이번 달 말 10일 안에 선생산
        if r['group'] not in ('건재수출', '가전수출') or not next_ym or not r['salesNext']:
            continue
        for d, ship, due, bulk, w in dest.get((r['group'], r['product'], r['region'], next_ym)) or []:
            if due != -1:
                continue
            q = max(0.0, (r['salesNext'] - r['targetEnd']) * w)
            if q < 0.5:
                continue
            r['preNext'] = r.get('preNext', 0) + q
            n = max(1, min(4, round(q / 400)))
            for k in range(n):
                lots.append({'row': r, 'group': r['group'], 'dest': d, 'ship': ship + ' (다음달 판매분 선생산)', 't': q / n,
                             'release': max(start_day, ndays - 9), 'due': ndays, 'prio': PRIORITY['수출벌크'], 'k': k + 1})
    for r in sales:
        need = r.get('needLeft', r['need'])
        if need < 1:
            continue
        g = r['group']
        if g in ('건재수출', '가전수출'):
            ds = dest.get((g, r['product'], r['region'], ym)) or [('미정', '', None, False, 1.0)]
            for d, ship, due, bulk, w in ds:
                q = need * w
                if q < 0.5:
                    continue
                if due == -1:                                  # 이번 달 1~5일 선적분: 지난달 생산 대상 → 남았으면 바로
                    due = start_day + 2
                if due:                                        # 선적 완료기한 있음: 벌크는 기한 전 10일 안, 컨테이너 월말은 기한 전
                    due = max(due, start_day)
                    n = max(1, min(4 if bulk else LOT_MAX[g], round(q / (400 if bulk else LOT_T[g]))))
                    for k in range(n):
                        lots.append({'row': r, 'group': g, 'dest': d, 'ship': ship, 't': q / n, 'release': max(start_day, due - 10),
                                     'due': due, 'prio': PRIORITY['수출벌크' if bulk else '수출'], 'k': k + 1})
                else:
                    lots += _even(r, g, q, ndays, span0, PRIORITY['수출'], d, ship)
        else:
            lots += _even(r, g, need, ndays, span0, PRIORITY[g], '', '')
    return lots


def _even(r, g, q, ndays, start, prio, dest, ship):
    n = max(1, min(LOT_MAX[g], round(q / LOT_T[g])))
    span = (ndays - start + 1) / n
    out = []
    for k in range(n):
        rel = start + int(k * span)
        out.append({'row': r, 'group': g, 'dest': dest, 'ship': ship, 't': q / n, 'release': rel,
                    'due': min(ndays, int(start + (k + 1) * span + 2)), 'prio': prio, 'k': k + 1})
    return out


# ---------------------------------------------------------------- 일별 배정
def schedule(lots, thr, cap_t, occ, ndays, start_day, prefer=None):
    """lots 를 (라인, 일) 1,440분 칸에 배정. cap_t: 라인 남은 월 톤 한도, occ: (일, 라인) → 이미 쓴 분(계획재)
    prefer: 로트 키 → [(일, 라인)] — 재계획 때 지난 계획 자리를 먼저 시도(일정이 통째로 바뀌지 않게). 키 = lot_key(로트)
    반환: 배정 행 목록, 미편성 로트"""
    free = defaultdict(lambda: 1440.0)
    for k, v in occ.items():
        free[k] = max(0.0, 1440.0 - v)
    used_t = Counter()
    run_days = defaultdict(set)
    for (d, l), v in occ.items():
        if v > 0:
            run_days[l].add(d)
    placed, unplaced = [], []
    # 한 라인에서만 되는 품명(STS→3CCL, 후물·AL→4CCL 등)을 먼저 넣고, 여러 라인이 되는 품명은 남은 칸에 — 전용 라인을 범용 품명이 먼저 차지하지 않게
    lots.sort(key=lambda x: (len(lines_for(x['row']['product'], x['group'], thr)) > 1, x['prio'], x['due'], -x['t']))
    for x in lots:
        prod = x['row']['product']
        cands = lines_for(prod, x['group'], thr)
        left = x['t']
        days_pref = list(range(max(start_day, x['release']), min(ndays, x['due']) + 1)) or [min(ndays, max(start_day, x['due']))]
        days_early = list(range(min(ndays, max(start_day, x['release']) - 1), start_day - 1, -1))
        days_late = list(range(min(ndays, x['due']) + 1, ndays + 1))
        for d, l in ((prefer or {}).get(lot_key(x)) or []):            # 지난 계획 자리 먼저
            if left < 0.05:
                break
            if d < start_day or d > ndays or l not in cands:
                continue
            tph, src = tph_for(prod, l, thr)
            room_t = cap_t.get(l, 0) - used_t[l]
            if room_t <= 0.05 or free[(d, l)] < 5:
                continue
            q = min(left, free[(d, l)] / 60 * tph, room_t)
            mins = q / tph * 60
            free[(d, l)] -= mins
            used_t[l] += q
            run_days[l].add(d)
            left -= q
            placed.append({'lot': x, 'day': d, 'line': l, 't': q, 'min': mins, 'tph': tph, 'src': src, 'late': d > x['due'], 'early': d < x['release'], 'kept': True})
        for pass_ in ('pref', 'early', 'late'):
            for l in cands:
                if left < 0.05:
                    break
                tph, src = tph_for(prod, l, thr)
                ds = {'pref': days_pref, 'early': days_early, 'late': days_late}[pass_]
                if l == '2CCL':                                # 2CCL: 이미 가동하는 날 먼저(몰아주기)
                    ds = sorted(ds, key=lambda d: (d not in run_days[l], d))
                for d in ds:
                    if left < 0.05:
                        break
                    room_t = cap_t.get(l, 0) - used_t[l]
                    if room_t <= 0.05 or free[(d, l)] < 5:
                        continue
                    q = min(left, free[(d, l)] / 60 * tph, room_t)
                    mins = q / tph * 60
                    free[(d, l)] -= mins
                    used_t[l] += q
                    run_days[l].add(d)
                    left -= q
                    placed.append({'lot': x, 'day': d, 'line': l, 't': q, 'min': mins, 'tph': tph, 'src': src,
                                   'late': pass_ == 'late', 'early': pass_ == 'early'})
            if left < 0.05:
                break
        if left >= 0.05:
            unplaced.append((x, left))
    return placed, unplaced, used_t


def lot_key(x):
    r = x['row']
    return '|'.join(map(str, (x['group'], r.get('productRaw'), r.get('region') or r.get('customer'), x.get('dest'), x.get('ship'), x.get('k'))))


def plan_month(specs, tbl_speed, ex_tables, sales, dest, month_plan, year, month, start_day, act_from, act_to, official_target=None):
    """official_target: {'컬러수출': t, '컬러건재': t} (판매생산속보 6-2 목표재고). 주면 TF 목표재고일수로 만든 목표기말재고를
    부서 합계가 공식 목표와 같아지도록 줄이거나 늘림(컬러건재 = 계획재 목표 + 주문재). None 이면 TF 일수 그대로"""
    T = ex_tables
    ndays = calendar.monthrange(year, month)[1]
    ym = f'{year}-{month:02d}'
    ny, nm = (year + 1, 1) if month == 12 else (year, month + 1)
    next_ym, nd_next = f'{ny}-{nm:02d}', calendar.monthrange(ny, nm)[1]
    # ① 계획재(사양 단위)
    stock, smon = CL.stock_by_spec(specs, T['snap_stock'])
    act = CL.actual_stats(specs, T['color_prod'], act_from, act_to)
    act['share'] = {l: (0.0 if l == '3CCL' else 1.0) for l in CL.LINES}   # 전체 계획에서는 계획재도 라인 전체 시간 안에서(나머지 그룹과 같이 1,440분 칸을 나눠 씀)
    dact, made = CL.actual_days(specs, T['color_prod'], year, month, start_day)
    PR = CL.plan(specs, stock, month_plan, act, tbl_speed, year, month, start_day=start_day, made_before=made)
    occ = Counter()
    plan_t_line = Counter()
    for x in PR['lots']:
        s0 = x['startH'] - x['coMin'] / 60
        a, b = s0, x['endH']
        while a < b - 1e-9:
            d = int(a // 24) + 1
            e = min(b, d * 24)
            occ[(min(d, ndays), x['line'])] += (e - a) * 60
            a = e
        plan_t_line[x['line']] += x['t']
    # ② 나머지 그룹: 판매계획 − 재고 + 목표재고 → 이번 달 실적 빼고 남은 필요량
    pools, _ = stock_pools(T['snap_stock'], specs, smon)
    spec_dem = Counter()
    for s in specs:
        spec_dem[(s['name'], '(MAC' in str(s['nameMat']))] += s['demand']
    needs(sales, pools, ym, nd_next, next_ym, spec_dem)
    scale = {}
    if official_target:
        exp = sum(r['targetEnd'] for r in sales if r['group'] in ('건재수출', '가전수출', '가전내수'))
        odr = sum(r['targetEnd'] for r in sales if r['group'] == '주문재')
        plan_tg = sum(sp['target'] for sp in specs)
        scale = {'수출': (official_target.get('컬러수출', 0) / exp) if exp else 1,
                 '주문재': max(0.0, official_target.get('컬러건재', 0) - plan_tg) / odr if odr else 1, '수요개발': 0.0}
        for r in sales:
            k = '수출' if r['group'] in ('건재수출', '가전수출', '가전내수') else r['group']
            r['targetTF'] = r['targetEnd']
            r['targetEnd'] *= scale.get(k, 1)
            r['need'] = max(0.0, r['salesM'] + r['targetEnd'] - r['stock0'])
    thr = thr_table(T['color_prod'], act_from, act_to)
    # 이번 달 실적(계획재 사양 제외)을 그룹·품명별로 빼기 — 컬러수출 실적은 그 품명의 수출·가전 행에 필요량 비례
    cd = CL._codes()
    m = CL.Matcher(specs)
    done = Counter()
    done_line = Counter()
    for r in T['color_prod']['rows']:
        x = dict(zip(T['color_prod']['columns'], r))
        if not x['PRD_DT'].startswith(ym + '-') or int(x['PRD_DT'][8:]) >= start_day:
            continue
        t = _f(x['PDT_WGT']) / 1000
        done_line[x['LINE']] += t
        if m(x['PDT_NM'], _f(x['REAL_MSR_THK']), _f(x['PDT_WDT']), x['SUR_FINISH_CD']):
            continue
        p = base_name((cd.get(x['PDT_NM']) or {}).get('name', x['PDT_NM']))[0]
        dept = str(x['DEPT'] or '')
        fam = '주문재' if dept.startswith('컬러건재') else ('수요개발' if dept.startswith('수요') else '수출')
        done[(fam, p)] += t
    for r in sales:
        fam = '수출' if r['group'] in ('건재수출', '가전수출', '가전내수') else r['group']
        tot = sum(z['need'] for z in sales if z['product'] == r['product'] and ('수출' if z['group'] in ('건재수출', '가전수출', '가전내수') else z['group']) == fam)
        r['doneM'] = done[(fam, r['product'])] * (r['need'] / tot if tot else 0)
        r['needLeft'] = max(0.0, r['need'] - r['doneM'])
    # ③ 라인 남은 톤 한도 = 월차 − 이번 달 실적 − 계획재 편성
    cap = {l: max(0.0, (month_plan.get(l) or 0) - done_line[l] - plan_t_line[l]) for l in CL.LINES}
    lots = make_lots(sales, dest, ym, ndays, start_day, next_ym)
    placed, unplaced, used = schedule(lots, thr, cap, occ, ndays, start_day)
    return {'year': year, 'month': month, 'ndays': ndays, 'ym': ym, 'startDay': start_day, 'planned': PR, 'occ': occ,
            'sales': sales, 'placed': placed, 'unplaced': unplaced, 'cap': cap, 'usedT': used, 'doneLine': done_line,
            'planTLine': plan_t_line, 'monthPlan': month_plan, 'thr': thr, 'stockMonth': smon, 'dayAct': dact,
            'specs': specs, 'pools': pools, 'targetScale': scale, 'officialTarget': official_target}
